package com.example.data.model

data class UserProfile(
    val uid: String = "",
    val fullName: String = "",
    val email: String = "",
    val phoneNumber: String = "",
    val age: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
