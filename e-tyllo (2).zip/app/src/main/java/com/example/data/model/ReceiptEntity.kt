package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "receipts",
    indices = [Index(value = ["transactionId"])]
)
data class ReceiptEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val transactionId: Long = 0,
    val merchantName: String = "",
    val receiptDateMillis: Long = System.currentTimeMillis(),
    val category: String = "Shopping",
    val subtotal: Double = 0.0,
    val tax: Double = 0.0,
    val discount: Double = 0.0,
    val totalAmount: Double = 0.0,
    val currency: String = "PKR",
    val imagePath: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)
