package com.example.data.local

import androidx.room.*
import com.example.data.model.ReceiptEntity
import com.example.data.model.ReceiptItemEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ReceiptDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReceipt(receipt: ReceiptEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReceiptItems(items: List<ReceiptItemEntity>)

    @Query("SELECT * FROM receipts WHERE transactionId = :transactionId LIMIT 1")
    suspend fun getReceiptByTransactionId(transactionId: Long): ReceiptEntity?

    @Query("SELECT * FROM receipt_items WHERE receiptId = :receiptId")
    suspend fun getItemsByReceiptId(receiptId: Long): List<ReceiptItemEntity>

    @Query("SELECT * FROM receipt_items WHERE transactionId = :transactionId")
    suspend fun getItemsByTransactionId(transactionId: Long): List<ReceiptItemEntity>

    @Query("SELECT * FROM receipts ORDER BY receiptDateMillis DESC")
    fun getAllReceipts(): Flow<List<ReceiptEntity>>

    @Query("DELETE FROM receipts WHERE transactionId = :transactionId")
    suspend fun deleteReceiptByTransactionId(transactionId: Long)

    @Query("DELETE FROM receipt_items WHERE transactionId = :transactionId")
    suspend fun deleteReceiptItemsByTransactionId(transactionId: Long)
}
