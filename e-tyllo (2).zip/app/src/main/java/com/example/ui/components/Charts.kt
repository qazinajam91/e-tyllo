package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TransactionEntity
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

data class PieSegment(
    val category: String,
    val amount: Double,
    val color: Color
)

data class DayTrendData(
    val dayNumber: Int,
    val dateMillis: Long,
    val income: Double,
    val expense: Double,
    val net: Double
)

/**
 * Dynamic, interactive Donut / Pie chart with zero hardcoded sample data.
 * If no expenses exist, displays a clean, user-friendly empty state.
 */
@Composable
fun DonutChart(
    segments: List<PieSegment>,
    modifier: Modifier = Modifier,
    emptyMessage: String = "No expenses recorded for this period"
) {
    var selectedCategory by remember { mutableStateOf<PieSegment?>(null) }
    val total = remember(segments) { segments.sumOf { it.amount } }

    if (segments.isEmpty() || total <= 0.0) {
        // Clean empty state — No fake data!
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
            modifier = modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.PieChart,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                    modifier = Modifier.size(40.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = emptyMessage,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
        }
        return
    }

    // Sort segments from highest to lowest amount
    val sortedSegments = remember(segments) { segments.sortedByDescending { it.amount } }

    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(220.dp)
                .padding(8.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(sortedSegments, total) {
                        detectTapGestures { offset ->
                            val center = Offset(size.width / 2f, size.height / 2f)
                            val dx = offset.x - center.x
                            val dy = offset.y - center.y
                            val distance = Math.hypot(dx.toDouble(), dy.toDouble())
                            val outerRadius = minOf(size.width, size.height).toFloat() / 2f
                            val innerRadius = outerRadius - 36.dp.toPx()

                            if (distance in innerRadius..outerRadius) {
                                var angle = Math.toDegrees(Math.atan2(dy.toDouble(), dx.toDouble())).toFloat()
                                if (angle < 0) angle += 360f
                                // Angle relative to startAngle (-90 deg)
                                val normalizedAngle = (angle + 90f) % 360f

                                var currentAngle = 0f
                                var matched: PieSegment? = null
                                for (segment in sortedSegments) {
                                    val sweep = (segment.amount / total * 360f).toFloat()
                                    if (normalizedAngle in currentAngle..(currentAngle + sweep)) {
                                        matched = segment
                                        break
                                    }
                                    currentAngle += sweep
                                }
                                selectedCategory = if (selectedCategory == matched) null else matched
                            } else {
                                selectedCategory = null
                            }
                        }
                    }
            ) {
                val strokeWidth = 32.dp.toPx()
                val diameter = size.minDimension - strokeWidth
                val topLeft = Offset((size.width - diameter) / 2, (size.height - diameter) / 2)
                val arcSize = Size(diameter, diameter)

                var startAngle = -90f

                sortedSegments.forEach { seg ->
                    val sweepAngle = (seg.amount / total * 360f).toFloat()
                    val isSelected = selectedCategory == seg
                    val currentStroke = if (isSelected) strokeWidth + 6.dp.toPx() else strokeWidth

                    drawArc(
                        color = seg.color,
                        startAngle = startAngle,
                        sweepAngle = (sweepAngle - 2f).coerceAtLeast(1f),
                        useCenter = false,
                        topLeft = if (isSelected) Offset(topLeft.x - 3.dp.toPx(), topLeft.y - 3.dp.toPx()) else topLeft,
                        size = if (isSelected) Size(arcSize.width + 6.dp.toPx(), arcSize.height + 6.dp.toPx()) else arcSize,
                        style = Stroke(width = currentStroke)
                    )
                    startAngle += sweepAngle
                }
            }

            // Central Info Text
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(16.dp)
            ) {
                selectedCategory?.let { seg ->
                    val pct = (seg.amount / total * 100).toInt()
                    Text(
                        text = seg.category,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = seg.color,
                        maxLines = 1
                    )
                    Text(
                        text = "Rs ${seg.amount.toInt()}",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "$pct%",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } ?: run {
                    Text(
                        text = "Total Expense",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "Rs ${total.toInt()}",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "${sortedSegments.size} Categories",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Dynamic Legend Items sorted by highest amount first
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            sortedSegments.forEach { seg ->
                val pct = (seg.amount / total * 100)
                val isSelected = selectedCategory == seg

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isSelected) seg.color.copy(alpha = 0.12f) else Color.Transparent,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .clickable {
                            selectedCategory = if (selectedCategory == seg) null else seg
                        }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(seg.color)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = seg.category,
                                fontSize = 13.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Rs ${seg.amount.toInt()}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = String.format(Locale.US, "%.1f%%", pct),
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Monthly Financial Trend Chart — Replaces the old weekly demo chart.
 * Uses 100% REAL stored transactions aggregated day-by-day for the selected month.
 * Includes interactive month navigation, touch/drag date selector, and detailed day tooltip.
 */
@Composable
fun MonthlyFinancialTrendChart(
    transactions: List<TransactionEntity>,
    modifier: Modifier = Modifier,
    tr: (String) -> String = { it }
) {
    val todayCal = remember { Calendar.getInstance() }
    val todayYear = todayCal.get(Calendar.YEAR)
    val todayMonth = todayCal.get(Calendar.MONTH)
    val todayDay = todayCal.get(Calendar.DAY_OF_MONTH)

    var currentYear by remember { mutableIntStateOf(todayYear) }
    var currentMonth by remember { mutableIntStateOf(todayMonth) }

    // Month details calculation
    val monthCal = remember(currentYear, currentMonth) {
        Calendar.getInstance().apply {
            set(Calendar.YEAR, currentYear)
            set(Calendar.MONTH, currentMonth)
            set(Calendar.DAY_OF_MONTH, 1)
        }
    }
    val daysInMonth = monthCal.getActualMaximum(Calendar.DAY_OF_MONTH)
    val monthName = remember(currentMonth) {
        val cal = Calendar.getInstance().apply { set(Calendar.MONTH, currentMonth) }
        SimpleDateFormat("MMMM", Locale.getDefault()).format(cal.time)
    }

    var selectedDay by remember(currentYear, currentMonth) {
        val initial = if (currentYear == todayYear && currentMonth == todayMonth) todayDay else 1
        mutableIntStateOf(initial.coerceIn(1, daysInMonth))
    }

    // Build real day-by-day aggregated data (1..daysInMonth)
    val dailyData = remember(transactions, currentYear, currentMonth, daysInMonth) {
        val filtered = transactions.filter { tx ->
            val cal = Calendar.getInstance().apply { timeInMillis = tx.dateMillis }
            cal.get(Calendar.YEAR) == currentYear && cal.get(Calendar.MONTH) == currentMonth
        }

        (1..daysInMonth).map { dayNum ->
            val dayCal = Calendar.getInstance().apply {
                set(Calendar.YEAR, currentYear)
                set(Calendar.MONTH, currentMonth)
                set(Calendar.DAY_OF_MONTH, dayNum)
                set(Calendar.HOUR_OF_DAY, 12)
            }
            val dayTxs = filtered.filter { tx ->
                val cal = Calendar.getInstance().apply { timeInMillis = tx.dateMillis }
                cal.get(Calendar.DAY_OF_MONTH) == dayNum
            }

            val inc = dayTxs.filter { it.type.equals("INCOME", ignoreCase = true) }.sumOf { it.amount }
            val exp = dayTxs.filter { it.type.equals("EXPENSE", ignoreCase = true) }.sumOf { it.amount }
            DayTrendData(
                dayNumber = dayNum,
                dateMillis = dayCal.timeInMillis,
                income = inc,
                expense = exp,
                net = inc - exp
            )
        }
    }

    val maxAmount = remember(dailyData) {
        val peak = dailyData.maxOfOrNull { maxOf(it.income, it.expense) } ?: 0.0
        if (peak > 0.0) peak else 1000.0
    }

    val selectedDayData = remember(dailyData, selectedDay) {
        dailyData.getOrNull(selectedDay - 1) ?: DayTrendData(selectedDay, System.currentTimeMillis(), 0.0, 0.0, 0.0)
    }

    val totalMonthIncome = remember(dailyData) { dailyData.sumOf { it.income } }
    val totalMonthExpense = remember(dailyData) { dailyData.sumOf { it.expense } }

    Column(modifier = modifier.fillMaxWidth()) {
        // Month Selector Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = {
                    if (currentMonth == 0) {
                        currentMonth = 11
                        currentYear -= 1
                    } else {
                        currentMonth -= 1
                    }
                },
                modifier = Modifier.size(36.dp).testTag("trend_prev_month")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Previous Month",
                    tint = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.size(18.dp)
                )
            }

            Text(
                text = "$monthName $currentYear",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.onSurface
            )

            IconButton(
                onClick = {
                    if (currentMonth == 11) {
                        currentMonth = 0
                        currentYear += 1
                    } else {
                        currentMonth += 1
                    }
                },
                modifier = Modifier.size(36.dp).testTag("trend_next_month")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = "Next Month",
                    tint = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Interactive Canvas Chart
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(daysInMonth) {
                        detectTapGestures { offset ->
                            val width = size.width
                            val stepX = width / daysInMonth
                            val clickedDay = ((offset.x / stepX).toInt() + 1).coerceIn(1, daysInMonth)
                            selectedDay = clickedDay
                        }
                    }
                    .pointerInput(daysInMonth) {
                        detectDragGestures { change, _ ->
                            val width = size.width
                            val stepX = width / daysInMonth
                            val draggedDay = ((change.position.x / stepX).toInt() + 1).coerceIn(1, daysInMonth)
                            selectedDay = draggedDay
                        }
                    }
            ) {
                val width = size.width
                val height = size.height - 24.dp.toPx()
                val stepX = width / daysInMonth

                // Background gridlines
                val gridColor = Color.Gray.copy(alpha = 0.15f)
                drawLine(gridColor, Offset(0f, 0f), Offset(width, 0f), strokeWidth = 1f)
                drawLine(gridColor, Offset(0f, height / 2), Offset(width, height / 2), strokeWidth = 1f)
                drawLine(gridColor, Offset(0f, height), Offset(width, height), strokeWidth = 1f)

                // Highlight selected day column
                val selX = (selectedDay - 1) * stepX
                drawRect(
                    color = EmeraldPrimary.copy(alpha = 0.08f),
                    topLeft = Offset(selX, 0f),
                    size = Size(stepX, height)
                )
                drawLine(
                    color = EmeraldPrimary.copy(alpha = 0.4f),
                    start = Offset(selX + stepX / 2, 0f),
                    end = Offset(selX + stepX / 2, height),
                    strokeWidth = 1.5f
                )

                // Draw actual bars for each day
                val barWidth = (stepX * 0.38f).coerceIn(2.dp.toPx(), 8.dp.toPx())

                dailyData.forEachIndexed { index, day ->
                    val centerX = index * stepX + stepX / 2

                    // Income Bar (Emerald)
                    if (day.income > 0) {
                        val barH = ((day.income / maxAmount) * height).toFloat().coerceIn(4f, height)
                        drawRoundRect(
                            color = IncomeGreen,
                            topLeft = Offset(centerX - barWidth - 1f, height - barH),
                            size = Size(barWidth, barH),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(2f, 2f)
                        )
                    }

                    // Expense Bar (Red)
                    if (day.expense > 0) {
                        val barH = ((day.expense / maxAmount) * height).toFloat().coerceIn(4f, height)
                        drawRoundRect(
                            color = ExpenseRed,
                            topLeft = Offset(centerX + 1f, height - barH),
                            size = Size(barWidth, barH),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(2f, 2f)
                        )
                    }
                }
            }

            // Interactive Tooltip Card
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                shadowElevation = 4.dp,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 4.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "$selectedDay $monthName",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Inc: Rs ${selectedDayData.income.toInt()}",
                        color = IncomeGreen,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Exp: Rs ${selectedDayData.expense.toInt()}",
                        color = ExpenseRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Net: Rs ${selectedDayData.net.toInt()}",
                        color = if (selectedDayData.net >= 0) IncomeGreen else ExpenseRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // X-Axis Day Number Labels (Showing sampled days: 1, 5, 10, 15, 20, 25, End)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            val sampledDays = listOf(1, 5, 10, 15, 20, 25, daysInMonth).distinct()
            sampledDays.forEach { d ->
                Text(
                    text = "D$d",
                    fontSize = 10.sp,
                    fontWeight = if (d == selectedDay) FontWeight.Bold else FontWeight.Normal,
                    color = if (d == selectedDay) EmeraldPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Legend & Month Totals
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(IncomeGreen))
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "Income (Rs ${totalMonthIncome.toInt()})", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(ExpenseRed))
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "Expense (Rs ${totalMonthExpense.toInt()})", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
