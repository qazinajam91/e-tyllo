package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.util.Log
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.example.data.service.ExtractedItemData
import com.example.data.service.ReceiptAiService
import com.example.ui.components.AdBannerCard
import com.example.ui.components.CameraCaptureDialog
import com.example.ui.theme.*
import com.example.ui.viewmodel.ETylloViewModel
import com.example.util.ReceiptImageUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

data class ExtractedReceiptItem(
    var name: String = "",
    var quantity: Double = 1.0,
    var unitPrice: Double = 0.0,
    var lineTotal: Double = 0.0
)

data class ReceiptCategory(
    val name: String,
    val icon: ImageVector,
    val color: Color
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImportReceiptScreen(
    viewModel: ETylloViewModel,
    tr: (String) -> String
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var pendingCameraUri by remember { mutableStateOf<Uri?>(null) }
    var showCameraView by remember { mutableStateOf(false) }

    var isAnalyzing by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Extracted / Form Data
    var hasExtractedData by remember { mutableStateOf(false) }
    var merchantName by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Shopping") }
    var totalAmountStr by remember { mutableStateOf("") }
    var subtotalAmount by remember { mutableDoubleStateOf(0.0) }
    var taxAmount by remember { mutableDoubleStateOf(0.0) }
    var discountAmount by remember { mutableDoubleStateOf(0.0) }
    var detectedCurrency by remember { mutableStateOf("PKR") }
    var receiptDateMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var lineItems by remember { mutableStateOf(listOf<ExtractedReceiptItem>()) }
    var saveIndividually by remember { mutableStateOf(false) }

    // Camera Permission Launcher
    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            showCameraView = true
        } else {
            // Fallback to system camera capture contract if direct CameraX preview permission not granted
            try {
                val (file, uri) = ReceiptImageUtils.createCameraImageUri(context)
                pendingCameraUri = uri
                errorMessage = "Camera permission was denied. You can grant camera permission in device settings or pick from Gallery."
            } catch (e: Exception) {
                errorMessage = "Camera permission required to capture receipts."
            }
        }
    }

    // System camera capture fallback
    val systemCameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success: Boolean ->
        if (success && pendingCameraUri != null) {
            val normalized = ReceiptImageUtils.persistOrientedImage(context, pendingCameraUri!!)
            selectedImageUri = normalized
            errorMessage = null
            hasExtractedData = false
        } else {
            errorMessage = "Photo capture was cancelled or failed. Please try again."
        }
    }

    // Gallery Picker Launcher
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val normalized = ReceiptImageUtils.persistOrientedImage(context, uri)
            selectedImageUri = normalized
            errorMessage = null
            hasExtractedData = false
        }
    }

    val categories = listOf(
        ReceiptCategory("Food", Icons.Default.Fastfood, Color(0xFFFF9800)),
        ReceiptCategory("Fuel", Icons.Default.LocalGasStation, Color(0xFF2196F3)),
        ReceiptCategory("Hotel", Icons.Default.Hotel, Color(0xFF9C27B0)),
        ReceiptCategory("Medicine", Icons.Default.Medication, Color(0xFFE91E63)),
        ReceiptCategory("Travel", Icons.Default.DirectionsCar, Color(0xFF00BCD4)),
        ReceiptCategory("Shopping", Icons.Default.ShoppingCart, Color(0xFF4CAF50)),
        ReceiptCategory("Bills", Icons.Default.Receipt, Color(0xFF607D8B))
    )

    fun decodeBitmap(): Bitmap? {
        return selectedImageUri?.let { uri ->
            ReceiptImageUtils.decodeOrientedBitmap(context, uri, maxDimension = 1280)
        }
    }

    fun analyzeReceipt() {
        val bitmap = decodeBitmap()
        if (bitmap == null) {
            Toast.makeText(context, "Please select or take a photo of a receipt first", Toast.LENGTH_SHORT).show()
            return
        }

        isAnalyzing = true
        errorMessage = null

        coroutineScope.launch {
            try {
                // Call Gemini / AI OCR extraction
                val result = withContext(Dispatchers.IO) {
                    ReceiptAiService.analyzeReceiptImage(context, bitmap)
                }

                merchantName = result.merchant.ifBlank { "Store Receipt" }
                val detectedCat = result.category
                selectedCategory = if (categories.any { it.name.equals(detectedCat, ignoreCase = true) }) {
                    categories.first { it.name.equals(detectedCat, ignoreCase = true) }.name
                } else {
                    "Shopping"
                }

                if (result.grandTotal > 0) {
                    val grandInt = result.grandTotal.toInt()
                    totalAmountStr = if (result.grandTotal % 1.0 == 0.0) grandInt.toString() else String.format(Locale.US, "%.2f", result.grandTotal)
                } else {
                    totalAmountStr = "0"
                }

                subtotalAmount = result.subtotal
                taxAmount = result.tax
                discountAmount = result.discount
                detectedCurrency = result.currency
                receiptDateMillis = result.dateMillis

                val itemsList = result.items.map { item ->
                    ExtractedReceiptItem(
                        name = item.name,
                        quantity = item.quantity,
                        unitPrice = item.unitPrice,
                        lineTotal = item.lineTotal
                    )
                }.toMutableList()

                if (itemsList.isEmpty() && result.grandTotal > 0) {
                    itemsList.add(
                        ExtractedReceiptItem(
                            name = merchantName,
                            quantity = 1.0,
                            unitPrice = result.grandTotal,
                            lineTotal = result.grandTotal
                        )
                    )
                }

                lineItems = itemsList
                hasExtractedData = true

                if (result.isSuccessful) {
                    Toast.makeText(context, "Receipt analyzed successfully! Review details below.", Toast.LENGTH_SHORT).show()
                } else {
                    errorMessage = "Receipt image loaded. ${result.rawJson}. You can edit all details and line items below."
                }
            } catch (e: Exception) {
                Log.e("ImportReceiptScreen", "AI receipt analysis failed", e)
                errorMessage = "Could not automatically read all fields (${e.localizedMessage ?: "Unknown"}). You can edit or enter receipt details manually below."
                hasExtractedData = true // Allow manual fallback
                if (merchantName.isBlank()) merchantName = "Store Receipt"
            } finally {
                isAnalyzing = false
            }
        }
    }

    fun saveExpenses() {
        val totalAmount = totalAmountStr.toDoubleOrNull() ?: 0.0
        val itemsSum = lineItems.sumOf { it.lineTotal }
        val finalAmount = if (totalAmount > 0) totalAmount else itemsSum

        if (finalAmount <= 0 && lineItems.isEmpty()) {
            Toast.makeText(context, "Please enter a valid amount", Toast.LENGTH_SHORT).show()
            return
        }

        val itemDataList = lineItems.map {
            ExtractedItemData(
                name = it.name.ifBlank { "Item" },
                quantity = it.quantity,
                unitPrice = it.unitPrice,
                lineTotal = if (it.lineTotal > 0) it.lineTotal else (it.quantity * it.unitPrice)
            )
        }

        viewModel.addReceiptExpense(
            amount = finalAmount,
            category = selectedCategory,
            dateMillis = receiptDateMillis,
            merchantName = merchantName.ifBlank { "Store Receipt" },
            subtotal = subtotalAmount,
            tax = taxAmount,
            discount = discountAmount,
            currency = detectedCurrency,
            items = itemDataList,
            imageUri = selectedImageUri?.toString(),
            saveIndividually = saveIndividually
        )

        if (saveIndividually && lineItems.isNotEmpty()) {
            Toast.makeText(context, "Saved ${lineItems.size} items as individual expenses!", Toast.LENGTH_LONG).show()
        } else {
            val amountDisplay = if (finalAmount % 1.0 == 0.0) finalAmount.toInt().toString() else String.format(Locale.US, "%.2f", finalAmount)
            Toast.makeText(context, "Saved expense of Rs $amountDisplay successfully!", Toast.LENGTH_LONG).show()
        }

        // Reset state
        selectedImageUri = null
        pendingCameraUri = null
        hasExtractedData = false
        merchantName = ""
        totalAmountStr = ""
        subtotalAmount = 0.0
        taxAmount = 0.0
        discountAmount = 0.0
        lineItems = emptyList()
    }

    // Camera View Overlay Dialog
    if (showCameraView) {
        CameraCaptureDialog(
            onDismissRequest = { showCameraView = false },
            onImageCaptured = { uri ->
                showCameraView = false
                selectedImageUri = uri
                errorMessage = null
                hasExtractedData = false
            },
            onError = { err ->
                showCameraView = false
                errorMessage = err
                // Fallback to system camera capture
                try {
                    val (file, uri) = ReceiptImageUtils.createCameraImageUri(context)
                    pendingCameraUri = uri
                    systemCameraLauncher.launch(uri)
                } catch (e: Exception) {
                    errorMessage = "Camera error: ${err}"
                }
            }
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header Card
        item {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 2.dp,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(EmeraldPrimary.copy(alpha = 0.15f), RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.DocumentScanner,
                                contentDescription = null,
                                tint = EmeraldPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Smart Receipt Scanner",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Snap a photo of your receipt to auto-fill expense details",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Buttons: Take Photo / Gallery
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                val hasPermission = ContextCompat.checkSelfPermission(
                                    context,
                                    Manifest.permission.CAMERA
                                ) == PackageManager.PERMISSION_GRANTED

                                if (hasPermission) {
                                    showCameraView = true
                                } else {
                                    cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("take_photo_button")
                        ) {
                            Icon(imageVector = Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Take Photo", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = { galleryLauncher.launch("image/*") },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("gallery_picker_button")
                        ) {
                            Icon(imageVector = Icons.Default.PhotoLibrary, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Gallery", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = EmeraldPrimary)
                        }
                    }
                }
            }
        }

        // Image Preview Card (if an image is selected/captured)
        if (selectedImageUri != null) {
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    shadowElevation = 2.dp,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Receipt Photo Selected",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            TextButton(
                                onClick = {
                                    selectedImageUri = null
                                    hasExtractedData = false
                                }
                            ) {
                                Text("Clear", fontSize = 12.sp, color = ExpenseRed)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Full Receipt Preview without artificial cropping or distortion
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 180.dp, max = 320.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant),
                            contentAlignment = Alignment.Center
                        ) {
                            AsyncImage(
                                model = selectedImageUri,
                                contentDescription = "Receipt Image Preview",
                                contentScale = ContentScale.Fit,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .wrapContentHeight()
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = { analyzeReceipt() },
                            enabled = !isAnalyzing,
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("scan_receipt_ai_button")
                        ) {
                            if (isAnalyzing) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Reading Receipt with AI...", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            } else {
                                Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, tint = Color.White)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Extract with AI", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                        }
                    }
                }
            }
        }

        // Error / Status message if any
        if (errorMessage != null) {
            item {
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = errorMessage ?: "",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }
        }

        // Extracted / Editable Form
        if (hasExtractedData || selectedImageUri == null) {
            item {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = MaterialTheme.colorScheme.surface,
                    shadowElevation = 2.dp,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Expense Details",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            if (hasExtractedData) {
                                Surface(
                                    color = EmeraldPrimary.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = "AI Extracted",
                                        color = EmeraldPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Merchant / Store Name
                        OutlinedTextField(
                            value = merchantName,
                            onValueChange = { merchantName = it },
                            label = { Text("Store / Merchant Name") },
                            leadingIcon = { Icon(Icons.Default.Storefront, contentDescription = null, tint = EmeraldPrimary) },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("receipt_merchant_input")
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Total Amount
                        OutlinedTextField(
                            value = totalAmountStr,
                            onValueChange = { totalAmountStr = it.filter { ch -> ch.isDigit() || ch == '.' } },
                            label = { Text("Total Amount (Rs)") },
                            leadingIcon = { Icon(Icons.Default.AttachMoney, contentDescription = null, tint = EmeraldPrimary) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("receipt_amount_input")
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Category Chips
                        Text(
                            text = "Category",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            categories.forEach { cat ->
                                val isSelected = selectedCategory.equals(cat.name, ignoreCase = true)
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { selectedCategory = cat.name },
                                    label = { Text(cat.name, fontSize = 12.sp) },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = cat.icon,
                                            contentDescription = null,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = EmeraldPrimary,
                                        selectedLabelColor = Color.White,
                                        selectedLeadingIconColor = Color.White
                                    )
                                )
                            }
                        }

                        // Line items section (Every product with Name, Quantity, Unit Price, Line Total)
                        Spacer(modifier = Modifier.height(16.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Purchased Items (${lineItems.size})",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                if (lineItems.isNotEmpty()) {
                                    val sum = lineItems.sumOf { it.lineTotal }
                                    val sumStr = if (sum % 1.0 == 0.0) sum.toInt().toString() else String.format(Locale.US, "%.2f", sum)
                                    Text(
                                        text = "Items Sum: Rs $sumStr",
                                        fontSize = 11.sp,
                                        color = EmeraldPrimary,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                            TextButton(
                                onClick = {
                                    lineItems = lineItems + ExtractedReceiptItem(
                                        name = "New Item ${lineItems.size + 1}",
                                        quantity = 1.0,
                                        unitPrice = 0.0,
                                        lineTotal = 0.0
                                    )
                                }
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Add Item", fontSize = 12.sp)
                            }
                        }

                        if (lineItems.isEmpty()) {
                            Text(
                                text = "No items extracted yet. Tap 'Add Item' to list individual products with quantities.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                        } else {
                            lineItems.forEachIndexed { index, item ->
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            OutlinedTextField(
                                                value = item.name,
                                                onValueChange = { newName ->
                                                    lineItems = lineItems.toMutableList().also {
                                                        it[index] = it[index].copy(name = newName)
                                                    }
                                                },
                                                placeholder = { Text("Product name") },
                                                label = { Text("Item ${index + 1}", fontSize = 10.sp) },
                                                singleLine = true,
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(10.dp)
                                            )
                                            IconButton(
                                                onClick = {
                                                    lineItems = lineItems.filterIndexed { i, _ -> i != index }
                                                },
                                                modifier = Modifier.size(36.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.DeleteOutline,
                                                    contentDescription = "Delete item",
                                                    tint = ExpenseRed,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(6.dp))

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            // Quantity
                                            OutlinedTextField(
                                                value = if (item.quantity % 1.0 == 0.0) item.quantity.toInt().toString() else item.quantity.toString(),
                                                onValueChange = { qStr ->
                                                    val qVal = qStr.toDoubleOrNull() ?: 1.0
                                                    val updatedTotal = if (item.unitPrice > 0) qVal * item.unitPrice else item.lineTotal
                                                    lineItems = lineItems.toMutableList().also {
                                                        it[index] = it[index].copy(quantity = qVal, lineTotal = updatedTotal)
                                                    }
                                                },
                                                label = { Text("Qty", fontSize = 10.sp) },
                                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                singleLine = true,
                                                modifier = Modifier.weight(0.8f),
                                                shape = RoundedCornerShape(10.dp)
                                            )

                                            // Unit Price
                                            OutlinedTextField(
                                                value = if (item.unitPrice > 0) {
                                                    if (item.unitPrice % 1.0 == 0.0) item.unitPrice.toInt().toString() else String.format(Locale.US, "%.2f", item.unitPrice)
                                                } else "",
                                                onValueChange = { pStr ->
                                                    val pVal = pStr.toDoubleOrNull() ?: 0.0
                                                    val updatedTotal = if (pVal > 0 && item.quantity > 0) pVal * item.quantity else item.lineTotal
                                                    lineItems = lineItems.toMutableList().also {
                                                        it[index] = it[index].copy(unitPrice = pVal, lineTotal = updatedTotal)
                                                    }
                                                },
                                                label = { Text("Unit Price", fontSize = 10.sp) },
                                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                singleLine = true,
                                                modifier = Modifier.weight(1.1f),
                                                shape = RoundedCornerShape(10.dp)
                                            )

                                            // Line Total
                                            OutlinedTextField(
                                                value = if (item.lineTotal > 0) {
                                                    if (item.lineTotal % 1.0 == 0.0) item.lineTotal.toInt().toString() else String.format(Locale.US, "%.2f", item.lineTotal)
                                                } else "",
                                                onValueChange = { tStr ->
                                                    val tVal = tStr.toDoubleOrNull() ?: 0.0
                                                    val updatedUnitPrice = if (tVal > 0 && item.quantity > 0) tVal / item.quantity else item.unitPrice
                                                    lineItems = lineItems.toMutableList().also {
                                                        it[index] = it[index].copy(lineTotal = tVal, unitPrice = updatedUnitPrice)
                                                    }
                                                },
                                                label = { Text("Line Total", fontSize = 10.sp) },
                                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                                singleLine = true,
                                                modifier = Modifier.weight(1.1f),
                                                shape = RoundedCornerShape(10.dp)
                                            )
                                        }
                                    }
                                }
                            }

                            // Sync total button if mismatch
                            val calculatedSum = lineItems.sumOf { it.lineTotal }
                            val typedTotal = totalAmountStr.toDoubleOrNull() ?: 0.0
                            if (calculatedSum > 0 && Math.abs(calculatedSum - typedTotal) > 0.01) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Items sum (Rs ${if (calculatedSum % 1.0 == 0.0) calculatedSum.toInt() else String.format(Locale.US, "%.2f", calculatedSum)}) differs from total.",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    TextButton(
                                        onClick = {
                                            totalAmountStr = if (calculatedSum % 1.0 == 0.0) calculatedSum.toInt().toString() else String.format(Locale.US, "%.2f", calculatedSum)
                                        }
                                    ) {
                                        Text("Sync Total", fontSize = 11.sp, color = EmeraldPrimary, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Option to save individual items
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { saveIndividually = !saveIndividually }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = saveIndividually,
                                    onCheckedChange = { saveIndividually = it }
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Save line items as separate individual expenses",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Save Button
                        Button(
                            onClick = { saveExpenses() },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("save_receipt_expense_button")
                        ) {
                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (saveIndividually && lineItems.isNotEmpty()) "Save ${lineItems.size} Expenses" else "Save Expense",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }

        item {
            AdBannerCard()
        }
    }
}
