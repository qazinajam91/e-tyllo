package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.TealPrimary

import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll

@Composable
fun BudgetScreen(
    monthlyExpense: Double,
    budgetAmount: Double,
    onSetBudgetClick: () -> Unit,
    tr: (String) -> String
) {
    val usedPct = if (budgetAmount > 0) (monthlyExpense / budgetAmount).coerceIn(0.0, 1.0).toFloat() else 0f
    val remaining = (budgetAmount - monthlyExpense).coerceAtLeast(0.0)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 2.dp,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = tr("budget_status"),
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    IconButton(onClick = onSetBudgetClick) {
                        Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit Budget", tint = TealPrimary)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(text = "Total Monthly Limit: Rs ${budgetAmount.toInt()}", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                Spacer(modifier = Modifier.height(12.dp))

                LinearProgressIndicator(
                    progress = { usedPct },
                    modifier = Modifier.fillMaxWidth().height(12.dp).clip(RoundedCornerShape(6.dp)),
                    color = if (usedPct > 0.85f) ExpenseRed else TealPrimary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(text = tr("used"), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(text = "Rs ${monthlyExpense.toInt()}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = ExpenseRed)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(text = tr("remaining"), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(text = "Rs ${remaining.toInt()}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TealPrimary)
                    }
                }
            }
        }
    }
}
