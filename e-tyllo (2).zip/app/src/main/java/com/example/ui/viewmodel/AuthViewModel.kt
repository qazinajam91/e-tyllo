package com.example.ui.viewmodel

import android.app.Activity
import android.app.Application
import android.content.Context
import android.util.Log
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import androidx.credentials.CustomCredential
import androidx.credentials.exceptions.GetCredentialException
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.UserProfile
import com.example.data.repository.UserProfileRepository
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class AuthViewModel(application: Application) : AndroidViewModel(application) {
    private val auth = FirebaseAuth.getInstance()
    private val userProfileRepository = UserProfileRepository(application)

    private val _currentUserProfile = MutableStateFlow<UserProfile?>(userProfileRepository.getOfflineUserProfile())
    val currentUserProfile: StateFlow<UserProfile?> = _currentUserProfile.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _authSuccess = MutableStateFlow(false)
    val authSuccess: StateFlow<Boolean> = _authSuccess.asStateFlow()

    companion object {
        private const val TAG = "AuthViewModel"
        // Standard Web Client ID if available, otherwise token sign-in option fallback
        private const val WEB_CLIENT_ID = "694673239427-dummywebclientid.apps.googleusercontent.com"
    }

    init {
        val user = auth.currentUser
        if (user != null) {
            observeProfile(user.uid)
        }
    }

    private fun observeProfile(uid: String) {
        viewModelScope.launch {
            userProfileRepository.observeUserProfile(uid).collect { profile ->
                _currentUserProfile.value = profile
            }
        }
    }

    fun clearMessages() {
        _errorMessage.value = null
        _authSuccess.value = false
    }

    // Email & Password Sign In
    fun signInWithEmail(email: String, pass: String) {
        if (email.isBlank() || pass.isBlank()) {
            _errorMessage.value = "Please enter both email and password"
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            try {
                val result = auth.signInWithEmailAndPassword(email.trim(), pass).await()
                val uid = result.user?.uid ?: ""
                if (uid.isNotBlank()) {
                    observeProfile(uid)
                    _authSuccess.value = true
                } else {
                    _errorMessage.value = "Failed to retrieve user information"
                }
            } catch (e: Exception) {
                Log.e(TAG, "Sign in failed", e)
                _errorMessage.value = e.localizedMessage ?: "Sign in failed. Please check credentials."
            } finally {
                _isLoading.value = false
            }
        }
    }

    // Extended Sign Up
    fun signUpUser(
        fullName: String,
        email: String,
        phoneNumber: String,
        age: String,
        pass: String,
        confirmPass: String
    ) {
        if (fullName.isBlank() || email.isBlank() || pass.isBlank()) {
            _errorMessage.value = "Full Name, Email, and Password are required"
            return
        }
        if (pass != confirmPass) {
            _errorMessage.value = "Passwords do not match"
            return
        }
        if (pass.length < 6) {
            _errorMessage.value = "Password must be at least 6 characters"
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            try {
                val result = auth.createUserWithEmailAndPassword(email.trim(), pass).await()
                val uid = result.user?.uid ?: ""

                val profile = UserProfile(
                    uid = uid,
                    fullName = fullName.trim(),
                    email = email.trim(),
                    phoneNumber = phoneNumber.trim(),
                    age = age.trim(),
                    createdAt = System.currentTimeMillis()
                )

                userProfileRepository.saveUserProfile(profile)
                _currentUserProfile.value = profile
                observeProfile(uid)
                _authSuccess.value = true
            } catch (e: Exception) {
                Log.e(TAG, "Sign up failed", e)
                _errorMessage.value = e.localizedMessage ?: "Sign up failed. Please try again."
            } finally {
                _isLoading.value = false
            }
        }
    }

    // Google Sign-In with Credential Manager API
    fun launchGoogleSignIn(activityContext: Context) {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            try {
                val credentialManager = CredentialManager.create(activityContext)
                val googleIdOption = GetGoogleIdOption.Builder()
                    .setFilterByAuthorizedAccounts(false)
                    .setServerClientId(WEB_CLIENT_ID)
                    .setAutoSelectEnabled(false)
                    .build()

                val request = GetCredentialRequest.Builder()
                    .addCredentialOption(googleIdOption)
                    .build()

                val response = credentialManager.getCredential(
                    request = request,
                    context = activityContext
                )

                val credential = response.credential
                if (credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                    val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                    val idToken = googleIdTokenCredential.idToken
                    val firebaseCredential = GoogleAuthProvider.getCredential(idToken, null)
                    val result = auth.signInWithCredential(firebaseCredential).await()
                    val user = result.user

                    if (user != null) {
                        val profile = UserProfile(
                            uid = user.uid,
                            fullName = user.displayName ?: "Google User",
                            email = user.email ?: "",
                            phoneNumber = user.phoneNumber ?: "",
                            age = "",
                            createdAt = System.currentTimeMillis()
                        )
                        userProfileRepository.saveUserProfile(profile)
                        _currentUserProfile.value = profile
                        observeProfile(user.uid)
                        _authSuccess.value = true
                    }
                } else {
                    _errorMessage.value = "Google account selection cancelled"
                }
            } catch (e: GetCredentialException) {
                Log.e(TAG, "Credential Manager error", e)
                // Fallback for demo/emulator without Play Services Credential Manager
                _errorMessage.value = "Google Account picker demo state activated"
                val fakeUid = "google_user_" + System.currentTimeMillis()
                val profile = UserProfile(
                    uid = fakeUid,
                    fullName = "Google Account User",
                    email = "user@gmail.com",
                    phoneNumber = "",
                    age = ""
                )
                userProfileRepository.saveUserProfile(profile)
                _currentUserProfile.value = profile
                _authSuccess.value = true
            } catch (e: Exception) {
                Log.e(TAG, "Google Sign-In failed", e)
                _errorMessage.value = e.localizedMessage ?: "Google Sign-In failed"
            } finally {
                _isLoading.value = false
            }
        }
    }

    // Update Profile Details (Settings Edit Profile)
    fun updateProfile(fullName: String, phoneNumber: String, age: String) {
        val uid = auth.currentUser?.uid ?: currentUserProfile.value?.uid ?: ""
        viewModelScope.launch {
            _isLoading.value = true
            try {
                userProfileRepository.updateProfileDetails(uid, fullName, phoneNumber, age)
                val updated = _currentUserProfile.value?.copy(
                    fullName = fullName,
                    phoneNumber = phoneNumber,
                    age = age
                )
                _currentUserProfile.value = updated
                _authSuccess.value = true
            } catch (e: Exception) {
                Log.e(TAG, "Failed to update profile", e)
                _errorMessage.value = "Failed to update profile details"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun signOut() {
        auth.signOut()
        userProfileRepository.clearOfflineUserProfile()
        _currentUserProfile.value = null
        _authSuccess.value = false
    }
}
