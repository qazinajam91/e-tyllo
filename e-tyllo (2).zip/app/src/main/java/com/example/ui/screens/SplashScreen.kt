package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.*
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(
    onSplashFinished: (isAuthenticated: Boolean, isNeedsVerification: Boolean) -> Unit,
    checkAuthStatus: suspend () -> Pair<Boolean, Boolean>
) {
    // Animation States
    val transitionState = remember { MutableTransitionState(false) }
    LaunchedEffect(Unit) {
        transitionState.targetState = true
    }

    val transition = updateTransition(transitionState, label = "SplashTransition")

    val scale by transition.animateFloat(
        transitionSpec = {
            spring(
                dampingRatio = Spring.DampingRatioMediumBouncy,
                stiffness = Spring.StiffnessLow
            )
        },
        label = "LogoScale"
    ) { state ->
        if (state) 1f else 0.4f
    }

    val alpha by transition.animateFloat(
        transitionSpec = {
            tween(durationMillis = 800, easing = FastOutSlowInEasing)
        },
        label = "LogoAlpha"
    ) { state ->
        if (state) 1f else 0f
    }

    // Glowing pulse animation for circular background aura
    val infiniteTransition = rememberInfiniteTransition(label = "GlowPulse")
    val glowScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.22f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "GlowScale"
    )
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.25f,
        targetValue = 0.7f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "GlowAlpha"
    )

    // Non-blocking async check & transition
    LaunchedEffect(Unit) {
        delay(1500) // Aesthetic presentation duration
        val (isAuth, isVerificationNeeded) = checkAuthStatus()
        onSplashFinished(isAuth, isVerificationNeeded)
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = DarkSlateNavy
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            // Background subtle ambient radial gradient
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(size.width / 2f, size.height / 2f)
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            DeepTeal.copy(alpha = 0.45f),
                            DarkSlateNavy.copy(alpha = 0.85f),
                            DarkSlateNavy
                        ),
                        center = center,
                        radius = size.width * 0.8f
                    ),
                    radius = size.width * 0.9f,
                    center = center
                )
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier
                    .scale(scale)
                    .alpha(alpha)
                    .padding(32.dp)
            ) {
                // Glowing Circular Container Encapsulating Logo
                Box(
                    modifier = Modifier.size(140.dp),
                    contentAlignment = Alignment.Center
                ) {
                    // Pulsing Outer Aura
                    Box(
                        modifier = Modifier
                            .size(136.dp)
                            .scale(glowScale)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    colors = listOf(
                                        EmeraldGreen.copy(alpha = glowAlpha),
                                        DeepTeal.copy(alpha = 0.15f),
                                        Color.Transparent
                                    )
                                )
                            )
                    )

                    // Outer Border Ring
                    Box(
                        modifier = Modifier
                            .size(112.dp)
                            .clip(RoundedCornerShape(32.dp))
                            .border(
                                width = 2.dp,
                                brush = Brush.linearGradient(
                                    listOf(EmeraldLight, DeepTealLight, Color.Transparent)
                                ),
                                shape = RoundedCornerShape(32.dp)
                            )
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(
                                        DeepTealDark,
                                        DarkSlateNavy
                                    )
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_etyllo_logo),
                            contentDescription = "E-Tyllo Splash Logo",
                            modifier = Modifier
                                .size(108.dp)
                                .clip(RoundedCornerShape(30.dp)),
                            contentScale = ContentScale.Crop
                        )
                    }
                }

                Spacer(modifier = Modifier.height(28.dp))

                // App Title with crisp tracking and typography
                Text(
                    text = "E-Tyllo",
                    fontSize = 38.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.SansSerif,
                    letterSpacing = 2.sp,
                    color = CleanWhite,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Modern Tagline
                Text(
                    text = "Daily Expense & Finance Management",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 0.5.sp,
                    color = SoftSlateGray,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(48.dp))

                // Subtle Developer Architecture Credit
                Surface(
                    shape = CircleShape,
                    color = DeepTeal.copy(alpha = 0.3f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldDark.copy(alpha = 0.4f)),
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "Designed & Engineered by Qazi Najam • Software Engineer",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = EmeraldLight.copy(alpha = 0.9f),
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}
