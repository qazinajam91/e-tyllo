package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dark Theme Palette
val DarkBackground = Color(0xFF090A0C)
val DarkSurface = Color(0xFF121619)
val DarkSurfaceVariant = Color(0xFF181C20)
val DarkBorder = Color(0xFF262C32)
val DarkTextPrimary = Color(0xFFFFFFFF)
val DarkTextSecondary = Color(0xFF94A3B8)

// Light Theme Palette
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightBorder = Color(0xFFE2E8F0)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF64748B)

// Shared Brand Colors
val EmeraldPrimary = Color(0xFF10B981)
val EmeraldDark = Color(0xFF059669)
val EmeraldLight = Color(0xFF34D399)
val EmeraldBg = Color(0xFF064E3B)

val IncomeGreen = Color(0xFF10B981)
val IncomeGreenBg = Color(0xFF022C22)

val ExpenseRed = Color(0xFFEF4444)
val ExpenseRedBg = Color(0xFF450A0A)

val LoanOrange = Color(0xFFF59E0B)
val LoanOrangeBg = Color(0xFF451A03)

val SavingsBlue = Color(0xFF3B82F6)
val SavingsBlueBg = Color(0xFF172554)

val ChartBlue = Color(0xFF3B82F6)
val ChartRed = Color(0xFFEF4444)
val ChartGreen = Color(0xFF10B981)
val ChartYellow = Color(0xFFEAB308)
