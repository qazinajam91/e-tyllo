package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LoanEntity
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun LoansScreen(
    youOweAmount: Double,
    owedToYouAmount: Double,
    pendingCount: Int,
    loansList: List<LoanEntity>,
    onAddLoanClick: () -> Unit,
    onAddLoanPayment: (Long, Double) -> Unit,
    onDeleteLoan: (Long) -> Unit,
    tr: (String) -> String
) {
    var selectedFilter by remember { mutableStateOf("All") }
    var selectedLoanForPayment by remember { mutableStateOf<LoanEntity?>(null) }

    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()) }

    val filteredLoans = loansList.filter { loan ->
        val isBorrowType = loan.type.contains("BORROW", true) || loan.type.contains("Took", true)
        when (selectedFilter) {
            "Borrowed" -> isBorrowType
            "Lend" -> !isBorrowType
            "Cleared" -> loan.isCleared
            else -> true
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Summary Cards
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(text = tr("you_owe"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "Rs${youOweAmount.toInt()}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = ExpenseRed)
                }
            }

            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(text = tr("owed_to_you"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "Rs${owedToYouAmount.toInt()}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = IncomeGreen)
                }
            }

            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(text = tr("pending_loans"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "$pendingCount", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = LoanOrange)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Orange Add Loan Button
        Button(
            onClick = onAddLoanClick,
            colors = ButtonDefaults.buttonColors(containerColor = LoanOrange),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("add_loan_button")
        ) {
            Icon(imageVector = Icons.Default.Add, contentDescription = null, tint = Color.White)
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = tr("add_loan"), fontWeight = FontWeight.Bold, color = Color.White, fontSize = 15.sp)
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Filter Pills
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            FilterChip(
                selected = selectedFilter == "All",
                onClick = { selectedFilter = "All" },
                label = { Text(tr("all")) }
            )
            FilterChip(
                selected = selectedFilter == "Borrowed",
                onClick = { selectedFilter = "Borrowed" },
                label = { Text(tr("borrowed")) }
            )
            FilterChip(
                selected = selectedFilter == "Lend",
                onClick = { selectedFilter = "Lend" },
                label = { Text(tr("lent")) }
            )
            FilterChip(
                selected = selectedFilter == "Cleared",
                onClick = { selectedFilter = "Cleared" },
                label = { Text("Cleared") }
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (filteredLoans.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize().weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "No loan records found", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(filteredLoans, key = { it.id }) { item ->
                    val isBorrow = item.type.contains("BORROW", true) || item.type.contains("Took", true)
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(CircleShape)
                                        .background(if (isBorrow) LoanOrangeBg else IncomeGreenBg),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (isBorrow) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                                        contentDescription = null,
                                        tint = if (isBorrow) LoanOrange else IncomeGreen,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = item.personName,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = if (isBorrow) "Took Loan (Borrowed)" else "Gave Loan (Lent)",
                                        fontSize = 12.sp,
                                        color = if (isBorrow) LoanOrange else IncomeGreen
                                    )
                                    if (item.dueDateMillis > 0) {
                                        Text(
                                            text = "Due: ${dateFormat.format(Date(item.dueDateMillis))}",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "Rs${item.amount.toInt()}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    if (item.paidAmount > 0) {
                                        Text(
                                            text = "Paid: Rs${item.paidAmount.toInt()}",
                                            fontSize = 11.sp,
                                            color = IncomeGreen
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.width(8.dp))

                                IconButton(
                                    onClick = { onDeleteLoan(item.id) },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Delete",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Status or Partial Payment Action
                            if (item.isCleared) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = IncomeGreenBg,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.CheckCircle,
                                            contentDescription = null,
                                            tint = IncomeGreen,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "LOAN CLEARED",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = IncomeGreen
                                        )
                                    }
                                }
                            } else {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Remaining: Rs${item.remainingAmount.toInt()}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = if (isBorrow) LoanOrange else IncomeGreen
                                    )

                                    OutlinedButton(
                                        onClick = { selectedLoanForPayment = item },
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                        modifier = Modifier.height(32.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Payment, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(text = "Record Payment", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (selectedLoanForPayment != null) {
        val loan = selectedLoanForPayment!!
        var paymentText by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { selectedLoanForPayment = null },
            title = {
                Text("Record Repayment for ${loan.personName}")
            },
            text = {
                Column {
                    Text("Total Loan: Rs ${loan.amount.toInt()}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Already Paid: Rs ${loan.paidAmount.toInt()}", fontSize = 12.sp, color = IncomeGreen)
                    Text("Remaining Balance: Rs ${loan.remainingAmount.toInt()}", fontSize = 13.sp, fontWeight = FontWeight.Bold)

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = paymentText,
                        onValueChange = { paymentText = it },
                        label = { Text("Payment Amount (Rs)") },
                        placeholder = { Text("e.g. ${loan.remainingAmount.toInt()}") },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val pAmt = paymentText.toDoubleOrNull() ?: 0.0
                        if (pAmt > 0) {
                            onAddLoanPayment(loan.id, pAmt)
                            selectedLoanForPayment = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                ) {
                    Text("Save Payment", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedLoanForPayment = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}
