package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TransactionEntity
import com.example.ui.components.AdBannerCard
import com.example.ui.components.DonutChart
import com.example.ui.components.PieSegment
import com.example.ui.components.WeeklyTrendChart
import com.example.ui.theme.*

@Composable
fun DashboardScreen(
    todayIncome: Double,
    todayExpense: Double,
    todaySavings: Double,
    todayNet: Double,
    monthlyIncome: Double,
    monthlyExpense: Double,
    monthlyNet: Double,
    budgetAmount: Double,
    recentTransactions: List<TransactionEntity>,
    onAddExpenseClick: () -> Unit,
    onAddIncomeClick: () -> Unit,
    onAddLoanClick: () -> Unit,
    onSetBudgetClick: () -> Unit,
    onViewAllTransactions: () -> Unit,
    tr: (String) -> String
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // TODAY Section Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = tr("today"),
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                letterSpacing = 1.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = EmeraldPrimary.copy(alpha = 0.15f)
            ) {
                Text(
                    text = tr("today_pulse"),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = EmeraldPrimary,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 2x2 Grid for TODAY
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Today's Income Card
                DashboardStatCard(
                    title = tr("todays_income"),
                    amount = "Rs${todayIncome.toInt()}",
                    icon = Icons.Default.ArrowUpward,
                    iconBg = IncomeGreenBg,
                    iconTint = IncomeGreen,
                    amountColor = IncomeGreen,
                    modifier = Modifier.weight(1f).testTag("todays_income_card")
                )

                // Today's Expense Card
                DashboardStatCard(
                    title = tr("todays_expense"),
                    amount = "Rs${todayExpense.toInt()}",
                    icon = Icons.Default.ArrowDownward,
                    iconBg = ExpenseRedBg,
                    iconTint = ExpenseRed,
                    amountColor = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f).testTag("todays_expense_card")
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Today's Savings Card
                DashboardStatCard(
                    title = tr("todays_savings"),
                    amount = "Rs${todaySavings.toInt()}",
                    icon = Icons.Default.Savings,
                    iconBg = SavingsBlueBg,
                    iconTint = SavingsBlue,
                    amountColor = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f).testTag("todays_savings_card")
                )

                // Profit / Loss Card
                DashboardStatCard(
                    title = tr("profit_loss"),
                    amount = "Rs${todayNet.toInt()}",
                    icon = Icons.Default.AccountBalanceWallet,
                    iconBg = EmeraldBg,
                    iconTint = EmeraldPrimary,
                    amountColor = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f).testTag("profit_loss_card")
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // THIS MONTH Section
        Text(
            text = tr("this_month"),
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            letterSpacing = 1.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(10.dp))

        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(16.dp).fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = tr("monthly_income"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "Rs${monthlyIncome.toInt()}", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = IncomeGreen)
                }
                Divider(modifier = Modifier.height(36.dp).width(1.dp), color = MaterialTheme.colorScheme.outline)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = tr("monthly_expense"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "Rs${monthlyExpense.toInt()}", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = ExpenseRed)
                }
                Divider(modifier = Modifier.height(36.dp).width(1.dp), color = MaterialTheme.colorScheme.outline)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = tr("monthly_net"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "Rs${monthlyNet.toInt()}", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // QUICK ACTIONS Section
        Text(
            text = tr("quick_actions"),
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            letterSpacing = 1.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Add Expense Button
            Button(
                onClick = onAddExpenseClick,
                colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f).testTag("quick_add_expense")
            ) {
                Text(text = tr("add_expense"), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }

            // Add Income Button
            Button(
                onClick = onAddIncomeClick,
                colors = ButtonDefaults.buttonColors(containerColor = SavingsBlue),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f).testTag("quick_add_income")
            ) {
                Text(text = tr("add_income"), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }

            // Add Loan Button
            Button(
                onClick = onAddLoanClick,
                colors = ButtonDefaults.buttonColors(containerColor = LoanOrange),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f).testTag("quick_add_loan")
            ) {
                Text(text = tr("add_loan"), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Budget Status Card
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = tr("budget_status"), fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
                        Text(text = tr("budget_monthly"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    TextButton(onClick = onSetBudgetClick) {
                        Text(text = tr("set_budget"), color = EmeraldPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                val usedPct = (monthlyExpense / budgetAmount).coerceIn(0.0, 1.0).toFloat()
                val remaining = (budgetAmount - monthlyExpense).coerceAtLeast(0.0)

                LinearProgressIndicator(
                    progress = { usedPct },
                    modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)),
                    color = if (usedPct > 0.85f) ExpenseRed else EmeraldPrimary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "${tr("used")}: Rs${monthlyExpense.toInt()}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(text = "${tr("remaining")}: Rs${remaining.toInt()}", fontSize = 12.sp, color = EmeraldPrimary, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Weekly Trend Chart Card
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = tr("weekly_trend"), fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
                Spacer(modifier = Modifier.height(12.dp))
                WeeklyTrendChart()
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Expense Breakdown Donut Chart Card
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = tr("expense_breakdown"), fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
                Spacer(modifier = Modifier.height(12.dp))
                DonutChart(
                    segments = listOf(
                        PieSegment("Travel", 230.0, ChartBlue),
                        PieSegment("Food", 170.0, ChartRed)
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // AdMob Native Ad Card
        AdBannerCard()

        Spacer(modifier = Modifier.height(20.dp))

        // Recent Activity / Transactions Feed
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = tr("recent_activity"),
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = tr("view_all"),
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = EmeraldPrimary,
                modifier = Modifier.clickable { onViewAllTransactions() }
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (recentTransactions.isEmpty()) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(modifier = Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
                    Text(text = "No recent transactions", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        } else {
            recentTransactions.take(5).forEach { tx ->
                TransactionListItem(transaction = tx)
                Spacer(modifier = Modifier.height(8.dp))
            }
        }

        Spacer(modifier = Modifier.height(30.dp))
    }
}

@Composable
fun DashboardStatCard(
    title: String,
    amount: String,
    icon: ImageVector,
    iconBg: Color,
    iconTint: Color,
    amountColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(iconBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = iconTint,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = title,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = amount,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = amountColor
            )
        }
    }
}

@Composable
fun TransactionListItem(transaction: TransactionEntity) {
    val isExpense = transaction.type == "EXPENSE"
    val icon = when (transaction.category) {
        "Travel" -> Icons.Default.DirectionsCar
        "Food" -> Icons.Default.Fastfood
        "Fuel" -> Icons.Default.LocalGasStation
        "Hotel" -> Icons.Default.Hotel
        "Medicine" -> Icons.Default.MedicalServices
        "Company Allowance", "Salary" -> Icons.Default.AccountBalanceWallet
        else -> Icons.Default.AttachMoney
    }

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(if (isExpense) ExpenseRedBg else IncomeGreenBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = transaction.category,
                    tint = if (isExpense) ExpenseRed else IncomeGreen,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = transaction.category,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                if (transaction.note.isNotBlank()) {
                    Text(
                        text = transaction.note,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Text(
                text = if (isExpense) "-Rs${transaction.amount.toInt()}" else "+Rs${transaction.amount.toInt()}",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = if (isExpense) ExpenseRed else IncomeGreen
            )
        }
    }
}
