package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TransactionEntity
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.IncomeGreen
import com.example.util.PdfGenerator
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    transactions: List<TransactionEntity>,
    tr: (String) -> String
) {
    val context = LocalContext.current
    val currentCal = remember { Calendar.getInstance() }

    var selectedMonthIndex by remember { mutableIntStateOf(currentCal.get(Calendar.MONTH)) }
    var selectedYear by remember { mutableIntStateOf(currentCal.get(Calendar.YEAR)) }

    var showMonthDropdown by remember { mutableStateOf(false) }
    var showYearDropdown by remember { mutableStateOf(false) }

    val monthsList = listOf(
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    )
    val yearsList = (2024..2030).toList()

    // Filter transactions by selected month & year
    val filteredTransactions = remember(transactions, selectedMonthIndex, selectedYear) {
        transactions.filter { tx ->
            val cal = Calendar.getInstance().apply { timeInMillis = tx.dateMillis }
            cal.get(Calendar.MONTH) == selectedMonthIndex && cal.get(Calendar.YEAR) == selectedYear
        }.sortedByDescending { it.dateMillis }
    }

    val totalIncome = filteredTransactions.filter { it.type.uppercase() == "INCOME" }.sumOf { it.amount }
    val totalExpense = filteredTransactions.filter { it.type.uppercase() == "EXPENSE" }.sumOf { it.amount }
    val netBalance = totalIncome - totalExpense

    // Group transactions by date string (e.g. "09 Aug 2026")
    val dayGrouped = remember(filteredTransactions) {
        val dateFormat = SimpleDateFormat("dd MMMM yyyy", Locale.getDefault())
        filteredTransactions.groupBy { dateFormat.format(Date(it.dateMillis)) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Month and Year Selectors
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Month Dropdown Box
            Box(modifier = Modifier.weight(1f)) {
                OutlinedButton(
                    onClick = { showMonthDropdown = true },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(monthsList[selectedMonthIndex], fontWeight = FontWeight.Bold)
                }
                DropdownMenu(
                    expanded = showMonthDropdown,
                    onDismissRequest = { showMonthDropdown = false }
                ) {
                    monthsList.forEachIndexed { index, name ->
                        DropdownMenuItem(
                            text = { Text(name) },
                            onClick = {
                                selectedMonthIndex = index
                                showMonthDropdown = false
                            }
                        )
                    }
                }
            }

            // Year Dropdown Box
            Box(modifier = Modifier.weight(0.8f)) {
                OutlinedButton(
                    onClick = { showYearDropdown = true },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("$selectedYear", fontWeight = FontWeight.Bold)
                }
                DropdownMenu(
                    expanded = showYearDropdown,
                    onDismissRequest = { showYearDropdown = false }
                ) {
                    yearsList.forEach { y ->
                        DropdownMenuItem(
                            text = { Text("$y") },
                            onClick = {
                                selectedYear = y
                                showYearDropdown = false
                            }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Monthly Summary Card
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "${monthsList[selectedMonthIndex]} $selectedYear Overview",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("Income", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("Rs ${totalIncome.toInt()}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = IncomeGreen)
                    }
                    Column {
                        Text("Expense", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("Rs ${totalExpense.toInt()}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = ExpenseRed)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Net Balance", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            text = "Rs ${netBalance.toInt()}",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (netBalance >= 0) IncomeGreen else ExpenseRed
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Export to PDF Button
        Button(
            onClick = {
                PdfGenerator.generateAndOpenReportPdf(
                    context = context,
                    monthName = monthsList[selectedMonthIndex],
                    year = selectedYear,
                    totalIncome = totalIncome,
                    totalExpense = totalExpense,
                    transactions = filteredTransactions
                )
            },
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Icon(imageVector = Icons.Default.PictureAsPdf, contentDescription = null, tint = Color.White)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Export to PDF Report", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 15.sp)
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Daily Logs Breakdown",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )

        Spacer(modifier = Modifier.height(8.dp))

        if (dayGrouped.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text("No entries recorded for ${monthsList[selectedMonthIndex]} $selectedYear", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                dayGrouped.forEach { (dateStr, txList) ->
                    val dayIncome = txList.filter { it.type.uppercase() == "INCOME" }.sumOf { it.amount }
                    val dayExpense = txList.filter { it.type.uppercase() == "EXPENSE" }.sumOf { it.amount }

                    item {
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surface,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = dateStr,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = EmeraldPrimary
                                    )
                                    Text(
                                        text = "Day Net: Rs ${(dayIncome - dayExpense).toInt()}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (dayIncome - dayExpense >= 0) IncomeGreen else ExpenseRed
                                    )
                                }

                                HorizontalDivider(
                                    modifier = Modifier.padding(vertical = 8.dp),
                                    color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                                )

                                txList.forEach { tx ->
                                    val isIncome = tx.type.uppercase() == "INCOME"
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = if (isIncome) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                                            contentDescription = null,
                                            tint = if (isIncome) IncomeGreen else ExpenseRed,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = tx.category,
                                                fontWeight = FontWeight.Medium,
                                                fontSize = 13.sp,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            if (tx.note.isNotBlank()) {
                                                Text(
                                                    text = tx.note,
                                                    fontSize = 11.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }
                                        Text(
                                            text = "${if (isIncome) "+" else "-"}Rs ${tx.amount.toInt()}",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = if (isIncome) IncomeGreen else ExpenseRed
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
