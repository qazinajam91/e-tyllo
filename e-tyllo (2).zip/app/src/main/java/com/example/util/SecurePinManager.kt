package com.example.util

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import android.util.Log
import java.security.MessageDigest
import java.security.SecureRandom

object SecurePinManager {
    private const val TAG = "SecurePinManager"
    private const val PREFS_NAME = "etyllo_secure_security_prefs"
    private const val KEY_PIN_ENABLED = "secure_pin_enabled"
    private const val KEY_PIN_HASH = "secure_pin_hash"
    private const val KEY_PIN_SALT = "secure_pin_salt"
    private const val KEY_LEGACY_PIN = "pin_code"

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    /**
     * Checks if PIN lock is enabled by the user.
     */
    fun isPinEnabled(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_PIN_ENABLED, false) && isPinSet(context)
    }

    /**
     * Checks if a valid secure PIN hash has been configured.
     */
    fun isPinSet(context: Context): Boolean {
        val hash = getPrefs(context).getString(KEY_PIN_HASH, null)
        val salt = getPrefs(context).getString(KEY_PIN_SALT, null)
        return !hash.isNullOrBlank() && !salt.isNullOrBlank()
    }

    /**
     * Securely sets a new 4-digit PIN.
     * Computes SHA-256 hash with a cryptographically secure random 16-byte salt.
     * Removes any legacy plaintext PIN.
     */
    fun setPin(context: Context, pin: String): Boolean {
        if (pin.length != 4 || !pin.all { it.isDigit() }) {
            Log.e(TAG, "Invalid PIN format. PIN must be exactly 4 digits.")
            return false
        }

        return try {
            val saltBytes = ByteArray(16)
            SecureRandom().nextBytes(saltBytes)
            val saltBase64 = Base64.encodeToString(saltBytes, Base64.NO_WRAP)

            val hashBytes = hashPinWithSalt(pin, saltBytes)
            val hashBase64 = Base64.encodeToString(hashBytes, Base64.NO_WRAP)

            getPrefs(context).edit()
                .putBoolean(KEY_PIN_ENABLED, true)
                .putString(KEY_PIN_HASH, hashBase64)
                .putString(KEY_PIN_SALT, saltBase64)
                .apply()

            // Remove legacy plaintext PIN from default prefs if present
            try {
                context.getSharedPreferences("etyllo_prefs", Context.MODE_PRIVATE)
                    .edit()
                    .remove(KEY_LEGACY_PIN)
                    .putBoolean("pin_enabled", true)
                    .apply()
            } catch (e: Exception) {
                Log.w(TAG, "Error cleaning legacy prefs", e)
            }

            Log.d(TAG, "PIN securely saved with salt.")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to securely save PIN", e)
            false
        }
    }

    /**
     * Verifies the entered PIN against the stored cryptographic hash.
     * Returns false for any incorrect PIN, random digits, or legacy "1234" bypass.
     */
    fun verifyPin(context: Context, enteredPin: String): Boolean {
        if (enteredPin.length != 4 || !enteredPin.all { it.isDigit() }) {
            return false
        }

        val prefs = getPrefs(context)
        val storedHashBase64 = prefs.getString(KEY_PIN_HASH, null) ?: return false
        val storedSaltBase64 = prefs.getString(KEY_PIN_SALT, null) ?: return false

        return try {
            val saltBytes = Base64.decode(storedSaltBase64, Base64.NO_WRAP)
            val expectedHashBytes = Base64.decode(storedHashBase64, Base64.NO_WRAP)
            val computedHashBytes = hashPinWithSalt(enteredPin, saltBytes)

            MessageDigest.isEqual(expectedHashBytes, computedHashBytes)
        } catch (e: Exception) {
            Log.e(TAG, "Error during PIN verification", e)
            false
        }
    }

    /**
     * Disables the PIN lock and clears stored PIN credentials.
     */
    fun disablePin(context: Context) {
        getPrefs(context).edit()
            .putBoolean(KEY_PIN_ENABLED, false)
            .remove(KEY_PIN_HASH)
            .remove(KEY_PIN_SALT)
            .apply()

        try {
            context.getSharedPreferences("etyllo_prefs", Context.MODE_PRIVATE)
                .edit()
                .remove(KEY_LEGACY_PIN)
                .putBoolean("pin_enabled", false)
                .apply()
        } catch (e: Exception) {
            Log.w(TAG, "Error clearing legacy prefs", e)
        }
        Log.d(TAG, "PIN lock disabled.")
    }

    /**
     * Hashes PIN with salt using SHA-256.
     */
    private fun hashPinWithSalt(pin: String, salt: ByteArray): ByteArray {
        val digest = MessageDigest.getInstance("SHA-256")
        digest.update(salt)
        return digest.digest(pin.toByteArray(Charsets.UTF_8))
    }
}
