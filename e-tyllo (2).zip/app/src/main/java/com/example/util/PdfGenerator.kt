package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.util.Log
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.model.TransactionEntity
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

object PdfGenerator {
    private const val TAG = "PdfGenerator"

    fun generateAndOpenReportPdf(
        context: Context,
        monthName: String,
        year: Int,
        totalIncome: Double,
        totalExpense: Double,
        transactions: List<TransactionEntity>
    ) {
        try {
            val pdfDocument = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // Standard A4 size
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            val titlePaint = Paint().apply {
                color = Color.parseColor("#10B981") // Emerald Green
                textSize = 20f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }

            val subtitlePaint = Paint().apply {
                color = Color.DKGRAY
                textSize = 12f
            }

            val headerBgPaint = Paint().apply {
                color = Color.parseColor("#F3F4F6")
            }

            val textBoldPaint = Paint().apply {
                color = Color.BLACK
                textSize = 11f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }

            val textPaint = Paint().apply {
                color = Color.BLACK
                textSize = 10f
            }

            val incomePaint = Paint().apply {
                color = Color.parseColor("#10B981")
                textSize = 10f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }

            val expensePaint = Paint().apply {
                color = Color.parseColor("#EF4444")
                textSize = 10f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }

            val linePaint = Paint().apply {
                color = Color.LTGRAY
                strokeWidth = 1f
            }

            var y = 40f

            // App Header & Title
            canvas.drawText("E TYLLO EXPENSE MANAGER", 40f, y, titlePaint)
            y += 18f
            canvas.drawText("Financial Report: $monthName $year", 40f, y, subtitlePaint)
            y += 14f
            val dateStr = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date())
            canvas.drawText("Generated on: $dateStr", 40f, y, subtitlePaint)
            y += 20f

            // Summary Card
            canvas.drawRect(40f, y, 555f, y + 60f, headerBgPaint)
            val net = totalIncome - totalExpense
            canvas.drawText("Monthly Summary", 50f, y + 20f, textBoldPaint)
            canvas.drawText("Total Income: Rs ${totalIncome.toInt()}", 50f, y + 42f, incomePaint)
            canvas.drawText("Total Expense: Rs ${totalExpense.toInt()}", 220f, y + 42f, expensePaint)
            val netColor = if (net >= 0) incomePaint else expensePaint
            canvas.drawText("Net Balance: Rs ${net.toInt()}", 410f, y + 42f, netColor)
            y += 80f

            // Table Header
            canvas.drawRect(40f, y, 555f, y + 25f, headerBgPaint)
            canvas.drawText("Date", 50f, y + 17f, textBoldPaint)
            canvas.drawText("Type", 140f, y + 17f, textBoldPaint)
            canvas.drawText("Category", 220f, y + 17f, textBoldPaint)
            canvas.drawText("Amount", 360f, y + 17f, textBoldPaint)
            canvas.drawText("Note", 450f, y + 17f, textBoldPaint)
            y += 30f

            val dateFormat = SimpleDateFormat("dd MMM", Locale.getDefault())

            // Transactions Rows
            for (tx in transactions) {
                if (y > 780f) {
                    // Page limit reached for single page quick export
                    canvas.drawText("...and more entries", 40f, y, subtitlePaint)
                    break
                }

                val dateFormatted = dateFormat.format(Date(tx.dateMillis))
                val isIncome = tx.type.uppercase() == "INCOME"

                canvas.drawText(dateFormatted, 50f, y, textPaint)
                canvas.drawText(if (isIncome) "Income" else "Expense", 140f, y, if (isIncome) incomePaint else expensePaint)
                canvas.drawText(tx.category.take(18), 220f, y, textPaint)
                canvas.drawText("Rs ${tx.amount.toInt()}", 360f, y, if (isIncome) incomePaint else expensePaint)
                canvas.drawText(tx.note.take(15), 450f, y, textPaint)

                y += 8f
                canvas.drawLine(40f, y, 555f, y, linePaint)
                y += 18f
            }

            pdfDocument.finishPage(page)

            val pdfFile = File(context.cacheDir, "E_Tyllo_Report_${monthName}_$year.pdf")
            val outputStream = FileOutputStream(pdfFile)
            pdfDocument.writeTo(outputStream)
            pdfDocument.close()
            outputStream.close()

            // Open or share PDF via Intent
            val contentUri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.provider",
                pdfFile
            )

            val shareIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(contentUri, "application/pdf")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            val chooser = Intent.createChooser(shareIntent, "Open PDF Report")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)

        } catch (e: Exception) {
            Log.e(TAG, "Error generating PDF report", e)
            Toast.makeText(context, "Failed to generate PDF: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }
}
