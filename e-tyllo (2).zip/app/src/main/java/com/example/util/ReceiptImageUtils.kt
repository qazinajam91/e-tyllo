package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.util.Base64
import android.util.Log
import androidx.core.content.FileProvider
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

object ReceiptImageUtils {
    private const val TAG = "ReceiptImageUtils"

    /**
     * Reads EXIF orientation from a content or file Uri.
     */
    fun getExifRotation(context: Context, uri: Uri): Int {
        var inputStream: InputStream? = null
        return try {
            inputStream = context.contentResolver.openInputStream(uri)
            if (inputStream != null) {
                val exif = ExifInterface(inputStream)
                when (exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270
                    else -> 0
                }
            } else 0
        } catch (e: Exception) {
            Log.w(TAG, "Could not determine EXIF rotation: ${e.message}")
            0
        } finally {
            try { inputStream?.close() } catch (_: Exception) {}
        }
    }

    /**
     * Rotates a bitmap by the given degrees if needed.
     */
    fun rotateBitmap(bitmap: Bitmap, degrees: Int): Bitmap {
        if (degrees == 0) return bitmap
        val matrix = Matrix().apply { postRotate(degrees.toFloat()) }
        return try {
            val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
            if (rotated != bitmap && !bitmap.isRecycled) {
                bitmap.recycle()
            }
            rotated
        } catch (e: Exception) {
            Log.e(TAG, "Failed to rotate bitmap", e)
            bitmap
        }
    }

    /**
     * Decodes a memory-safe bitmap from a Uri with proper EXIF orientation correction.
     * Computes inSampleSize to prevent OutOfMemoryError for huge photos.
     */
    fun decodeOrientedBitmap(context: Context, uri: Uri, maxDimension: Int = 1280): Bitmap? {
        return try {
            // First decode with inJustDecodeBounds to check dimensions
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, options)
            }

            if (options.outWidth <= 0 || options.outHeight <= 0) {
                return null
            }

            // Calculate optimal inSampleSize
            var sampleSize = 1
            val maxOut = maxOf(options.outWidth, options.outHeight)
            while (maxOut / sampleSize > maxDimension * 2) {
                sampleSize *= 2
            }

            val decodeOptions = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }

            val decodedBitmap = context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, decodeOptions)
            } ?: return null

            val rotation = getExifRotation(context, uri)
            val orientedBitmap = rotateBitmap(decodedBitmap, rotation)

            // Scale to maxDimension if needed
            scaleBitmapToMax(orientedBitmap, maxDimension)
        } catch (e: Exception) {
            Log.e(TAG, "Error decoding oriented bitmap", e)
            null
        }
    }

    /**
     * Scales bitmap to max dimension while preserving aspect ratio.
     */
    fun scaleBitmapToMax(bitmap: Bitmap, maxDim: Int): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        if (width <= maxDim && height <= maxDim) return bitmap

        val ratio = width.toFloat() / height.toFloat()
        val newWidth: Int
        val newHeight: Int
        if (width > height) {
            newWidth = maxDim
            newHeight = (maxDim / ratio).toInt().coerceAtLeast(1)
        } else {
            newHeight = maxDim
            newWidth = (maxDim * ratio).toInt().coerceAtLeast(1)
        }
        return try {
            val scaled = Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true)
            if (scaled != bitmap && !bitmap.isRecycled) {
                bitmap.recycle()
            }
            scaled
        } catch (e: Exception) {
            Log.e(TAG, "Error scaling bitmap", e)
            bitmap
        }
    }

    /**
     * Converts bitmap to Base64 string for AI OCR payloads.
     */
    fun bitmapToBase64(bitmap: Bitmap, quality: Int = 85): String {
        val outputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream)
        return Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
    }

    /**
     * Creates a new temporary file in cache for Camera capture with FileProvider Uri.
     */
    fun createCameraImageUri(context: Context): Pair<File, Uri> {
        val storageDir = File(context.cacheDir, "receipt_captures").apply { mkdirs() }
        val file = File(storageDir, "receipt_${System.currentTimeMillis()}.jpg")
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.provider",
            file
        )
        return Pair(file, uri)
    }

    /**
     * Safely normalizes and saves an image from any Uri to internal storage with correct EXIF orientation.
     */
    fun persistOrientedImage(context: Context, sourceUri: Uri): Uri {
        return try {
            val bitmap = decodeOrientedBitmap(context, sourceUri, maxDimension = 1920)
                ?: return sourceUri

            val storageDir = File(context.filesDir, "receipts").apply { mkdirs() }
            val file = File(storageDir, "receipt_${System.currentTimeMillis()}.jpg")
            FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
            }
            if (!bitmap.isRecycled) {
                bitmap.recycle()
            }
            Uri.fromFile(file)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to persist oriented image", e)
            sourceUri
        }
    }
}
