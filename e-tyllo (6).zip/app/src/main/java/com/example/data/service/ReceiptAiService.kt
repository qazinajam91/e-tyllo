package com.example.data.service

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import com.example.BuildConfig
import com.example.util.ReceiptImageUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

data class ExtractedReceiptData(
    val merchant: String,
    val dateStr: String,
    val dateMillis: Long,
    val category: String,
    val currency: String,
    val subtotal: Double,
    val tax: Double,
    val discount: Double,
    val grandTotal: Double,
    val items: List<ExtractedItemData>,
    val isSuccessful: Boolean,
    val rawJson: String = ""
)

data class ExtractedItemData(
    val name: String,
    val quantity: Double,
    val unitPrice: Double,
    val lineTotal: Double
)

object ReceiptAiService {
    private const val TAG = "ReceiptAiService"
    private const val MODEL_NAME = "gemini-2.5-flash"

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(45, TimeUnit.SECONDS)
            .readTimeout(45, TimeUnit.SECONDS)
            .writeTimeout(45, TimeUnit.SECONDS)
            .build()
    }

    /**
     * Sends the receipt image to Gemini AI and extracts structured data.
     */
    suspend fun analyzeReceiptImage(context: Context, bitmap: Bitmap): ExtractedReceiptData = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            Log.w(TAG, "Gemini API key is not set or placeholder. Falling back to structured parser template.")
            return@withContext buildFallbackResponse("Please configure your Gemini API Key in AI Studio Secrets for live AI OCR.")
        }

        try {
            // Memory safe scaled processing copy
            val scaledBitmap = ReceiptImageUtils.scaleBitmapToMax(bitmap, 1280)
            val base64Image = ReceiptImageUtils.bitmapToBase64(scaledBitmap, 85)

            val promptText = """
                You are an expert OCR receipt and invoice parser. Analyze this receipt image thoroughly and extract every detail into strict JSON.
                
                REQUIREMENTS:
                1. Extract the merchant/store name.
                2. Extract the transaction date (format: YYYY-MM-DD). If no year, assume current year.
                3. Classify into one category: Food, Fuel, Hotel, Medicine, Travel, Shopping, Bills, or General.
                4. Detect currency (e.g. PKR, Rs, USD, EUR, GBP).
                5. Extract subtotal, tax amount, and discount amount if present (use 0.0 if not listed).
                6. Extract the grand total / final amount paid.
                7. Extract ALL purchased products/line items. If there are 10 items, extract all 10 items.
                   For each item, extract:
                   - name: Full clear product/item title
                   - quantity: numerical quantity (e.g. 1.0, 2.0, 0.5, 3.0)
                   - unitPrice: individual price per unit
                   - lineTotal: total price for this line (quantity * unitPrice)
                8. Verify math: ensure lineTotal = quantity * unitPrice. If lineTotal exists but unitPrice is missing, calculate unitPrice = lineTotal / quantity.
                
                Respond ONLY with a valid JSON object matching this schema:
                {
                  "merchant": "Merchant Name",
                  "date": "YYYY-MM-DD",
                  "category": "Shopping",
                  "currency": "PKR",
                  "subtotal": 0.0,
                  "tax": 0.0,
                  "discount": 0.0,
                  "total": 0.0,
                  "items": [
                    {
                      "name": "Item 1",
                      "quantity": 1.0,
                      "unitPrice": 0.0,
                      "lineTotal": 0.0
                    }
                  ]
                }
            """.trimIndent()

            val requestJson = JSONObject().apply {
                val contentsArray = JSONArray()
                val contentObj = JSONObject()
                val partsArray = JSONArray()

                // Text part
                partsArray.put(JSONObject().apply {
                    put("text", promptText)
                })

                // Image part
                partsArray.put(JSONObject().apply {
                    val inlineData = JSONObject().apply {
                        put("mimeType", "image/jpeg")
                        put("data", base64Image)
                    }
                    put("inlineData", inlineData)
                })

                contentObj.put("parts", partsArray)
                contentsArray.put(contentObj)
                put("contents", contentsArray)

                val genConfig = JSONObject().apply {
                    put("temperature", 0.1)
                    put("responseMimeType", "application/json")
                }
                put("generationConfig", genConfig)
            }

            val url = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL_NAME:generateContent?key=$apiKey"
            val body = requestJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder()
                .url(url)
                .post(body)
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                Log.e(TAG, "Gemini API HTTP ${response.code}: $responseBody")
                return@withContext buildFallbackResponse("AI Service returned HTTP ${response.code}. You can enter details manually.")
            }

            parseGeminiApiResponse(responseBody)
        } catch (e: Exception) {
            Log.e(TAG, "Receipt AI analysis exception", e)
            buildFallbackResponse("OCR processing note: ${e.localizedMessage ?: "Could not complete network request"}.")
        }
    }

    private fun parseGeminiApiResponse(responseBody: String): ExtractedReceiptData {
        try {
            val rootJson = JSONObject(responseBody)
            val candidates = rootJson.optJSONArray("candidates") ?: return buildFallbackResponse("No candidates returned")
            if (candidates.length() == 0) return buildFallbackResponse("Empty candidates")

            val firstCandidate = candidates.getJSONObject(0)
            val content = firstCandidate.optJSONObject("content") ?: return buildFallbackResponse("No content in candidate")
            val parts = content.optJSONArray("parts") ?: return buildFallbackResponse("No parts in candidate")
            if (parts.length() == 0) return buildFallbackResponse("Empty parts")

            var rawText = parts.getJSONObject(0).optString("text", "")
            // Clean up possible code blocks
            rawText = rawText.trim()
            if (rawText.startsWith("```json")) {
                rawText = rawText.removePrefix("```json").trim()
            }
            if (rawText.startsWith("```")) {
                rawText = rawText.removePrefix("```").trim()
            }
            if (rawText.endsWith("```")) {
                rawText = rawText.removeSuffix("```").trim()
            }

            val parsedJson = JSONObject(rawText)
            val merchant = parsedJson.optString("merchant", "Store Receipt").ifBlank { "Store Receipt" }
            val dateStr = parsedJson.optString("date", "")
            val category = parsedJson.optString("category", "Shopping")
            val currency = parsedJson.optString("currency", "PKR")
            val subtotal = parsedJson.optDouble("subtotal", 0.0)
            val tax = parsedJson.optDouble("tax", 0.0)
            val discount = parsedJson.optDouble("discount", 0.0)
            val grandTotal = parsedJson.optDouble("total", 0.0)

            val parsedDateMillis = parseDateToMillis(dateStr)

            val itemsList = mutableListOf<ExtractedItemData>()
            val itemsArray = parsedJson.optJSONArray("items")
            if (itemsArray != null) {
                for (i in 0 until itemsArray.length()) {
                    val itemObj = itemsArray.optJSONObject(i) ?: continue
                    val name = itemObj.optString("name", "Item ${i + 1}").ifBlank { "Item ${i + 1}" }
                    var quantity = itemObj.optDouble("quantity", 1.0)
                    if (quantity <= 0.0) quantity = 1.0

                    var unitPrice = itemObj.optDouble("unitPrice", 0.0)
                    var lineTotal = itemObj.optDouble("lineTotal", 0.0)

                    if (lineTotal <= 0.0 && unitPrice > 0.0) {
                        lineTotal = quantity * unitPrice
                    } else if (unitPrice <= 0.0 && lineTotal > 0.0 && quantity > 0.0) {
                        unitPrice = lineTotal / quantity
                    }

                    itemsList.add(
                        ExtractedItemData(
                            name = name,
                            quantity = quantity,
                            unitPrice = unitPrice,
                            lineTotal = lineTotal
                        )
                    )
                }
            }

            // If grand total is 0 but items have line totals, sum them
            val finalGrandTotal = if (grandTotal > 0) {
                grandTotal
            } else {
                itemsList.sumOf { it.lineTotal }
            }

            return ExtractedReceiptData(
                merchant = merchant,
                dateStr = dateStr,
                dateMillis = parsedDateMillis,
                category = category,
                currency = currency,
                subtotal = subtotal,
                tax = tax,
                discount = discount,
                grandTotal = finalGrandTotal,
                items = itemsList,
                isSuccessful = true,
                rawJson = rawText
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing Gemini response JSON", e)
            return buildFallbackResponse("Response parsing error: ${e.message}")
        }
    }

    private fun parseDateToMillis(dateStr: String): Long {
        if (dateStr.isBlank()) return System.currentTimeMillis()
        val formats = listOf(
            SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()),
            SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()),
            SimpleDateFormat("MM/dd/yyyy", Locale.getDefault()),
            SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()),
            SimpleDateFormat("yyyy/MM/dd", Locale.getDefault())
        )
        for (format in formats) {
            try {
                val date = format.parse(dateStr)
                if (date != null) return date.time
            } catch (_: Exception) {}
        }
        return System.currentTimeMillis()
    }

    private fun buildFallbackResponse(reason: String): ExtractedReceiptData {
        return ExtractedReceiptData(
            merchant = "Store Receipt",
            dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
            dateMillis = System.currentTimeMillis(),
            category = "Shopping",
            currency = "PKR",
            subtotal = 0.0,
            tax = 0.0,
            discount = 0.0,
            grandTotal = 0.0,
            items = emptyList(),
            isSuccessful = false,
            rawJson = reason
        )
    }
}
