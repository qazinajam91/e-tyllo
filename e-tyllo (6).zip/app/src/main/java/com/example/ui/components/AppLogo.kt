package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.DeepTeal
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.EmeraldPrimary

@Composable
fun AppLogo(
    modifier: Modifier = Modifier,
    size: Dp = 72.dp,
    showText: Boolean = false,
    textFontSize: Int = 26
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(size)
                .clip(RoundedCornerShape(size * 0.22f))
                .border(
                    width = 1.5.dp,
                    brush = Brush.linearGradient(listOf(EmeraldPrimary, DeepTeal)),
                    shape = RoundedCornerShape(size * 0.22f)
                )
                .background(
                    brush = Brush.linearGradient(
                        colors = listOf(DeepTeal, EmeraldGreen)
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.ic_etyllo_logo),
                contentDescription = "E-Tyllo Logo",
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(size * 0.22f)),
                contentScale = ContentScale.Crop
            )
        }
        
        if (showText) {
            Spacer(modifier = Modifier.width(14.dp))
            Column {
                Text(
                    text = "E-Tyllo",
                    fontSize = textFontSize.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Smart Expense & Finance Manager",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
