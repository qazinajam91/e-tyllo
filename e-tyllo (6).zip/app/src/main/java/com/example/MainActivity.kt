package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.AppLanguage
import com.example.data.model.ThemeMode
import com.example.ui.components.AccountModalSheet
import com.example.ui.components.ModernBottomNavBar
import com.example.ui.components.NavDrawerContent
import com.example.ui.components.TopBar
import com.example.ui.screens.*
import com.example.ui.theme.ETylloTheme
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.viewmodel.AuthViewModel
import com.example.ads.AppOpenAdManager
import com.example.ads.InterstitialAdManager
import com.example.ui.viewmodel.ETylloViewModel
import com.google.android.gms.ads.MobileAds
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize Google Mobile Ads (AdMob) SDK and preload ads
        MobileAds.initialize(this) {
            AppOpenAdManager.getInstance().loadAd(this)
            InterstitialAdManager.getInstance().loadAd(this)
        }

        setContent {
            ETylloApp()
        }
    }
}

data class BottomNavItem(
    val route: String,
    val titleKey: String,
    val icon: ImageVector
)

@Composable
fun ETylloApp(
    viewModel: ETylloViewModel = viewModel(),
    authViewModel: AuthViewModel = viewModel()
) {
    val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
    val language by viewModel.language.collectAsStateWithLifecycle()
    val isPinEnabled by viewModel.isPinEnabled.collectAsStateWithLifecycle()
    val pinCode by viewModel.pinCode.collectAsStateWithLifecycle()
    val isBiometricsEnabled by viewModel.isBiometricsEnabled.collectAsStateWithLifecycle()

    val authUiState by authViewModel.uiState.collectAsStateWithLifecycle()
    val isGuest = authUiState.isGuest
    val currentUserProfile by authViewModel.currentUserProfile.collectAsStateWithLifecycle()
    val isRealSignedIn = currentUserProfile != null || viewModel.isSignedIn.collectAsStateWithLifecycle().value
    val hasAccess = isRealSignedIn || isGuest

    val userEmail = if (isGuest) "Guest User (Offline)" else (currentUserProfile?.email ?: viewModel.userEmail.collectAsStateWithLifecycle().value)
    val userName = if (isGuest) "Guest" else (currentUserProfile?.fullName?.ifBlank { viewModel.userName.collectAsStateWithLifecycle().value }
        ?: viewModel.userName.collectAsStateWithLifecycle().value)

    val todayIncome by viewModel.todayIncome.collectAsStateWithLifecycle()
    val todayExpense by viewModel.todayExpense.collectAsStateWithLifecycle()
    val todaySavings by viewModel.todaySavings.collectAsStateWithLifecycle()
    val todayNet by viewModel.todayNet.collectAsStateWithLifecycle()

    val monthlyIncome by viewModel.monthlyIncome.collectAsStateWithLifecycle()
    val monthlyExpense by viewModel.monthlyExpense.collectAsStateWithLifecycle()
    val monthlySavings by viewModel.monthlySavings.collectAsStateWithLifecycle()
    val monthlyNet by viewModel.monthlyNet.collectAsStateWithLifecycle()
    val allTimeExpense by viewModel.allTimeExpense.collectAsStateWithLifecycle()

    val budgetAmount by viewModel.budgetAmount.collectAsStateWithLifecycle()
    val transactions by viewModel.transactions.collectAsStateWithLifecycle()
    val loans by viewModel.loans.collectAsStateWithLifecycle()

    val expenseCategories by viewModel.expenseCategories.collectAsStateWithLifecycle()
    val incomeCategories by viewModel.incomeCategories.collectAsStateWithLifecycle()

    val youOweAmount by viewModel.youOweAmount.collectAsStateWithLifecycle()
    val owedToYouAmount by viewModel.owedToYouAmount.collectAsStateWithLifecycle()
    val pendingCount by viewModel.pendingLoansCount.collectAsStateWithLifecycle()

    var isUnlocked by remember { mutableStateOf(!isPinEnabled) }
    var isSplashVisible by remember { mutableStateOf(true) }

    // Theme Mode Boolean Determination
    val isDarkTheme = when (themeMode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    // Layout Direction (RTL for Urdu)
    val layoutDirection = if (language == AppLanguage.URDU) LayoutDirection.Rtl else LayoutDirection.Ltr

    ETylloTheme(darkTheme = isDarkTheme) {
        CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
            if (isSplashVisible) {
                SplashScreen(
                    onSplashFinished = { isAuth, _ ->
                        isSplashVisible = false
                        if (isAuth) {
                            viewModel.setSignedIn(true, userEmail, userName)
                        }
                    },
                    checkAuthStatus = {
                        val user = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser
                        if (user != null) {
                            try {
                                user.reload()
                                Pair(user.isEmailVerified, !user.isEmailVerified)
                            } catch (e: Exception) {
                                val cached = currentUserProfile
                                if (cached != null && cached.emailVerified) {
                                    Pair(true, false)
                                } else {
                                    Pair(false, true)
                                }
                            }
                        } else {
                            Pair(false, false)
                        }
                    }
                )
            } else if (!isUnlocked && isPinEnabled) {
                PinLockOverlay(
                    correctPin = pinCode,
                    onUnlocked = { isUnlocked = true }
                )
            } else if (!hasAccess) {
                LoginScreen(
                    authViewModel = authViewModel,
                    onSignInSuccess = {
                        if (!authViewModel.uiState.value.isGuest) {
                            viewModel.setSignedIn(true, userEmail, userName)
                        }
                    },
                    tr = { viewModel.string(it) }
                )
            } else {
                val drawerState = rememberDrawerState(DrawerValue.Closed)
                val scope = rememberCoroutineScope()
                var currentRoute by remember { mutableStateOf("dashboard") }

                var showAddExpenseModal by remember { mutableStateOf(false) }
                var showAddIncomeModal by remember { mutableStateOf(false) }
                var showAddLoanModal by remember { mutableStateOf(false) }
                var showSetBudgetModal by remember { mutableStateOf(false) }
                var showAccountModalSheet by remember { mutableStateOf(false) }

                val bottomNavItems = listOf(
                    BottomNavItem("dashboard", "dashboard", Icons.Default.GridView),
                    BottomNavItem("expenses", "expenses", Icons.Default.TrendingDown),
                    BottomNavItem("income", "income", Icons.Default.TrendingUp),
                    BottomNavItem("loans", "loans", Icons.Default.People),
                    BottomNavItem("budget", "budget", Icons.Default.AccountBalance)
                )

                ModalNavigationDrawer(
                    drawerState = drawerState,
                    drawerContent = {
                        ModalDrawerSheet {
                            NavDrawerContent(
                                currentRoute = currentRoute,
                                onRouteSelected = { route -> currentRoute = route },
                                onCloseDrawer = { scope.launch { drawerState.close() } },
                                onSignOut = {
                                    authViewModel.signOut()
                                    viewModel.signOut()
                                },
                                userName = userName,
                                userEmail = userEmail,
                                tr = { viewModel.string(it) }
                            )
                        }
                    }
                ) {
                    Scaffold(
                        topBar = {
                            TopBar(
                                title = viewModel.string(currentRoute),
                                onMenuClick = { scope.launch { drawerState.open() } },
                                onAccountClick = { showAccountModalSheet = true },
                                isSignedIn = isRealSignedIn,
                                userEmail = userEmail,
                                userName = userName
                            )
                        },
                        bottomBar = {
                            if (bottomNavItems.any { it.route == currentRoute }) {
                                ModernBottomNavBar(
                                    items = bottomNavItems,
                                    currentRoute = currentRoute,
                                    onItemSelected = { currentRoute = it },
                                    tr = { viewModel.string(it) }
                                )
                            }
                        }
                    ) { innerPadding ->
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            if (isGuest) {
                                Surface(
                                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.8f),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 16.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Info,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "Guest Mode: Local only",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Medium,
                                                color = MaterialTheme.colorScheme.onPrimaryContainer
                                            )
                                        }
                                        TextButton(
                                            onClick = {
                                                authViewModel.signOut()
                                                viewModel.signOut()
                                            },
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                                        ) {
                                            Text(
                                                text = "Sign In",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    }
                                }
                            }

                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                            ) {
                            when (currentRoute) {
                                "dashboard" -> DashboardScreen(
                                    todayIncome = todayIncome,
                                    todayExpense = todayExpense,
                                    todaySavings = todaySavings,
                                    todayNet = todayNet,
                                    monthlyIncome = monthlyIncome,
                                    monthlyExpense = monthlyExpense,
                                    monthlyNet = monthlyNet,
                                    budgetAmount = budgetAmount,
                                    recentTransactions = transactions,
                                    onAddExpenseClick = { showAddExpenseModal = true },
                                    onAddIncomeClick = { showAddIncomeModal = true },
                                    onAddLoanClick = { showAddLoanModal = true },
                                    onSetBudgetClick = { showSetBudgetModal = true },
                                    onViewAllTransactions = { currentRoute = "expenses" },
                                    tr = { viewModel.string(it) }
                                )
                                "expenses" -> ExpensesScreen(
                                    monthlyExpense = monthlyExpense,
                                    allTimeExpense = allTimeExpense,
                                    expensesList = transactions,
                                    onAddExpenseClick = { showAddExpenseModal = true },
                                    onDeleteExpense = { viewModel.deleteTransaction(it) },
                                    tr = { viewModel.string(it) }
                                )
                                "income" -> IncomeScreen(
                                    monthlyIncome = monthlyIncome,
                                    incomeList = transactions,
                                    onAddIncomeClick = { showAddIncomeModal = true },
                                    onDeleteIncome = { viewModel.deleteTransaction(it) },
                                    tr = { viewModel.string(it) }
                                )
                                "loans" -> LoansScreen(
                                    youOweAmount = youOweAmount,
                                    owedToYouAmount = owedToYouAmount,
                                    pendingCount = pendingCount,
                                    loansList = loans,
                                    onAddLoanClick = { showAddLoanModal = true },
                                    onAddLoanPayment = { id, pAmt -> viewModel.addLoanPayment(id, pAmt) },
                                    onDeleteLoan = { viewModel.deleteLoan(it) },
                                    tr = { viewModel.string(it) }
                                )
                                "budget" -> BudgetScreen(
                                    monthlyExpense = monthlyExpense,
                                    budgetAmount = budgetAmount,
                                    onSetBudgetClick = { showSetBudgetModal = true },
                                    tr = { viewModel.string(it) }
                                )
                                "reports" -> ReportsScreen(
                                    transactions = transactions,
                                    loans = loans,
                                    tr = { viewModel.string(it) }
                                )
                                "analytics" -> AnalyticsScreen(
                                    transactions = transactions,
                                    tr = { viewModel.string(it) }
                                )
                                "import", "export" -> ImportReceiptScreen(
                                    viewModel = viewModel,
                                    tr = { viewModel.string(it) }
                                )
                                "settings" -> SettingsScreen(
                                    themeMode = themeMode,
                                    onToggleTheme = { isDark -> viewModel.toggleTheme(isDark) },
                                    language = language,
                                    onToggleLanguage = { viewModel.toggleLanguage() },
                                    isPinEnabled = isPinEnabled,
                                    onTogglePin = { enabled -> viewModel.togglePinLock(enabled) },
                                    isBiometricsEnabled = isBiometricsEnabled,
                                    onToggleBiometrics = { enabled -> viewModel.toggleBiometrics(enabled) },
                                    currentUserProfile = currentUserProfile,
                                    onUpdateProfile = { name, phone, age ->
                                        authViewModel.updateProfile(name, phone, age)
                                    },
                                    onNavigateAbout = { currentRoute = "about" },
                                    onNavigateFeedback = { currentRoute = "feedback" },
                                    onSignOut = {
                                        authViewModel.signOut()
                                        viewModel.signOut()
                                    },
                                    tr = { viewModel.string(it) }
                                )
                                "about" -> AboutScreen(
                                    tr = { viewModel.string(it) }
                                )
                                "feedback" -> FeedbackScreen(
                                    tr = { viewModel.string(it) }
                                )
                            }
                        }
                    }

                        // Dialog Modals
                        if (showAddExpenseModal) {
                            AddExpenseDialog(
                                categoryList = expenseCategories,
                                onAddCustomCategory = { newCat -> viewModel.addCategory(newCat, "EXPENSE") },
                                onDismiss = { showAddExpenseModal = false },
                                onSave = { amt, cat, date, note ->
                                    viewModel.addExpense(amt, cat, date, note)
                                }
                            )
                        }

                        if (showAddIncomeModal) {
                            AddIncomeDialog(
                                categoryList = incomeCategories,
                                onAddCustomCategory = { newCat -> viewModel.addCategory(newCat, "INCOME") },
                                onDismiss = { showAddIncomeModal = false },
                                onSave = { amt, cat, date, note ->
                                    viewModel.addIncome(amt, cat, date, note)
                                }
                            )
                        }

                        if (showAddLoanModal) {
                            AddLoanDialog(
                                onDismiss = { showAddLoanModal = false },
                                onSave = { type, person, amt, date, dueDate, note ->
                                    viewModel.addLoan(type, person, amt, date, dueDate, note)
                                }
                            )
                        }

                        if (showSetBudgetModal) {
                            SetBudgetDialog(
                                currentBudget = budgetAmount,
                                onDismiss = { showSetBudgetModal = false },
                                onSave = { amt ->
                                    viewModel.updateBudget(amt)
                                }
                            )
                        }

                        if (showAccountModalSheet) {
                            AccountModalSheet(
                                onDismiss = { showAccountModalSheet = false },
                                userEmail = userEmail,
                                userName = userName,
                                isSignedIn = isRealSignedIn,
                                onSignInWithGoogle = {
                                    authViewModel.signOut()
                                    viewModel.signOut()
                                },
                                onSignOut = {
                                    authViewModel.signOut()
                                    viewModel.signOut()
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
