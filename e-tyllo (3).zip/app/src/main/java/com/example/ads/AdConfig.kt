package com.example.ads

/**
 * Centralized AdMob Configuration for E Tyllo.
 * 
 * Set [USE_TEST_ADS] = false when building for release with production AdMob units.
 * Replace the production IDs with your approved AdMob ad unit IDs from your AdMob console.
 */
object AdConfig {
    // Switch to false when publishing to Google Play Store
    const val USE_TEST_ADS = true

    // ==========================================
    // GOOGLE OFFICIAL TEST AD UNIT IDS
    // ==========================================
    private const val TEST_APP_OPEN_ID = "ca-app-pub-3940256099942544/9257395921"
    private const val TEST_BANNER_ID = "ca-app-pub-3940256099942544/6300978111"
    private const val TEST_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712"
    private const val TEST_NATIVE_ID = "ca-app-pub-3940256099942544/2247696110"

    // ==========================================
    // PRODUCTION ADMOB AD UNIT IDS
    // Insert your real AdMob unit IDs below:
    // Publisher Account: ca-app-pub-9568951418141073
    // ==========================================
    private const val PROD_APP_OPEN_ID = "ca-app-pub-9568951418141073/YOUR_APP_OPEN_ID" // "App open"
    private const val PROD_BANNER_ID = "ca-app-pub-9568951418141073/YOUR_BANNER_ID"     // "Daily Expense"
    private const val PROD_INTERSTITIAL_ID = "ca-app-pub-9568951418141073/YOUR_INTERSTITIAL_ID" // "Fulladd"
    private const val PROD_NATIVE_ID = "ca-app-pub-9568951418141073/YOUR_NATIVE_ID"     // "NativeAdd"

    // Public getters resolving either test or production ID
    val appOpenAdUnitId: String
        get() = if (USE_TEST_ADS) TEST_APP_OPEN_ID else PROD_APP_OPEN_ID

    val bannerAdUnitId: String
        get() = if (USE_TEST_ADS) TEST_BANNER_ID else PROD_BANNER_ID

    val interstitialAdUnitId: String
        get() = if (USE_TEST_ADS) TEST_INTERSTITIAL_ID else PROD_INTERSTITIAL_ID

    val nativeAdUnitId: String
        get() = if (USE_TEST_ADS) TEST_NATIVE_ID else PROD_NATIVE_ID
}
