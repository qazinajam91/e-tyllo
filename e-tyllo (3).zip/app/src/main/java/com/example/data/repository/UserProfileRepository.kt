package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.data.model.UserProfile
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class UserProfileRepository(context: Context) {
    private val firestore: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }
    private val prefs = context.getSharedPreferences("user_profile_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val TAG = "UserProfileRepo"
    }

    fun observeUserProfile(uid: String): Flow<UserProfile?> = callbackFlow {
        if (uid.isBlank()) {
            trySend(getOfflineUserProfile())
            close()
            return@callbackFlow
        }

        val docRef = firestore.collection("users").document(uid)
        val listener = docRef.addSnapshotListener { snapshot, error ->
            if (error != null) {
                Log.e(TAG, "Error listening to user profile changes", error)
                trySend(getOfflineUserProfile())
                return@addSnapshotListener
            }

            if (snapshot != null && snapshot.exists()) {
                val profile = snapshot.toObject(UserProfile::class.java)
                if (profile != null) {
                    saveOfflineUserProfile(profile)
                    trySend(profile)
                } else {
                    trySend(getOfflineUserProfile())
                }
            } else {
                trySend(getOfflineUserProfile())
            }
        }

        awaitClose { listener.remove() }
    }

    suspend fun saveUserProfile(profile: UserProfile): Boolean {
        saveOfflineUserProfile(profile)
        if (profile.uid.isBlank()) return true

        return try {
            firestore.collection("users").document(profile.uid)
                .set(profile, SetOptions.merge())
                .await()
            Log.d(TAG, "User profile saved successfully to Firestore: ${profile.uid}")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to save user profile to Firestore, saved offline", e)
            false
        }
    }

    suspend fun updateEmailVerificationStatus(uid: String, isVerified: Boolean): Boolean {
        val currentOffline = getOfflineUserProfile()
        if (currentOffline != null && currentOffline.uid == uid) {
            saveOfflineUserProfile(currentOffline.copy(emailVerified = isVerified))
        }

        if (uid.isBlank()) return true

        return try {
            firestore.collection("users").document(uid)
                .update("emailVerified", isVerified)
                .await()
            Log.d(TAG, "User email verification updated in Firestore: $isVerified")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to update email verification status in Firestore", e)
            false
        }
    }

    suspend fun updateProfileDetails(uid: String, fullName: String, phoneNumber: String, age: String): Boolean {
        val currentOffline = getOfflineUserProfile()
        val updated = currentOffline?.copy(
            name = fullName,
            fullName = fullName,
            phoneNumber = phoneNumber,
            age = age
        ) ?: UserProfile(uid = uid, name = fullName, fullName = fullName, phoneNumber = phoneNumber, age = age)

        saveOfflineUserProfile(updated)

        if (uid.isBlank()) return true

        return try {
            firestore.collection("users").document(uid)
                .update(
                    mapOf(
                        "name" to fullName,
                        "fullName" to fullName,
                        "phoneNumber" to phoneNumber,
                        "age" to age
                    )
                )
                .await()
            Log.d(TAG, "User profile updated successfully in Firestore")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to update profile in Firestore, changes saved locally", e)
            false
        }
    }

    fun saveOfflineUserProfile(profile: UserProfile) {
        prefs.edit()
            .putString("uid", profile.uid)
            .putString("name", profile.name.ifBlank { profile.fullName })
            .putString("fullName", profile.fullName.ifBlank { profile.name })
            .putString("email", profile.email)
            .putString("phoneNumber", profile.phoneNumber)
            .putString("age", profile.age)
            .putString("registrationDate", profile.registrationDate)
            .putBoolean("emailVerified", profile.emailVerified)
            .putLong("createdAt", profile.createdAt)
            .apply()
    }

    fun getOfflineUserProfile(): UserProfile? {
        val uid = prefs.getString("uid", "") ?: ""
        val email = prefs.getString("email", "") ?: ""
        if (uid.isBlank() && email.isBlank()) return null

        val name = prefs.getString("name", "") ?: ""
        val fullName = prefs.getString("fullName", name) ?: name

        return UserProfile(
            uid = uid,
            name = name,
            fullName = fullName,
            email = email,
            phoneNumber = prefs.getString("phoneNumber", "") ?: "",
            age = prefs.getString("age", "") ?: "",
            registrationDate = prefs.getString("registrationDate", "") ?: "",
            emailVerified = prefs.getBoolean("emailVerified", false),
            createdAt = prefs.getLong("createdAt", System.currentTimeMillis())
        )
    }

    fun clearOfflineUserProfile() {
        prefs.edit().clear().apply()
    }
}

