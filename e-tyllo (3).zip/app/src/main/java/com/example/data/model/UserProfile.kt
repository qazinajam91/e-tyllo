package com.example.data.model

data class UserProfile(
    val uid: String = "",
    val name: String = "",
    val fullName: String = "",
    val email: String = "",
    val phoneNumber: String = "",
    val age: String = "",
    val registrationDate: String = "",
    val emailVerified: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
) {
    val displayName: String
        get() = name.ifBlank { fullName.ifBlank { "E Tyllo User" } }
}
