package com.example.ui.viewmodel

sealed class AuthStatus {
    object Idle : AuthStatus()
    object Loading : AuthStatus()
    object NeedsVerification : AuthStatus()
    object Authenticated : AuthStatus()
    data class Error(val message: String) : AuthStatus()
}

data class AuthUiState(
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val successMessage: String? = null,
    val isNeedsVerification: Boolean = false,
    val isAuthenticated: Boolean = false,
    val userEmail: String = "",
    val isPasswordResetSent: Boolean = false
)
