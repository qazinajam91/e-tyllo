package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.util.Log
import android.util.Patterns
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialException
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.UserProfile
import com.example.data.repository.UserProfileRepository
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AuthViewModel(application: Application) : AndroidViewModel(application) {
    private val auth = FirebaseAuth.getInstance()
    private val userProfileRepository = UserProfileRepository(application)

    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    private val _currentUserProfile = MutableStateFlow<UserProfile?>(userProfileRepository.getOfflineUserProfile())
    val currentUserProfile: StateFlow<UserProfile?> = _currentUserProfile.asStateFlow()

    companion object {
        private const val TAG = "AuthViewModel"
        private const val WEB_CLIENT_ID = "694673239427-dummywebclientid.apps.googleusercontent.com"
    }

    init {
        checkInitialSession()
    }

    fun checkInitialSession() {
        val user = auth.currentUser
        if (user != null) {
            val email = user.email ?: ""
            _uiState.update { it.copy(userEmail = email) }
            viewModelScope.launch {
                try {
                    user.reload().await()
                    if (user.isEmailVerified) {
                        _uiState.update {
                            it.copy(
                                isAuthenticated = true,
                                isNeedsVerification = false
                            )
                        }
                        observeProfile(user.uid)
                    } else {
                        _uiState.update {
                            it.copy(
                                isAuthenticated = false,
                                isNeedsVerification = true
                            )
                        }
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Initial session check error", e)
                    // If offline, check cached profile state
                    val cached = userProfileRepository.getOfflineUserProfile()
                    if (cached != null && cached.emailVerified) {
                        _uiState.update { it.copy(isAuthenticated = true, isNeedsVerification = false) }
                        _currentUserProfile.value = cached
                    } else {
                        _uiState.update { it.copy(isAuthenticated = false, isNeedsVerification = true) }
                    }
                }
            }
        } else {
            _uiState.update {
                it.copy(
                    isAuthenticated = false,
                    isNeedsVerification = false
                )
            }
        }
    }

    private fun observeProfile(uid: String) {
        viewModelScope.launch {
            userProfileRepository.observeUserProfile(uid).collect { profile ->
                _currentUserProfile.value = profile
            }
        }
    }

    fun clearMessages() {
        _uiState.update {
            it.copy(
                errorMessage = null,
                successMessage = null,
                isPasswordResetSent = false
            )
        }
    }

    // Email & Password Sign Up
    fun signUp(
        fullName: String,
        email: String,
        age: String,
        pass: String,
        confirmPass: String
    ) {
        val cleanName = fullName.trim()
        val cleanEmail = email.trim()
        val cleanAge = age.trim()

        if (cleanName.isBlank()) {
            _uiState.update { it.copy(errorMessage = "Please enter your full name.") }
            return
        }
        if (cleanEmail.isBlank() || !Patterns.EMAIL_ADDRESS.matcher(cleanEmail).matches()) {
            _uiState.update { it.copy(errorMessage = "Please enter a valid email address.") }
            return
        }
        if (cleanAge.isBlank()) {
            _uiState.update { it.copy(errorMessage = "Please enter your age.") }
            return
        }
        val ageNum = cleanAge.toIntOrNull()
        if (ageNum == null || ageNum < 10 || ageNum > 120) {
            _uiState.update { it.copy(errorMessage = "Please enter a realistic age (10-120).") }
            return
        }
        if (pass.isBlank()) {
            _uiState.update { it.copy(errorMessage = "Please enter a password.") }
            return
        }
        if (pass.length < 6) {
            _uiState.update { it.copy(errorMessage = "Password must be at least 6 characters long.") }
            return
        }
        if (pass != confirmPass) {
            _uiState.update { it.copy(errorMessage = "Passwords do not match.") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null, successMessage = null) }
            try {
                val result = auth.createUserWithEmailAndPassword(cleanEmail, pass).await()
                val user = result.user
                val uid = user?.uid ?: ""

                if (uid.isNotBlank() && user != null) {
                    val dateFormatted = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

                    val profile = UserProfile(
                        uid = uid,
                        name = cleanName,
                        fullName = cleanName,
                        email = cleanEmail,
                        age = cleanAge,
                        registrationDate = dateFormatted,
                        emailVerified = false,
                        createdAt = System.currentTimeMillis()
                    )

                    // Send verification email
                    try {
                        user.sendEmailVerification().await()
                    } catch (evErr: Exception) {
                        Log.w(TAG, "sendEmailVerification non-fatal error", evErr)
                    }

                    // Save profile to Firestore
                    userProfileRepository.saveUserProfile(profile)
                    _currentUserProfile.value = profile

                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            isNeedsVerification = true,
                            isAuthenticated = false,
                            userEmail = cleanEmail,
                            successMessage = "Account created! A verification email has been sent."
                        )
                    }
                } else {
                    _uiState.update { it.copy(isLoading = false, errorMessage = "Failed to create account. Please try again.") }
                }
            } catch (e: FirebaseAuthUserCollisionException) {
                _uiState.update { it.copy(isLoading = false, errorMessage = "This email is already registered. Please sign in instead.") }
            } catch (e: FirebaseAuthInvalidCredentialsException) {
                _uiState.update { it.copy(isLoading = false, errorMessage = "Invalid email format or credentials.") }
            } catch (e: Exception) {
                Log.e(TAG, "Sign up failed", e)
                _uiState.update { it.copy(isLoading = false, errorMessage = e.localizedMessage ?: "Sign up failed. Please try again.") }
            }
        }
    }

    // Email & Password Sign In
    fun signIn(email: String, pass: String) {
        val cleanEmail = email.trim()
        if (cleanEmail.isBlank()) {
            _uiState.update { it.copy(errorMessage = "Please enter your email address.") }
            return
        }
        if (pass.isBlank()) {
            _uiState.update { it.copy(errorMessage = "Please enter your password.") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null, successMessage = null) }
            try {
                val result = auth.signInWithEmailAndPassword(cleanEmail, pass).await()
                val user = result.user
                if (user != null) {
                    user.reload().await()
                    val isVerified = user.isEmailVerified

                    if (isVerified) {
                        userProfileRepository.updateEmailVerificationStatus(user.uid, true)
                        observeProfile(user.uid)
                        _uiState.update {
                            it.copy(
                                isLoading = false,
                                isAuthenticated = true,
                                isNeedsVerification = false,
                                userEmail = cleanEmail
                            )
                        }
                    } else {
                        _uiState.update {
                            it.copy(
                                isLoading = false,
                                isAuthenticated = false,
                                isNeedsVerification = true,
                                userEmail = cleanEmail,
                                errorMessage = "Please verify your email before accessing the dashboard."
                            )
                        }
                    }
                } else {
                    _uiState.update { it.copy(isLoading = false, errorMessage = "Unable to sign in. User not found.") }
                }
            } catch (e: FirebaseAuthInvalidCredentialsException) {
                _uiState.update { it.copy(isLoading = false, errorMessage = "Invalid email or password.") }
            } catch (e: Exception) {
                Log.e(TAG, "Sign in error", e)
                _uiState.update { it.copy(isLoading = false, errorMessage = e.localizedMessage ?: "Sign in failed. Please check credentials.") }
            }
        }
    }

    // Check Email Verification status
    fun checkEmailVerification() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null, successMessage = null) }
            try {
                val user = auth.currentUser
                if (user == null) {
                    _uiState.update { it.copy(isLoading = false, errorMessage = "Session expired. Please sign in again.") }
                    return@launch
                }

                user.reload().await()
                if (user.isEmailVerified) {
                    userProfileRepository.updateEmailVerificationStatus(user.uid, true)
                    observeProfile(user.uid)
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            isAuthenticated = true,
                            isNeedsVerification = false,
                            successMessage = "Email verified! Welcome to E Tyllo."
                        )
                    }
                } else {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            errorMessage = "Your email is not verified yet. Please check your inbox (and spam) for the verification link."
                        )
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Check verification error", e)
                _uiState.update { it.copy(isLoading = false, errorMessage = "Unable to check verification status: ${e.localizedMessage}") }
            }
        }
    }

    // Resend Verification Email
    fun sendVerificationEmail() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null, successMessage = null) }
            try {
                val user = auth.currentUser
                if (user != null) {
                    user.sendEmailVerification().await()
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            successMessage = "Verification email sent to ${user.email}. Please check your inbox and spam folder."
                        )
                    }
                } else {
                    _uiState.update { it.copy(isLoading = false, errorMessage = "No active session found. Please sign in again.") }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Resend verification error", e)
                _uiState.update { it.copy(isLoading = false, errorMessage = "Failed to send verification email: ${e.localizedMessage}") }
            }
        }
    }

    // Forgot Password / Password Reset Email
    fun resetPassword(email: String) {
        val cleanEmail = email.trim()
        if (cleanEmail.isBlank() || !Patterns.EMAIL_ADDRESS.matcher(cleanEmail).matches()) {
            _uiState.update { it.copy(errorMessage = "Please enter a valid email address for password reset.") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null, successMessage = null) }
            try {
                auth.sendPasswordResetEmail(cleanEmail).await()
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        isPasswordResetSent = true,
                        successMessage = "Password reset link sent to $cleanEmail. Check your inbox."
                    )
                }
            } catch (e: Exception) {
                Log.e(TAG, "Reset password error", e)
                _uiState.update { it.copy(isLoading = false, errorMessage = e.localizedMessage ?: "Failed to send reset email.") }
            }
        }
    }

    // Google Sign-In with Credential Manager API
    fun launchGoogleSignIn(activityContext: Context) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null, successMessage = null) }
            try {
                val credentialManager = CredentialManager.create(activityContext)
                val googleIdOption = GetGoogleIdOption.Builder()
                    .setFilterByAuthorizedAccounts(false)
                    .setServerClientId(WEB_CLIENT_ID)
                    .setAutoSelectEnabled(false)
                    .build()

                val request = GetCredentialRequest.Builder()
                    .addCredentialOption(googleIdOption)
                    .build()

                val response = credentialManager.getCredential(
                    request = request,
                    context = activityContext
                )

                val credential = response.credential
                if (credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                    val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                    val idToken = googleIdTokenCredential.idToken
                    val firebaseCredential = GoogleAuthProvider.getCredential(idToken, null)
                    val result = auth.signInWithCredential(firebaseCredential).await()
                    val user = result.user

                    if (user != null) {
                        val dateFormatted = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                        val profile = UserProfile(
                            uid = user.uid,
                            name = user.displayName ?: "Google User",
                            fullName = user.displayName ?: "Google User",
                            email = user.email ?: "",
                            phoneNumber = user.phoneNumber ?: "",
                            age = "",
                            registrationDate = dateFormatted,
                            emailVerified = true,
                            createdAt = System.currentTimeMillis()
                        )
                        userProfileRepository.saveUserProfile(profile)
                        _currentUserProfile.value = profile
                        observeProfile(user.uid)
                        _uiState.update {
                            it.copy(
                                isLoading = false,
                                isAuthenticated = true,
                                isNeedsVerification = false,
                                userEmail = user.email ?: ""
                            )
                        }
                    }
                } else {
                    _uiState.update { it.copy(isLoading = false, errorMessage = "Google sign-in cancelled.") }
                }
            } catch (e: GetCredentialException) {
                Log.w(TAG, "Credential Manager error", e)
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        errorMessage = "Google Play Services sign-in cancelled or unavailable. Please use Email/Password."
                    )
                }
            } catch (e: Exception) {
                Log.e(TAG, "Google Sign-In failed", e)
                _uiState.update { it.copy(isLoading = false, errorMessage = e.localizedMessage ?: "Google Sign-In failed.") }
            }
        }
    }

    // Update Profile Details
    fun updateProfile(fullName: String, phoneNumber: String, age: String) {
        val uid = auth.currentUser?.uid ?: currentUserProfile.value?.uid ?: ""
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            try {
                userProfileRepository.updateProfileDetails(uid, fullName, phoneNumber, age)
                val updated = _currentUserProfile.value?.copy(
                    name = fullName,
                    fullName = fullName,
                    phoneNumber = phoneNumber,
                    age = age
                )
                _currentUserProfile.value = updated
                _uiState.update { it.copy(isLoading = false, successMessage = "Profile updated successfully.") }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to update profile", e)
                _uiState.update { it.copy(isLoading = false, errorMessage = "Failed to update profile details.") }
            }
        }
    }

    fun signOut() {
        try {
            auth.signOut()
        } catch (e: Exception) {
            Log.e(TAG, "Sign out error", e)
        }
        userProfileRepository.clearOfflineUserProfile()
        _currentUserProfile.value = null
        _uiState.update {
            AuthUiState(
                isAuthenticated = false,
                isNeedsVerification = false,
                userEmail = ""
            )
        }
    }
}
