package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Modern High-Contrast "E Tyllo" Color System

// Primary Brand Accents
val TealPrimary = Color(0xFF0D9488) // Teal 600
val TealDark = Color(0xFF0F766E)    // Teal 700
val TealLight = Color(0xFF14B8A6)   // Teal 500
val TealContainerLight = Color(0xFFCCFBF1) // Teal 100
val TealContainerDark = Color(0xFF134E4A)  // Teal 900

// Backwards compatibility aliases
val EmeraldPrimary = TealPrimary
val EmeraldDark = TealDark
val EmeraldLight = TealLight
val EmeraldBg = TealContainerDark

val RoseCoral = Color(0xFFE07A5F)
val RoseCoralBg = Color(0xFFFDF0ED)

val SlatePrimary = Color(0xFF0F172A)   // Slate 900
val SlateSecondary = Color(0xFF64748B) // Slate 500

val TextFieldBgLight = Color(0xFFF1F5F9) // Slate 100
val TextFieldBgDark = Color(0xFF334155)  // Slate 700

// Dark Theme Surface System
val DarkBackground = Color(0xFF0F172A)     // Slate 900
val DarkSurface = Color(0xFF1E293B)        // Slate 800
val DarkSurfaceVariant = Color(0xFF334155) // Slate 700
val DarkBorder = Color(0xFF334155)         // Slate 700
val DarkTextPrimary = Color(0xFFF8FAFC)    // Slate 50
val DarkTextSecondary = Color(0xFF94A3B8)  // Slate 400

// Light Theme Surface System
val LightBackground = Color(0xFFF8FAF9)     // Soft clean off-white
val LightSurface = Color(0xFFFFFFFF)        // Pure white cards
val LightSurfaceVariant = Color(0xFFF1F5F9) // Subtle tint
val LightBorder = Color(0xFFE2E8F0)        // Slate 200 border
val LightTextPrimary = Color(0xFF0F172A)   // High contrast Slate 900
val LightTextSecondary = Color(0xFF64748B) // High contrast Slate 500

// High Contrast Semantic Colors
val IncomeGreen = Color(0xFF059669)     // Emerald 600
val SoftMintGreenBg = Color(0xFFECFDF5) // Emerald 50
val SoftMintGreenBgDark = Color(0xFF064E3B)

val ExpenseRed = Color(0xFFDC2626)     // Red 600
val SoftSalmonRedBg = Color(0xFFFEF2F2) // Red 50
val SoftSalmonRedBgDark = Color(0xFF7F1D1D)

val LoanOrange = Color(0xFFD97706)     // Amber 600
val SoftOrangeBg = Color(0xFFFFFBEB)   // Amber 50
val SoftOrangeBgDark = Color(0xFF78350F)

val SavingsBlue = Color(0xFF2563EB)    // Blue 600
val SoftBlueBg = Color(0xFFF0F9FF)     // Blue 50
val SoftBlueBgDark = Color(0xFF0C4A6E)

// Chart Colors
val ChartBlue = Color(0xFF2563EB)
val ChartGreen = Color(0xFF059669)
val ChartRed = Color(0xFFDC2626)
val ChartYellow = Color(0xFFD97706)
