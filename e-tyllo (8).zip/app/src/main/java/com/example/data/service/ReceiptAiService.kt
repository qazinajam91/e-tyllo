package com.example.data.service

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import com.example.util.NetworkUtils
import com.example.util.ReceiptImageUtils
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.GenerativeBackend
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
import java.util.regex.Pattern

data class ExtractedReceiptData(
    val merchant: String,
    val dateStr: String,
    val dateMillis: Long,
    val category: String,
    val currency: String,
    val subtotal: Double,
    val tax: Double,
    val discount: Double,
    val grandTotal: Double,
    val items: List<ExtractedItemData>,
    val isSuccessful: Boolean,
    val rawJson: String = ""
)

data class ExtractedItemData(
    val name: String,
    val quantity: Double,
    val unitPrice: Double,
    val lineTotal: Double
)

object ReceiptAiService {
    private const val TAG = "ReceiptAiService"
    private const val MODEL_NAME = "gemini-2.5-flash"

    /**
     * Extracts structured receipt data from the given bitmap.
     * 1. If online, uses Firebase AI Logic (Gemini multimodal image analysis) as the primary engine.
     * 2. If offline, does not call Firebase AI repeatedly; immediately runs Google ML Kit on-device
     *    Text Recognition with heuristic parsing and informs the user.
     * 3. Never requires or prompts the user for any external API keys.
     */
    suspend fun analyzeReceiptImage(context: Context, bitmap: Bitmap): ExtractedReceiptData = withContext(Dispatchers.IO) {
        val scaledBitmap = ReceiptImageUtils.scaleBitmapToMax(bitmap, 1280)
        val isOnline = NetworkUtils.isNetworkAvailable(context)

        if (isOnline) {
            try {
                Log.d(TAG, "Attempting Firebase AI Logic receipt extraction...")
                val result = extractWithFirebaseAi(scaledBitmap)
                if (result.isSuccessful && (result.grandTotal > 0 || result.items.isNotEmpty())) {
                    Log.d(TAG, "Firebase AI extraction succeeded with ${result.items.size} items")
                    return@withContext result
                }
            } catch (e: Exception) {
                Log.w(TAG, "Firebase AI Logic extraction failed, falling back to ML Kit: ${e.message}")
            }
        } else {
            Log.d(TAG, "Device is offline. Using local Google ML Kit OCR.")
        }

        // On-device ML Kit text recognition fallback
        try {
            Log.d(TAG, "Running on-device Google ML Kit Text Recognition...")
            val ocrResult = extractWithMlKit(scaledBitmap, isOnline)
            return@withContext ocrResult
        } catch (e: Exception) {
            Log.e(TAG, "ML Kit OCR extraction failed", e)
            val msg = if (!isOnline) {
                "No internet connection. Offline receipt scanning is available; please verify the extracted details."
            } else {
                "OCR note: ${e.localizedMessage ?: "Could not complete text recognition"}"
            }
            return@withContext buildFallbackResponse(msg)
        }
    }

    /**
     * Firebase AI Logic (Gemini multimodal extraction).
     */
    private suspend fun extractWithFirebaseAi(bitmap: Bitmap): ExtractedReceiptData {
        val promptText = """
            You are an expert OCR receipt and invoice parser. Analyze this receipt/invoice image and extract every detail into strict JSON.
            
            EXTRACTION INSTRUCTIONS:
            1. Merchant Name:
               - Extract the primary business / brand / restaurant / store name from the header.
               - Strictly DO NOT use FBR invoice number, NTN, STRN, PNTN, POS ID, Table #, Cashier, or Date as the merchant name.
            2. Date:
               - Extract the transaction date in YYYY-MM-DD format. If no year is printed, assume the current year.
            3. Category:
               - Classify into one of: Food, Fuel, Hotel, Medicine, Travel, Shopping, Bills, or General.
            4. Currency:
               - Detect currency (e.g. PKR, Rs, USD, EUR, GBP, AED, SAR). Default to PKR if not specified.
            5. Totals:
               - Extract subtotal, tax amount (GST / VAT / Sales Tax), discount, and grand total / net payable.
            6. Line Items (CRITICAL):
               - Extract ALL individual purchased products/line items with their exact names, quantities, unit prices, and line totals.
               - Preserve distinct item names (e.g., "White Chicken Boti", "Chicken Seekh Kebab (Plate)", "Woven Bag").
               - Properly parse comma-separated numbers (e.g., 1,075 -> 1075.0, 2,150 -> 2150.0).
               - Ensure quantity * unitPrice = lineTotal.
            
            Respond ONLY with a valid JSON object matching this schema:
            {
              "merchant": "Merchant Name",
              "invoiceNumber": "FBR-12345",
              "date": "YYYY-MM-DD",
              "category": "Food",
              "currency": "PKR",
              "subtotal": 0.0,
              "tax": 0.0,
              "discount": 0.0,
              "total": 0.0,
              "items": [
                {
                  "name": "Item Name",
                  "quantity": 1.0,
                  "unitPrice": 0.0,
                  "lineTotal": 0.0
                }
              ]
            }
        """.trimIndent()

        val generativeModel = Firebase.ai(backend = GenerativeBackend.googleAI()).generativeModel(
            modelName = MODEL_NAME,
            generationConfig = generationConfig {
                temperature = 0.1f
                responseMimeType = "application/json"
            }
        )

        val inputContent = content {
            image(bitmap)
            text(promptText)
        }

        val response = generativeModel.generateContent(inputContent)
        val responseText = response.text ?: throw IllegalStateException("Empty response from AI")
        return parseGeminiApiResponse(responseText)
    }

    /**
     * Local On-Device Google ML Kit Text Recognition with intelligent spatial & columnar heuristic parser.
     */
    private suspend fun extractWithMlKit(bitmap: Bitmap, isOnline: Boolean): ExtractedReceiptData {
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val image = InputImage.fromBitmap(bitmap, 0)
        val visionText = recognizer.process(image).await()

        val fullText = visionText.text
        val textBlocks = visionText.textBlocks

        val rawLines = mutableListOf<String>()
        for (block in textBlocks) {
            for (line in block.lines) {
                val t = line.text.trim()
                if (t.isNotBlank()) {
                    rawLines.add(t)
                }
            }
        }

        if (rawLines.isEmpty()) {
            val offlineMsg = if (!isOnline) {
                "No internet connection. Offline receipt scanning is available; please verify the extracted details."
            } else {
                "No readable text detected in receipt photo."
            }
            return buildFallbackResponse(offlineMsg)
        }

        // 1. Merchant Detection
        var merchant = "Store Receipt"
        val ignoredMerchantKeywords = listOf(
            "receipt", "tax invoice", "cash memo", "invoice", "welcome", "tel", "phone",
            "date", "time", "cashier", "pos", "bill", "duplicate", "thank you", "subtotal", "total",
            "gst", "ntn", "strn", "pntn", "fbr", "pkr", "rs", "order", "table", "qty", "rate", "amount"
        )
        for (i in 0 until minOf(6, rawLines.size)) {
            val candidate = rawLines[i].replace(Regex("[^a-zA-Z0-9 &.'-]"), " ").trim()
            if (candidate.length >= 3 && !ignoredMerchantKeywords.any { candidate.lowercase().contains(it) }) {
                merchant = candidate
                break
            }
        }

        // 2. Date Detection
        var dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        var dateMillis = System.currentTimeMillis()
        val dateRegexPatterns = listOf(
            Pattern.compile("\\b(\\d{4})[-/.](0?[1-9]|1[0-2])[-/.](0?[1-9]|[12]\\d|3[01])\\b"), // YYYY-MM-DD
            Pattern.compile("\\b(0?[1-9]|[12]\\d|3[01])[-/.](0?[1-9]|1[0-2])[-/.](20\\d{2}|\\d{2})\\b"), // DD/MM/YYYY
            Pattern.compile("\\b(0?[1-9]|[12]\\d|3[01])[-/ ](Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*[-/ ](20\\d{2}|\\d{2})\\b", Pattern.CASE_INSENSITIVE)
        )

        for (line in rawLines) {
            var foundDate = false
            for (pattern in dateRegexPatterns) {
                val matcher = pattern.matcher(line)
                if (matcher.find()) {
                    val matchedGroup = matcher.group()
                    val parsed = parseDateToMillis(matchedGroup)
                    if (parsed > 0) {
                        dateMillis = parsed
                        dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(dateMillis))
                        foundDate = true
                        break
                    }
                }
            }
            if (foundDate) break
        }

        // 3. Category Detection
        val fullTextLower = fullText.lowercase()
        val category = when {
            listOf("petrol", "diesel", "fuel", "cng", "pso", "shell", "attock", "total energies").any { fullTextLower.contains(it) } -> "Fuel"
            listOf("restaurant", "cafe", "burger", "pizza", "biryani", "food", "kitchen", "bakery", "bread", "milk", "tea", "coffee", "dine", "snack", "sweets", "roti", "chicken", "meat", "boti", "kebab", "karahi", "handi").any { fullTextLower.contains(it) } -> "Food"
            listOf("hotel", "room", "lodge", "resort", "inn", "stay", "guest house").any { fullTextLower.contains(it) } -> "Hotel"
            listOf("pharmacy", "medical", "medicine", "chemist", "clinic", "hospital", "pharma", "tablet", "syrup", "capsule", "panadol", "injection").any { fullTextLower.contains(it) } -> "Medicine"
            listOf("uber", "careem", "indrive", "taxi", "bus", "fare", "toll", "airline", "flight", "ticket", "train").any { fullTextLower.contains(it) } -> "Travel"
            listOf("bill", "electricity", "wapda", "lesco", "iesco", "ptcl", "internet", "water", "gas", "utility", "sui gas").any { fullTextLower.contains(it) } -> "Bills"
            else -> "Shopping"
        }

        // 4. Currency Detection
        val currency = when {
            fullText.contains("$") || fullTextLower.contains("usd") -> "USD"
            fullText.contains("€") || fullTextLower.contains("eur") -> "EUR"
            fullText.contains("£") || fullTextLower.contains("gbp") -> "GBP"
            fullTextLower.contains("aed") -> "AED"
            fullTextLower.contains("sar") -> "SAR"
            else -> "PKR"
        }

        // 5. Total, Subtotal, Tax, Discount extraction
        var grandTotal = 0.0
        var subtotal = 0.0
        var tax = 0.0
        var discount = 0.0

        val totalRegex = Pattern.compile("(?i)(?:grand\\s*total|net\\s*total|total\\s*amount|total\\s*payable|amount\\s*paid|net\\s*amount|total\\s*due|total)\\s*[:=-]?\\s*(?:rs\\.?|pkr)?\\s*([\\d,]+\\.?\\d*)")
        val subtotalRegex = Pattern.compile("(?i)(?:sub\\s*total|subtotal)\\s*[:=-]?\\s*(?:rs\\.?|pkr)?\\s*([\\d,]+\\.?\\d*)")
        val taxRegex = Pattern.compile("(?i)(?:tax|gst|vat|sales\\s*tax)\\s*[:=-]?\\s*(?:rs\\.?|pkr)?\\s*([\\d,]+\\.?\\d*)")
        val discountRegex = Pattern.compile("(?i)(?:discount|disc|less)\\s*[:=-]?\\s*(?:rs\\.?|pkr)?\\s*([\\d,]+\\.?\\d*)")

        for (line in rawLines) {
            val totalMatcher = totalRegex.matcher(line)
            if (totalMatcher.find()) {
                val amt = parseAmount(totalMatcher.group(1))
                if (amt > grandTotal) grandTotal = amt
            }
            val subMatcher = subtotalRegex.matcher(line)
            if (subMatcher.find()) {
                val amt = parseAmount(subMatcher.group(1))
                if (amt > 0) subtotal = amt
            }
            val taxMatcher = taxRegex.matcher(line)
            if (taxMatcher.find()) {
                val amt = parseAmount(taxMatcher.group(1))
                if (amt > 0) tax = amt
            }
            val discMatcher = discountRegex.matcher(line)
            if (discMatcher.find()) {
                val amt = parseAmount(discMatcher.group(1))
                if (amt > 0) discount = amt
            }
        }

        // 6. Intelligent Multi-Column Line Items Extraction
        val extractedItems = mutableListOf<ExtractedItemData>()
        val skipLineKeywords = listOf(
            "subtotal", "sub total", "total", "grand total", "net amount", "tax", "gst", "vat",
            "discount", "cash", "change", "card", "visa", "mastercard", "date", "time",
            "thank you", "welcome", "tel", "phone", "cashier", "pos", "invoice", "receipt",
            "ntn", "strn", "pntn", "fbr", "item description", "qty", "rate", "amount"
        )

        // Pattern A: "White Chicken Boti 2 1,075 2,150" or "Woven Bag 2 19 38"
        // Pattern B: "Chicken Seekh Kebab 2 x 1,075 = 2,150"
        // Pattern C: "ItemName 2,150"
        val columnTablePattern = Pattern.compile("^(.*?)\\s+(\\d+(?:\\.\\d+)?)\\s+([\\d,]+(?:\\.\\d+)?)\\s+([\\d,]+(?:\\.\\d+)?)$")
        val priceQtyPattern = Pattern.compile("^(.*?)\\s+(\\d+(?:\\.\\d+)?)\\s*[xX*@]\\s*([\\d,]+(?:\\.\\d+)?)\\s*(?:=\\s*)?([\\d,]+(?:\\.\\d+)?)?$")
        val priceEndingPattern = Pattern.compile("^(.*?)\\s+([\\d,]+\\.\\d{2}|[\\d,]+)$")

        for (line in rawLines) {
            val lineLower = line.lowercase().trim()
            if (skipLineKeywords.any { lineLower.startsWith(it) || lineLower == "total" || lineLower.contains("subtotal") || lineLower.contains("fbr invoice") }) {
                continue
            }

            // Check Pattern A: [Item Name] [Qty] [Rate] [Total] (e.g., "White Chicken Boti 2 1,075 2,150")
            val colMatcher = columnTablePattern.matcher(line)
            if (colMatcher.find()) {
                val itemName = colMatcher.group(1)?.replace(Regex("[^a-zA-Z0-9 &.'()/-]"), " ")?.trim() ?: ""
                val qty = colMatcher.group(2)?.toDoubleOrNull() ?: 1.0
                val unitPrice = parseAmount(colMatcher.group(3))
                val lineTotal = parseAmount(colMatcher.group(4))

                if (itemName.isNotBlank() && lineTotal > 0 && !itemName.all { it.isDigit() }) {
                    extractedItems.add(
                        ExtractedItemData(
                            name = itemName,
                            quantity = if (qty <= 0) 1.0 else qty,
                            unitPrice = if (unitPrice > 0) unitPrice else (lineTotal / qty),
                            lineTotal = lineTotal
                        )
                    )
                    continue
                }
            }

            // Check Pattern B: "ItemName Qty x UnitPrice [= LineTotal]"
            val pqMatcher = priceQtyPattern.matcher(line)
            if (pqMatcher.find()) {
                val itemName = pqMatcher.group(1)?.replace(Regex("[^a-zA-Z0-9 &.'()/-]"), " ")?.trim() ?: ""
                val qty = pqMatcher.group(2)?.toDoubleOrNull() ?: 1.0
                val unitPrice = parseAmount(pqMatcher.group(3))
                val lineTotalFromMatch = parseAmount(pqMatcher.group(4))
                val finalLineTotal = if (lineTotalFromMatch > 0) lineTotalFromMatch else (qty * unitPrice)

                if (itemName.isNotBlank() && finalLineTotal > 0 && !itemName.all { it.isDigit() }) {
                    extractedItems.add(
                        ExtractedItemData(
                            name = itemName,
                            quantity = if (qty <= 0) 1.0 else qty,
                            unitPrice = if (unitPrice > 0) unitPrice else (finalLineTotal / qty),
                            lineTotal = finalLineTotal
                        )
                    )
                    continue
                }
            }

            // Check Pattern C: "ItemName LineTotal"
            val priceMatcher = priceEndingPattern.matcher(line)
            if (priceMatcher.find()) {
                val rawItemName = priceMatcher.group(1)?.replace(Regex("[^a-zA-Z0-9 &.'()/-]"), " ")?.trim() ?: ""
                val priceVal = parseAmount(priceMatcher.group(2))
                if (rawItemName.length >= 2 && priceVal > 0 && !rawItemName.all { it.isDigit() }) {
                    var parsedQty = 1.0
                    val qtyInName = Regex("(\\d+)\\s*(?:pcs|kg|liters|x|qty)", RegexOption.IGNORE_CASE).find(rawItemName)
                    if (qtyInName != null) {
                        parsedQty = qtyInName.groupValues[1].toDoubleOrNull() ?: 1.0
                    }
                    extractedItems.add(
                        ExtractedItemData(
                            name = rawItemName,
                            quantity = parsedQty,
                            unitPrice = if (parsedQty > 1.0) priceVal / parsedQty else priceVal,
                            lineTotal = priceVal
                        )
                    )
                }
            }
        }

        // If grand total is still 0, sum extracted line items
        val calculatedItemsSum = extractedItems.sumOf { it.lineTotal }
        val finalGrandTotal = if (grandTotal > 0) {
            grandTotal
        } else if (calculatedItemsSum > 0) {
            calculatedItemsSum
        } else {
            0.0
        }

        val rawNote = if (!isOnline) {
            "No internet connection. Offline receipt scanning is available; please verify the extracted details."
        } else {
            "Extracted via On-Device ML Kit OCR (${extractedItems.size} items detected)"
        }

        Log.d(TAG, "ML Kit extraction finished: $merchant, Date: $dateStr, Total: $finalGrandTotal, Items: ${extractedItems.size}")

        return ExtractedReceiptData(
            merchant = merchant,
            dateStr = dateStr,
            dateMillis = dateMillis,
            category = category,
            currency = currency,
            subtotal = if (subtotal > 0) subtotal else calculatedItemsSum,
            tax = tax,
            discount = discount,
            grandTotal = finalGrandTotal,
            items = extractedItems,
            isSuccessful = true,
            rawJson = rawNote
        )
    }

    private fun parseAmount(str: String?): Double {
        if (str.isNullOrBlank()) return 0.0
        return try {
            str.replace(",", "").trim().toDoubleOrNull() ?: 0.0
        } catch (e: Exception) {
            0.0
        }
    }

    private fun parseGeminiApiResponse(responseText: String): ExtractedReceiptData {
        var rawText = responseText.trim()
        if (rawText.startsWith("```json")) {
            rawText = rawText.removePrefix("```json").trim()
        }
        if (rawText.startsWith("```")) {
            rawText = rawText.removePrefix("```").trim()
        }
        if (rawText.endsWith("```")) {
            rawText = rawText.removeSuffix("```").trim()
        }

        val parsedJson = JSONObject(rawText)
        val merchant = parsedJson.optString("merchant", "Store Receipt").ifBlank { "Store Receipt" }
        val dateStr = parsedJson.optString("date", "")
        val category = parsedJson.optString("category", "Shopping")
        val currency = parsedJson.optString("currency", "PKR")
        val subtotal = parsedJson.optDouble("subtotal", 0.0)
        val tax = parsedJson.optDouble("tax", 0.0)
        val discount = parsedJson.optDouble("discount", 0.0)
        val grandTotal = parsedJson.optDouble("total", 0.0)

        val parsedDateMillis = parseDateToMillis(dateStr)

        val itemsList = mutableListOf<ExtractedItemData>()
        val itemsArray = parsedJson.optJSONArray("items")
        if (itemsArray != null) {
            for (i in 0 until itemsArray.length()) {
                val itemObj = itemsArray.optJSONObject(i) ?: continue
                val name = itemObj.optString("name", "Item ${i + 1}").ifBlank { "Item ${i + 1}" }
                var quantity = itemObj.optDouble("quantity", 1.0)
                if (quantity <= 0.0) quantity = 1.0

                var unitPrice = itemObj.optDouble("unitPrice", 0.0)
                var lineTotal = itemObj.optDouble("lineTotal", 0.0)

                if (lineTotal <= 0.0 && unitPrice > 0.0) {
                    lineTotal = quantity * unitPrice
                } else if (unitPrice <= 0.0 && lineTotal > 0.0 && quantity > 0.0) {
                    unitPrice = lineTotal / quantity
                }

                itemsList.add(
                    ExtractedItemData(
                        name = name,
                        quantity = quantity,
                        unitPrice = unitPrice,
                        lineTotal = lineTotal
                    )
                )
            }
        }

        val finalGrandTotal = if (grandTotal > 0) {
            grandTotal
        } else {
            itemsList.sumOf { it.lineTotal }
        }

        return ExtractedReceiptData(
            merchant = merchant,
            dateStr = dateStr,
            dateMillis = parsedDateMillis,
            category = category,
            currency = currency,
            subtotal = subtotal,
            tax = tax,
            discount = discount,
            grandTotal = finalGrandTotal,
            items = itemsList,
            isSuccessful = true,
            rawJson = rawText
        )
    }

    private fun parseDateToMillis(dateStr: String): Long {
        if (dateStr.isBlank()) return System.currentTimeMillis()
        val formats = listOf(
            SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()),
            SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()),
            SimpleDateFormat("MM/dd/yyyy", Locale.getDefault()),
            SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()),
            SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault()),
            SimpleDateFormat("dd MMMM yyyy", Locale.getDefault()),
            SimpleDateFormat("yyyy/MM/dd", Locale.getDefault())
        )
        for (format in formats) {
            try {
                val date = format.parse(dateStr)
                if (date != null) return date.time
            } catch (_: Exception) {}
        }
        return System.currentTimeMillis()
    }

    private fun buildFallbackResponse(reason: String): ExtractedReceiptData {
        return ExtractedReceiptData(
            merchant = "Store Receipt",
            dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
            dateMillis = System.currentTimeMillis(),
            category = "Shopping",
            currency = "PKR",
            subtotal = 0.0,
            tax = 0.0,
            discount = 0.0,
            grandTotal = 0.0,
            items = emptyList(),
            isSuccessful = false,
            rawJson = reason
        )
    }
}
