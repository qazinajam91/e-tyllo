package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.ThemeMode
import com.example.data.model.UserProfile
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.ExpenseRed
import com.example.util.BiometricHelper

@Composable
fun SettingsScreen(
    themeMode: ThemeMode,
    onToggleTheme: (Boolean) -> Unit,
    language: AppLanguage,
    onToggleLanguage: () -> Unit,
    isPinEnabled: Boolean,
    onSetPin: (String) -> Boolean,
    onVerifyPin: (String) -> Boolean,
    onDisablePin: () -> Unit,
    isBiometricsEnabled: Boolean,
    onToggleBiometrics: (Boolean) -> Unit,
    currentUserProfile: UserProfile?,
    onUpdateProfile: (String, String, String) -> Unit,
    onNavigateAbout: () -> Unit,
    onNavigateFeedback: () -> Unit,
    onSignOut: () -> Unit,
    tr: (String) -> String
) {
    val context = LocalContext.current
    var showEditProfileDialog by remember { mutableStateOf(false) }
    var showCreatePinDialog by remember { mutableStateOf(false) }
    var showDisablePinDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Guest Banner or Edit Profile Card
        if (currentUserProfile == null) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = EmeraldPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Guest Mode (Local Only)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Your transactions are stored locally. Sign in with Google to enable automatic cloud backup and sync across devices.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 16.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = onSignOut,
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.AccountCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "Sign In / Register with Google", fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            SettingsCard(onClick = { showEditProfileDialog = true }) {
                SettingsRow(
                    icon = Icons.Default.Person,
                    title = "Edit Profile",
                    subtitle = if (currentUserProfile.fullName.isNotBlank())
                        "${currentUserProfile.fullName} • ${currentUserProfile.email}"
                    else
                        "Update name, phone number & age",
                    trailing = {
                        Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null)
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Theme Row
        SettingsCard {
            SettingsRow(
                icon = Icons.Default.DarkMode,
                title = tr("theme"),
                subtitle = tr("switch_theme"),
                trailing = {
                    Switch(
                        checked = themeMode == ThemeMode.DARK,
                        onCheckedChange = { isDark -> onToggleTheme(isDark) },
                        colors = SwitchDefaults.colors(checkedThumbColor = EmeraldPrimary)
                    )
                }
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Language Row
        SettingsCard {
            SettingsRow(
                icon = Icons.Default.Language,
                title = tr("language"),
                subtitle = if (language == AppLanguage.URDU) "اردو (Urdu)" else "English",
                trailing = {
                    Button(
                        onClick = onToggleLanguage,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Text(
                            text = if (language == AppLanguage.URDU) "اردو" else "EN",
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // PIN Lock Row
        SettingsCard {
            Column {
                SettingsRow(
                    icon = Icons.Default.Pin,
                    title = tr("pin_lock"),
                    subtitle = tr("secure_with_pin"),
                    trailing = {
                        Switch(
                            checked = isPinEnabled,
                            onCheckedChange = { checked ->
                                if (checked) {
                                    showCreatePinDialog = true
                                } else {
                                    showDisablePinDialog = true
                                }
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = EmeraldPrimary)
                        )
                    }
                )

                if (isPinEnabled) {
                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showCreatePinDialog = true }
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Change Security PIN",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = EmeraldPrimary
                        )
                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = "Change PIN",
                            tint = EmeraldPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Fingerprint Row
        SettingsCard {
            SettingsRow(
                icon = Icons.Default.Fingerprint,
                title = tr("fingerprint_lock"),
                subtitle = tr("biometric_auth"),
                trailing = {
                    Switch(
                        checked = isBiometricsEnabled,
                        onCheckedChange = { checked ->
                            if (checked) {
                                if (BiometricHelper.isBiometricEnrolled(context) || BiometricHelper.isDeviceSecurityAvailable(context)) {
                                    onToggleBiometrics(true)
                                    Toast.makeText(context, "Biometric security enabled.", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(
                                        context,
                                        "No enrolled fingerprint or biometric found. Please enroll biometric security in your device Settings first.",
                                        Toast.LENGTH_LONG
                                    ).show()
                                }
                            } else {
                                onToggleBiometrics(false)
                            }
                        },
                        colors = SwitchDefaults.colors(checkedThumbColor = EmeraldPrimary)
                    )
                }
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // About Row
        SettingsCard(onClick = onNavigateAbout) {
            SettingsRow(
                icon = Icons.Default.Info,
                title = tr("about_etyllo"),
                subtitle = tr("version_credits_features"),
                trailing = {
                    Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null)
                }
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Feedback Row
        SettingsCard(onClick = onNavigateFeedback) {
            SettingsRow(
                icon = Icons.Default.Feedback,
                title = tr("send_feedback"),
                subtitle = tr("help_us_improve"),
                trailing = {
                    Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null)
                }
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Sign Out Button
        OutlinedButton(
            onClick = onSignOut,
            colors = ButtonDefaults.outlinedButtonColors(contentColor = ExpenseRed),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Icon(imageVector = Icons.AutoMirrored.Filled.ExitToApp, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (currentUserProfile == null) "Exit Guest Mode / Sign In" else tr("sign_out"),
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Footer Credit
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Developed By",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "Qazi Najam",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = EmeraldPrimary
                )
                Text(
                    text = "Lead Developer and Architect",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }

    if (showCreatePinDialog) {
        CreatePinDialog(
            onPinCreated = { newPin ->
                val success = onSetPin(newPin)
                if (success) {
                    Toast.makeText(context, "Security PIN configured successfully.", Toast.LENGTH_SHORT).show()
                }
                showCreatePinDialog = false
            },
            onDismiss = { showCreatePinDialog = false }
        )
    }

    if (showDisablePinDialog) {
        ConfirmDisablePinDialog(
            onVerifyPin = { entered -> onVerifyPin(entered) },
            onConfirmed = {
                onDisablePin()
                Toast.makeText(context, "PIN Lock disabled.", Toast.LENGTH_SHORT).show()
                showDisablePinDialog = false
            },
            onDismiss = { showDisablePinDialog = false }
        )
    }

    if (showEditProfileDialog) {
        EditProfileDialog(
            currentProfile = currentUserProfile,
            onDismiss = { showEditProfileDialog = false },
            onSave = { name, phone, ageVal ->
                onUpdateProfile(name, phone, ageVal)
                showEditProfileDialog = false
            }
        )
    }
}

@Composable
fun EditProfileDialog(
    currentProfile: UserProfile?,
    onDismiss: () -> Unit,
    onSave: (String, String, String) -> Unit
) {
    var fullName by remember { mutableStateOf(currentProfile?.fullName ?: "") }
    var phoneNumber by remember { mutableStateOf(currentProfile?.phoneNumber ?: "") }
    var age by remember { mutableStateOf(currentProfile?.age ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Edit User Profile", fontWeight = FontWeight.Bold)
        },
        text = {
            Column {
                Text("Full Name", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = fullName,
                    onValueChange = { fullName = it },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text("Phone/Contact Number", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = phoneNumber,
                    onValueChange = { phoneNumber = it },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text("Age", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = age,
                    onValueChange = { age = it },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(fullName, phoneNumber, age) },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
            ) {
                Text("Save to Cloud", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun SettingsCard(
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
    ) {
        Box(modifier = Modifier.padding(16.dp)) {
            content()
        }
    }
}

@Composable
fun SettingsRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    trailing: @Composable () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(imageVector = icon, contentDescription = title, tint = EmeraldPrimary, modifier = Modifier.size(24.dp))
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface)
            Text(text = subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        trailing()
    }
}
