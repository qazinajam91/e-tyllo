package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.util.Log
import android.util.Patterns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.UserProfile
import com.example.data.repository.UserProfileRepository
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AuthViewModel(application: Application) : AndroidViewModel(application) {
    private val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }
    private val userProfileRepository = UserProfileRepository(application)
    private var profileObserverJob: Job? = null

    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    private val _currentUserProfile = MutableStateFlow<UserProfile?>(userProfileRepository.getOfflineUserProfile())
    val currentUserProfile: StateFlow<UserProfile?> = _currentUserProfile.asStateFlow()

    companion object {
        private const val TAG = "AuthViewModel"
    }

    init {
        checkInitialSession()
    }

    fun checkInitialSession() {
        val user = auth.currentUser
        if (user != null) {
            val email = user.email ?: ""
            _uiState.update { it.copy(userEmail = email) }
            viewModelScope.launch {
                try {
                    user.reload().await()
                    if (user.isEmailVerified) {
                        _uiState.update {
                            it.copy(
                                isAuthenticated = true,
                                isNeedsVerification = false
                            )
                        }
                        observeProfile(user.uid)
                    } else {
                        _uiState.update {
                            it.copy(
                                isAuthenticated = false,
                                isNeedsVerification = true
                            )
                        }
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Initial session check error", e)
                    val cached = userProfileRepository.getOfflineUserProfile()
                    if (cached != null && cached.emailVerified) {
                        _uiState.update { it.copy(isAuthenticated = true, isNeedsVerification = false) }
                        _currentUserProfile.value = cached
                    } else {
                        _uiState.update { it.copy(isAuthenticated = false, isNeedsVerification = true) }
                    }
                }
            }
        } else {
            _uiState.update {
                it.copy(
                    isAuthenticated = false,
                    isNeedsVerification = false
                )
            }
        }
    }

    private fun observeProfile(uid: String) {
        profileObserverJob?.cancel()
        profileObserverJob = viewModelScope.launch {
            userProfileRepository.observeUserProfile(uid).collect { profile ->
                _currentUserProfile.value = profile
            }
        }
    }

    fun clearMessages() {
        _uiState.update {
            it.copy(
                errorMessage = null,
                successMessage = null,
                isPasswordResetSent = false
            )
        }
    }

    // ===================================================================
    // GUEST MODE (IN-MEMORY SESSION)
    // ===================================================================
    fun continueAsGuest() {
        _uiState.update {
            it.copy(
                isGuest = true,
                isAuthenticated = false,
                isNeedsVerification = false,
                errorMessage = null,
                successMessage = null
            )
        }
    }

    // ===================================================================
    // EMAIL & PASSWORD REGISTRATION
    // ===================================================================
    fun signUp(
        fullName: String,
        email: String,
        age: String,
        pass: String,
        confirmPass: String
    ) {
        val cleanName = fullName.trim()
        val cleanEmail = email.trim()
        val cleanAge = age.trim()

        if (cleanName.isBlank() || cleanName.length < 2) {
            _uiState.update { it.copy(errorMessage = "Please enter your full name (minimum 2 characters).") }
            return
        }
        if (cleanEmail.isBlank() || !Patterns.EMAIL_ADDRESS.matcher(cleanEmail).matches()) {
            _uiState.update { it.copy(errorMessage = "Please enter a valid email address.") }
            return
        }
        if (cleanAge.isBlank()) {
            _uiState.update { it.copy(errorMessage = "Please enter your age.") }
            return
        }
        val ageNum = cleanAge.toIntOrNull()
        if (ageNum == null || ageNum < 10 || ageNum > 120) {
            _uiState.update { it.copy(errorMessage = "Please enter a valid age between 10 and 120.") }
            return
        }
        if (pass.isBlank()) {
            _uiState.update { it.copy(errorMessage = "Please enter a password.") }
            return
        }
        if (pass.length < 6) {
            _uiState.update { it.copy(errorMessage = "Password must be at least 6 characters long.") }
            return
        }
        if (pass != confirmPass) {
            _uiState.update { it.copy(errorMessage = "Passwords do not match.") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null, successMessage = null) }
            try {
                val result = auth.createUserWithEmailAndPassword(cleanEmail, pass).await()
                val user = result.user
                val uid = user?.uid ?: ""

                if (uid.isNotBlank() && user != null) {
                    val dateFormatted = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                    val now = System.currentTimeMillis()

                    val profile = UserProfile(
                        uid = uid,
                        name = cleanName,
                        fullName = cleanName,
                        email = cleanEmail,
                        age = cleanAge,
                        registrationDate = dateFormatted,
                        emailVerified = false,
                        createdAt = now,
                        updatedAt = now
                    )

                    // Dispatch verification email
                    try {
                        user.sendEmailVerification().await()
                    } catch (evErr: Exception) {
                        Log.w(TAG, "sendEmailVerification non-fatal issue", evErr)
                    }

                    // Save user profile in Firestore
                    userProfileRepository.saveUserProfile(profile)
                    _currentUserProfile.value = profile

                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            isNeedsVerification = true,
                            isAuthenticated = false,
                            userEmail = cleanEmail,
                            successMessage = "We've sent a confirmation link to your Gmail. Open it from your inbox (check Spam/Promotions too) to activate your E Tyllo account."
                        )
                    }
                } else {
                    _uiState.update { it.copy(isLoading = false, errorMessage = "Failed to create account. Please try again.") }
                }
            } catch (e: FirebaseAuthUserCollisionException) {
                _uiState.update { it.copy(isLoading = false, errorMessage = "This email is already registered. Please sign in instead.") }
            } catch (e: FirebaseAuthInvalidCredentialsException) {
                _uiState.update { it.copy(isLoading = false, errorMessage = "Invalid email format or credentials.") }
            } catch (e: Exception) {
                Log.e(TAG, "Sign up error", e)
                _uiState.update { it.copy(isLoading = false, errorMessage = e.localizedMessage ?: "Sign up failed. Please try again.") }
            }
        }
    }

    // ===================================================================
    // EMAIL & PASSWORD SIGN IN
    // ===================================================================
    fun signIn(email: String, pass: String) {
        val cleanEmail = email.trim()
        if (cleanEmail.isBlank()) {
            _uiState.update { it.copy(errorMessage = "Please enter your email address.") }
            return
        }
        if (pass.isBlank()) {
            _uiState.update { it.copy(errorMessage = "Please enter your password.") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null, successMessage = null) }
            try {
                val result = auth.signInWithEmailAndPassword(cleanEmail, pass).await()
                val user = result.user
                if (user != null) {
                    user.reload().await()
                    val isVerified = user.isEmailVerified

                    if (isVerified) {
                        userProfileRepository.updateEmailVerificationStatus(user.uid, true)
                        observeProfile(user.uid)
                        _uiState.update {
                            it.copy(
                                isLoading = false,
                                isAuthenticated = true,
                                isNeedsVerification = false,
                                userEmail = cleanEmail
                            )
                        }
                    } else {
                        _uiState.update {
                            it.copy(
                                isLoading = false,
                                isAuthenticated = false,
                                isNeedsVerification = true,
                                userEmail = cleanEmail,
                                errorMessage = "Please verify your email address before accessing your dashboard."
                            )
                        }
                    }
                } else {
                    _uiState.update { it.copy(isLoading = false, errorMessage = "User account not found.") }
                }
            } catch (e: FirebaseAuthInvalidCredentialsException) {
                _uiState.update { it.copy(isLoading = false, errorMessage = "Invalid email address or password.") }
            } catch (e: Exception) {
                Log.e(TAG, "Sign in error", e)
                _uiState.update { it.copy(isLoading = false, errorMessage = e.localizedMessage ?: "Sign in failed.") }
            }
        }
    }

    // ===================================================================
    // EMAIL VERIFICATION ACTIONS
    // ===================================================================
    fun checkEmailVerification() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null, successMessage = null) }
            try {
                val user = auth.currentUser
                if (user == null) {
                    _uiState.update { it.copy(isLoading = false, errorMessage = "No active session found. Please sign in again.") }
                    return@launch
                }

                user.reload().await()
                if (user.isEmailVerified) {
                    userProfileRepository.updateEmailVerificationStatus(user.uid, true)
                    observeProfile(user.uid)
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            isAuthenticated = true,
                            isNeedsVerification = false,
                            successMessage = "Email verified! Welcome to E Tyllo."
                        )
                    }
                } else {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            errorMessage = "Your email has not been verified yet. Please check your inbox or spam folder."
                        )
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Check verification error", e)
                _uiState.update { it.copy(isLoading = false, errorMessage = "Unable to check verification status: ${e.localizedMessage}") }
            }
        }
    }

    fun sendVerificationEmail() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null, successMessage = null) }
            try {
                val user = auth.currentUser
                if (user != null) {
                    user.sendEmailVerification().await()
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            successMessage = "Verification email sent to ${user.email}. Check your inbox and spam folder."
                        )
                    }
                } else {
                    _uiState.update { it.copy(isLoading = false, errorMessage = "No active session found. Please sign in.") }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Resend verification error", e)
                _uiState.update { it.copy(isLoading = false, errorMessage = "Failed to send verification email: ${e.localizedMessage}") }
            }
        }
    }

    fun resetPassword(email: String) {
        val cleanEmail = email.trim()
        if (cleanEmail.isBlank() || !Patterns.EMAIL_ADDRESS.matcher(cleanEmail).matches()) {
            _uiState.update { it.copy(errorMessage = "Please enter a valid email address.") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null, successMessage = null) }
            try {
                auth.sendPasswordResetEmail(cleanEmail).await()
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        isPasswordResetSent = true,
                        successMessage = "Password reset instructions sent to $cleanEmail."
                    )
                }
            } catch (e: Exception) {
                Log.e(TAG, "Reset password error", e)
                _uiState.update { it.copy(isLoading = false, errorMessage = e.localizedMessage ?: "Failed to send reset email.") }
            }
        }
    }

    fun setErrorMessage(msg: String) {
        _uiState.update { it.copy(isLoading = false, errorMessage = msg) }
    }

    // ===================================================================
    // PROFILE MANAGEMENT
    // ===================================================================
    fun updateProfile(fullName: String, phoneNumber: String, age: String) {
        val uid = auth.currentUser?.uid ?: currentUserProfile.value?.uid ?: ""
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            try {
                userProfileRepository.updateProfileDetails(uid, fullName, phoneNumber, age)
                val updated = _currentUserProfile.value?.copy(
                    name = fullName,
                    fullName = fullName,
                    phoneNumber = phoneNumber,
                    age = age
                )
                _currentUserProfile.value = updated
                _uiState.update { it.copy(isLoading = false, successMessage = "Profile updated successfully.") }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to update profile", e)
                _uiState.update { it.copy(isLoading = false, errorMessage = "Failed to update profile details.") }
            }
        }
    }

    fun signOut() {
        try {
            auth.signOut()
        } catch (e: Exception) {
            Log.e(TAG, "Sign out error", e)
        }
        userProfileRepository.clearOfflineUserProfile()
        _currentUserProfile.value = null
        _uiState.update {
            AuthUiState(
                isAuthenticated = false,
                isGuest = false,
                isNeedsVerification = false,
                userEmail = ""
            )
        }
    }
}
