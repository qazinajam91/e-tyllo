package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AppLanguage
import com.example.data.model.CategoryEntity
import com.example.data.model.LoanEntity
import com.example.data.model.ThemeMode
import com.example.data.model.TransactionEntity
import com.example.data.repository.ETylloRepository
import com.example.ui.i18n.Translations
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Calendar

class ETylloViewModel(application: Application) : AndroidViewModel(application) {
    val repository = ETylloRepository(application)

    val transactions: StateFlow<List<TransactionEntity>> = repository.allTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val loans: StateFlow<List<LoanEntity>> = repository.allLoans
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val budgetAmount: StateFlow<Double> = repository.budget
        .map { it?.monthlyAmount ?: 50000.0 }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 50000.0)

    val allCategories: StateFlow<List<CategoryEntity>> = repository.allCategories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val expenseCategories: StateFlow<List<String>> = allCategories.map { list ->
        list.filter { it.type == "EXPENSE" }.map { it.name }.ifEmpty {
            listOf("Food & Dining", "Bills & Utilities", "Transport", "Shopping", "Entertainment", "Health", "General")
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("Food & Dining", "Bills & Utilities", "Transport", "Shopping", "Entertainment", "Health", "General"))

    val incomeCategories: StateFlow<List<String>> = allCategories.map { list ->
        list.filter { it.type == "INCOME" }.map { it.name }.ifEmpty {
            listOf("Salary", "Freelance", "Allowance", "Company Allowance", "Business", "Investment", "Others")
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("Salary", "Freelance", "Allowance", "Company Allowance", "Business", "Investment", "Others"))

    val themeMode: StateFlow<ThemeMode> = repository.themeMode
    val language: StateFlow<AppLanguage> = repository.language
    val isPinEnabled: StateFlow<Boolean> = repository.isPinEnabled
    val pinCode: StateFlow<String> = repository.pinCode
    val isBiometricsEnabled: StateFlow<Boolean> = repository.isBiometricsEnabled
    val isSignedIn: StateFlow<Boolean> = repository.isSignedIn
    val userEmail: StateFlow<String> = repository.userEmail
    val userName: StateFlow<String> = repository.userName

    // Helper translation accessor
    fun string(key: String): String = Translations.getString(key, language.value)

    private fun getTodayStartMillis(): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    private fun getMonthStartMillis(): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    // Today Statistics
    val todayIncome: StateFlow<Double> = transactions.map { list ->
        val start = getTodayStartMillis()
        list.filter { it.type == "INCOME" && it.dateMillis >= start }.sumOf { it.amount }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val todayExpense: StateFlow<Double> = transactions.map { list ->
        val start = getTodayStartMillis()
        list.filter { it.type == "EXPENSE" && it.dateMillis >= start }.sumOf { it.amount }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val todaySavings: StateFlow<Double> = combine(todayIncome, todayExpense) { inc, exp ->
        (inc - exp).coerceAtLeast(0.0)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val todayNet: StateFlow<Double> = combine(todayIncome, todayExpense) { inc, exp ->
        inc - exp
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // Monthly Statistics
    val monthlyIncome: StateFlow<Double> = transactions.map { list ->
        val start = getMonthStartMillis()
        list.filter { it.type == "INCOME" && it.dateMillis >= start }.sumOf { it.amount }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val monthlyExpense: StateFlow<Double> = transactions.map { list ->
        val start = getMonthStartMillis()
        list.filter { it.type == "EXPENSE" && it.dateMillis >= start }.sumOf { it.amount }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val monthlySavings: StateFlow<Double> = combine(monthlyIncome, monthlyExpense) { inc, exp ->
        (inc - exp).coerceAtLeast(0.0)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val monthlyNet: StateFlow<Double> = combine(monthlyIncome, monthlyExpense) { inc, exp ->
        inc - exp
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // All time expense
    val allTimeExpense: StateFlow<Double> = transactions.map { list ->
        list.filter { it.type == "EXPENSE" }.sumOf { it.amount }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // Loans Summary with Remaining Amount calculation
    val youOweAmount: StateFlow<Double> = loans.map { list ->
        list.filter { (it.type.contains("BORROW", true) || it.type.contains("Took", true)) && !it.isCleared }
            .sumOf { it.remainingAmount }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val owedToYouAmount: StateFlow<Double> = loans.map { list ->
        list.filter { (it.type.contains("LEND", true) || it.type.contains("Gave", true)) && !it.isCleared }
            .sumOf { it.remainingAmount }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val pendingLoansCount: StateFlow<Int> = loans.map { list ->
        list.count { !it.isCleared }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // Actions
    fun addExpense(amount: Double, category: String, dateMillis: Long, note: String) {
        viewModelScope.launch {
            repository.addTransaction("EXPENSE", amount, category, dateMillis, note)
        }
    }

    fun addReceiptExpense(
        amount: Double,
        category: String,
        dateMillis: Long,
        merchantName: String,
        subtotal: Double = 0.0,
        tax: Double = 0.0,
        discount: Double = 0.0,
        currency: String = "PKR",
        items: List<com.example.data.service.ExtractedItemData> = emptyList(),
        imageUri: String? = null,
        saveIndividually: Boolean = false
    ) {
        viewModelScope.launch {
            repository.addReceiptExpense(
                amount = amount,
                category = category,
                dateMillis = dateMillis,
                merchantName = merchantName,
                subtotal = subtotal,
                tax = tax,
                discount = discount,
                currency = currency,
                items = items,
                imageUri = imageUri,
                saveIndividually = saveIndividually
            )
        }
    }

    fun addIncome(amount: Double, category: String, dateMillis: Long, note: String) {
        viewModelScope.launch {
            repository.addTransaction("INCOME", amount, category, dateMillis, note)
        }
    }

    fun deleteTransaction(id: Long) {
        viewModelScope.launch {
            repository.deleteTransaction(id)
        }
    }

    fun addCategory(name: String, type: String) {
        viewModelScope.launch {
            repository.addCategory(name, type)
        }
    }

    fun deleteCategory(id: Long) {
        viewModelScope.launch {
            repository.deleteCategory(id)
        }
    }

    fun addLoan(type: String, personName: String, amount: Double, dateMillis: Long, dueDateMillis: Long, note: String) {
        viewModelScope.launch {
            repository.addLoan(type, personName, amount, dateMillis, dueDateMillis, note)
        }
    }

    fun addLoanPayment(loanId: Long, paymentAmount: Double) {
        viewModelScope.launch {
            repository.addLoanPayment(loanId, paymentAmount)
        }
    }

    fun deleteLoan(id: Long) {
        viewModelScope.launch {
            repository.deleteLoan(id)
        }
    }

    fun updateBudget(amount: Double) {
        viewModelScope.launch {
            repository.setBudgetAmount(amount)
        }
    }

    fun toggleTheme(isDark: Boolean) {
        repository.setThemeMode(if (isDark) ThemeMode.DARK else ThemeMode.LIGHT)
    }

    fun toggleLanguage() {
        val newLang = if (language.value == AppLanguage.ENGLISH) AppLanguage.URDU else AppLanguage.ENGLISH
        repository.setLanguage(newLang)
    }

    fun togglePinLock(enabled: Boolean, pin: String = "1234") {
        repository.setPinEnabled(enabled, pin)
    }

    fun toggleBiometrics(enabled: Boolean) {
        repository.setBiometricsEnabled(enabled)
    }

    fun setSignedIn(signedIn: Boolean, email: String = "", name: String = "") {
        repository.setSignedIn(signedIn, email, name)
    }

    fun signOut() {
        repository.setSignedIn(false, "", "")
    }

    init {
        viewModelScope.launch {
            val currentTx = repository.allTransactions.first()
            if (currentTx.isEmpty()) {
                repository.addTransaction("INCOME", 637.0, "Company Allowance", System.currentTimeMillis(), "Daily Income")
                repository.addTransaction("EXPENSE", 230.0, "Travel", System.currentTimeMillis(), "Bus fare")
                repository.addTransaction("EXPENSE", 170.0, "Food", System.currentTimeMillis(), "Lunch")
            }
        }
    }
}
