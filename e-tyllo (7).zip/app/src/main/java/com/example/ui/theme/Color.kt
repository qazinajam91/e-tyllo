package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ===================================================================
// E Tyllo Production Material 3 Financial Color System
// ===================================================================

// Primary Branding & Accents
val DeepTeal = Color(0xFF004D40)         // Deep Teal Primary (#004D40)
val DeepTealLight = Color(0xFF00796B)    // Teal 700
val DeepTealDark = Color(0xFF00251A)     // Darkest Teal
val TealContainerLight = Color(0xFFE0F2F1)
val TealContainerDark = Color(0xFF00382F)

val EmeraldGreen = Color(0xFF10B981)     // Emerald Accent / Success (#10B981)
val EmeraldLight = Color(0xFF34D399)     // Emerald 400
val EmeraldDark = Color(0xFF059669)      // Emerald 600

// Compatibility aliases
val TealPrimary = DeepTeal
val TealDark = DeepTealDark
val TealLight = DeepTealLight
val EmeraldPrimary = EmeraldGreen
val EmeraldBg = TealContainerDark

val RoseCoral = Color(0xFFE07A5F)
val RoseCoralBg = Color(0xFFFDF0ED)

// Dark Theme Surfaces & Text (Dark Slate / Navy #0A192F)
val DarkSlateNavy = Color(0xFF0A192F)       // Deep Dark Slate Navy (#0A192F)
val DarkBackground = DarkSlateNavy
val DarkSurface = Color(0xFF112240)          // Navy Slate Card Surface
val DarkSurfaceVariant = Color(0xFF1E293B)   // Slate 800
val DarkBorder = Color(0xFF233554)           // Border in Navy Dark
val DarkTextPrimary = Color(0xFFF8FAFC)      // Slate 50 Clean Text
val DarkTextSecondary = Color(0xFF94A3B8)    // Soft Slate Gray (#94A3B8)
val SoftSlateGray = Color(0xFF94A3B8)

// Light Theme Surfaces & Text (Clean White #F8FAFC / Light Soft Gray #F1F5F9)
val CleanWhite = Color(0xFFF8FAFC)          // Clean White Light Surface (#F8FAFC)
val SoftLightGray = Color(0xFFF1F5F9)       // Light Soft Gray (#F1F5F9)
val LightBackground = CleanWhite
val LightSurface = Color(0xFFFFFFFF)        // Pure White card
val LightSurfaceVariant = SoftLightGray
val LightBorder = Color(0xFFE2E8F0)         // Slate 200 Border
val LightTextPrimary = Color(0xFF0F172A)    // High-contrast Slate 900
val LightTextSecondary = Color(0xFF64748B)  // High-contrast Slate 500

val TextFieldBgLight = SoftLightGray
val TextFieldBgDark = DarkSurfaceVariant

// Semantic Transaction Colors
val IncomeGreen = Color(0xFF10B981)         // Emerald 500
val SoftMintGreenBg = Color(0xFFECFDF5)     // Emerald 50
val SoftMintGreenBgDark = Color(0xFF064E3B)

val ExpenseRed = Color(0xFFEF4444)          // Red 500
val SoftSalmonRedBg = Color(0xFFFEF2F2)     // Red 50
val SoftSalmonRedBgDark = Color(0xFF7F1D1D)

val LoanOrange = Color(0xFFF59E0B)          // Amber 500
val SoftOrangeBg = Color(0xFFFFFBEB)        // Amber 50
val SoftOrangeBgDark = Color(0xFF78350F)

val SavingsBlue = Color(0xFF3B82F6)         // Blue 500
val SoftBlueBg = Color(0xFFEFF6FF)          // Blue 50
val SoftBlueBgDark = Color(0xFF1E3A8A)

// Charts
val ChartBlue = Color(0xFF3B82F6)
val ChartGreen = Color(0xFF10B981)
val ChartRed = Color(0xFFEF4444)
val ChartYellow = Color(0xFFF59E0B)
