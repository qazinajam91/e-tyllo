package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.BottomNavItem
import com.example.ui.theme.*

@Composable
fun ModernBottomNavBar(
    items: List<BottomNavItem>,
    currentRoute: String,
    onItemSelected: (String) -> Unit,
    tr: (String) -> String,
    modifier: Modifier = Modifier
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 6.dp,
        shadowElevation = 8.dp,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
        ),
        modifier = modifier
            .fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            items.forEach { item ->
                val isSelected = currentRoute == item.route

                // Scale spring micro-animation on tab selection
                val scale by animateFloatAsState(
                    targetValue = if (isSelected) 1.12f else 1.0f,
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioMediumBouncy,
                        stiffness = Spring.StiffnessMediumLow
                    ),
                    label = "tab_scale_${item.route}"
                )

                // Dynamic accent tint for each specific finance category
                val itemAccentColor = when (item.route) {
                    "dashboard" -> IndigoPrimary
                    "expenses" -> AccentExpenseCoral
                    "income" -> AccentSuccessGreen
                    "loans" -> AccentLoanAmber
                    "budget" -> IndigoLight
                    else -> MaterialTheme.colorScheme.primary
                }

                val animatedLabelColor by animateColorAsState(
                    targetValue = if (isSelected) itemAccentColor else MaterialTheme.colorScheme.onSurfaceVariant,
                    label = "tab_color_${item.route}"
                )

                val interactionSource = remember { MutableInteractionSource() }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier
                        .weight(1f)
                        .scale(scale)
                        .clip(RoundedCornerShape(16.dp))
                        .clickable(
                            interactionSource = interactionSource,
                            indication = ripple(bounded = true, radius = 28.dp)
                        ) {
                            onItemSelected(item.route)
                        }
                        .padding(vertical = 4.dp)
                        .testTag("bottom_nav_${item.route}")
                ) {
                    // Soft 3D Rounded Chip container
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(if (isSelected) 42.dp else 36.dp)
                            .shadow(
                                elevation = if (isSelected) 3.dp else 0.dp,
                                shape = RoundedCornerShape(12.dp),
                                clip = false
                            )
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                brush = if (isSelected) {
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            itemAccentColor.copy(alpha = 0.24f),
                                            itemAccentColor.copy(alpha = 0.08f)
                                        )
                                    )
                                } else {
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            Color.Transparent,
                                            Color.Transparent
                                        )
                                    )
                                }
                            )
                            .then(
                                if (isSelected) {
                                    Modifier.border(
                                        width = 1.dp,
                                        brush = Brush.verticalGradient(
                                            colors = listOf(
                                                itemAccentColor.copy(alpha = 0.5f),
                                                itemAccentColor.copy(alpha = 0.2f)
                                            )
                                        ),
                                        shape = RoundedCornerShape(12.dp)
                                    )
                                } else {
                                    Modifier
                                }
                            )
                    ) {
                        Icon(
                            imageVector = item.icon,
                            contentDescription = tr(item.titleKey),
                            tint = if (isSelected) itemAccentColor else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(if (isSelected) 22.dp else 20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = tr(item.titleKey),
                        fontSize = 10.5.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = animatedLabelColor,
                        maxLines = 1
                    )
                }
            }
        }
    }
}
