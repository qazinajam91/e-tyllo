package com.example.ads

import android.app.Activity
import android.content.Context
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback

class InterstitialAdManager private constructor() {

    private var interstitialAd: InterstitialAd? = null
    private var isLoading = false

    companion object {
        private const val TAG = "InterstitialAdManager"

        @Volatile
        private var instance: InterstitialAdManager? = null

        fun getInstance(): InterstitialAdManager {
            return instance ?: synchronized(this) {
                instance ?: InterstitialAdManager().also { instance = it }
            }
        }
    }

    /**
     * Preload an Interstitial Ad asynchronously.
     */
    fun loadAd(context: Context) {
        if (isLoading || interstitialAd != null) {
            return
        }

        isLoading = true
        val adRequest = AdRequest.Builder().build()
        InterstitialAd.load(
            context.applicationContext,
            AdConfig.interstitialAdUnitId,
            adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    Log.d(TAG, "Interstitial ad loaded successfully")
                    interstitialAd = ad
                    isLoading = false
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    Log.w(TAG, "Interstitial ad failed to load: ${loadAdError.message}")
                    interstitialAd = null
                    isLoading = false
                }
            }
        )
    }

    /**
     * Shows the Interstitial ad at a natural transition point (e.g. exporting reports or clearing settled loans).
     * Never interrupts quick expense entry or authentication.
     */
    fun showInterstitial(
        activity: Activity,
        onAdClosed: () -> Unit = {}
    ) {
        val ad = interstitialAd
        if (ad != null) {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    Log.d(TAG, "Interstitial ad dismissed")
                    interstitialAd = null
                    onAdClosed()
                    loadAd(activity) // Preload next interstitial
                }

                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    Log.w(TAG, "Interstitial ad failed to show: ${adError.message}")
                    interstitialAd = null
                    onAdClosed()
                    loadAd(activity)
                }

                override fun onAdShowedFullScreenContent() {
                    Log.d(TAG, "Interstitial ad shown on screen")
                }
            }
            ad.show(activity)
        } else {
            Log.d(TAG, "Interstitial ad not ready, proceeding immediately")
            onAdClosed()
            loadAd(activity)
        }
    }
}
