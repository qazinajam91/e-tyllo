package com.example.ads

import android.app.Activity
import android.content.Context
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.appopen.AppOpenAd
import java.util.Date

class AppOpenAdManager private constructor() {

    private var appOpenAd: AppOpenAd? = null
    private var isLoadingAd = false
    var isShowingAd = false
        private set
    private var loadTime: Long = 0

    companion object {
        private const val TAG = "AppOpenAdManager"
        private const val AD_TIMEOUT_HOURS = 4

        @Volatile
        private var instance: AppOpenAdManager? = null

        fun getInstance(): AppOpenAdManager {
            return instance ?: synchronized(this) {
                instance ?: AppOpenAdManager().also { instance = it }
            }
        }
    }

    /**
     * Check if an ad is currently loaded and still valid (within 4 hours).
     */
    fun isAdAvailable(): Boolean {
        val wasLoadedRecently = (Date().time - loadTime) < (AD_TIMEOUT_HOURS * 3600000L)
        return appOpenAd != null && wasLoadedRecently
    }

    /**
     * Preload an App Open ad asynchronously.
     */
    fun loadAd(context: Context) {
        if (isLoadingAd || isAdAvailable()) {
            return
        }

        isLoadingAd = true
        val request = AdRequest.Builder().build()
        AppOpenAd.load(
            context.applicationContext,
            AdConfig.appOpenAdUnitId,
            request,
            object : AppOpenAd.AppOpenAdLoadCallback() {
                override fun onAdLoaded(ad: AppOpenAd) {
                    Log.d(TAG, "App Open Ad successfully loaded")
                    appOpenAd = ad
                    isLoadingAd = false
                    loadTime = Date().time
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    Log.w(TAG, "App Open Ad failed to load: ${loadAdError.message}")
                    isLoadingAd = false
                    appOpenAd = null
                }
            }
        )
    }

    /**
     * Shows the App Open ad if available and the user is on an authorized screen.
     * Never interrupts auth flows (Sign In, Sign Up, or Email Verification).
     */
    fun showAdIfAvailable(
        activity: Activity,
        canShow: Boolean = true,
        onAdDismissed: () -> Unit = {}
    ) {
        if (!canShow) {
            Log.d(TAG, "App Open Ad skipped because auth or verification is in progress")
            onAdDismissed()
            return
        }

        if (isShowingAd) {
            Log.d(TAG, "App Open Ad is already showing")
            return
        }

        if (!isAdAvailable()) {
            Log.d(TAG, "App Open Ad not ready, requesting preload")
            onAdDismissed()
            loadAd(activity)
            return
        }

        appOpenAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                Log.d(TAG, "App Open Ad dismissed")
                appOpenAd = null
                isShowingAd = false
                onAdDismissed()
                loadAd(activity) // Preload next ad
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                Log.w(TAG, "App Open Ad failed to show: ${adError.message}")
                appOpenAd = null
                isShowingAd = false
                onAdDismissed()
                loadAd(activity)
            }

            override fun onAdShowedFullScreenContent() {
                Log.d(TAG, "App Open Ad displayed on screen")
                isShowingAd = true
            }
        }

        appOpenAd?.show(activity)
    }
}
