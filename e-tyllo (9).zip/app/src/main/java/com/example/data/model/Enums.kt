package com.example.data.model

enum class TransactionType {
    INCOME,
    EXPENSE
}

enum class LoanType {
    BORROW,
    LEND
}

enum class ThemeMode {
    LIGHT,
    DARK,
    SYSTEM
}

enum class AppLanguage {
    ENGLISH,
    URDU
}
