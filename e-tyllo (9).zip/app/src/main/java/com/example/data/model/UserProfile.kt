package com.example.data.model

data class UserProfile(
    val uid: String = "",
    val name: String = "",
    val fullName: String = "",
    val email: String = "",
    val phoneNumber: String = "",
    val age: String = "0",
    val registrationDate: String = "",
    val emailVerified: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    val displayName: String
        get() = fullName.ifBlank { name.ifBlank { "E Tyllo User" } }
}
