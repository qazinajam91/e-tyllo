package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.data.model.UserProfile
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class UserProfileRepository(context: Context) {
    private val firestore: FirebaseFirestore by lazy {
        val db = FirebaseFirestore.getInstance()
        try {
            val settings = FirebaseFirestoreSettings.Builder()
                .setPersistenceEnabled(true)
                .build()
            db.firestoreSettings = settings
        } catch (e: Exception) {
            Log.w(TAG, "Firestore offline persistence already configured or initialized", e)
        }
        db
    }

    private val prefs = context.getSharedPreferences("user_profile_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val TAG = "UserProfileRepo"
    }

    fun observeUserProfile(uid: String): Flow<UserProfile?> = callbackFlow {
        if (uid.isBlank()) {
            trySend(getOfflineUserProfile())
            close()
            return@callbackFlow
        }

        val docRef = firestore.collection("users").document(uid)
        val listener = docRef.addSnapshotListener { snapshot, error ->
            if (error != null) {
                Log.e(TAG, "Error listening to user profile changes", error)
                trySend(getOfflineUserProfile())
                return@addSnapshotListener
            }

            if (snapshot != null && snapshot.exists()) {
                val fullName = snapshot.getString("fullName") ?: snapshot.getString("name") ?: ""
                val name = snapshot.getString("name") ?: fullName
                val email = snapshot.getString("email") ?: ""
                val phone = snapshot.getString("phoneNumber") ?: ""
                val age = snapshot.get("age")?.toString() ?: "0"
                val regDate = snapshot.get("registrationDate")?.toString() ?: ""
                val emailVerified = snapshot.getBoolean("emailVerified") ?: true
                val createdAt = snapshot.getLong("createdAt") ?: System.currentTimeMillis()
                val updatedAt = snapshot.getLong("updatedAt") ?: System.currentTimeMillis()

                val profile = UserProfile(
                    uid = uid,
                    name = name,
                    fullName = fullName,
                    email = email,
                    phoneNumber = phone,
                    age = age,
                    registrationDate = regDate,
                    emailVerified = emailVerified,
                    createdAt = createdAt,
                    updatedAt = updatedAt
                )
                saveOfflineUserProfile(profile)
                trySend(profile)
            } else {
                trySend(getOfflineUserProfile())
            }
        }

        awaitClose { listener.remove() }
    }

    suspend fun handleGoogleSignInUser(
        uid: String,
        displayName: String,
        email: String,
        phoneNumber: String
    ): UserProfile {
        val now = System.currentTimeMillis()
        val dateFormatted = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(now))
        val userDocRef = firestore.collection("users").document(uid)

        return try {
            val snapshot = userDocRef.get().await()
            if (snapshot.exists()) {
                // Existing user: update updatedAt & emailVerified without overwriting existing data
                userDocRef.update(
                    mapOf(
                        "updatedAt" to now,
                        "emailVerified" to true
                    )
                ).await()

                val existingFullName = snapshot.getString("fullName") ?: snapshot.getString("name") ?: displayName
                val existingAge = snapshot.get("age")?.toString() ?: "0"
                val existingRegDate = snapshot.get("registrationDate")?.toString() ?: dateFormatted
                val createdAt = snapshot.getLong("createdAt") ?: now

                val updated = UserProfile(
                    uid = uid,
                    name = existingFullName,
                    fullName = existingFullName,
                    email = email,
                    phoneNumber = phoneNumber.ifBlank { snapshot.getString("phoneNumber") ?: "" },
                    age = existingAge,
                    registrationDate = existingRegDate,
                    emailVerified = true,
                    createdAt = createdAt,
                    updatedAt = now
                )
                saveOfflineUserProfile(updated)
                updated
            } else {
                // New user: create full user document at users/{uid}
                val newProfile = UserProfile(
                    uid = uid,
                    name = displayName.ifBlank { "Google User" },
                    fullName = displayName.ifBlank { "Google User" },
                    email = email,
                    phoneNumber = phoneNumber,
                    age = "0",
                    registrationDate = dateFormatted,
                    emailVerified = true,
                    createdAt = now,
                    updatedAt = now
                )

                val dataMap = hashMapOf<String, Any>(
                    "uid" to uid,
                    "fullName" to newProfile.fullName,
                    "name" to newProfile.name,
                    "email" to email,
                    "phoneNumber" to phoneNumber,
                    "age" to 0,
                    "registrationDate" to now,
                    "emailVerified" to true,
                    "createdAt" to now,
                    "updatedAt" to now
                )
                userDocRef.set(dataMap).await()
                saveOfflineUserProfile(newProfile)
                newProfile
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error handling Google Sign-In user in Firestore, saved locally", e)
            val fallback = UserProfile(
                uid = uid,
                name = displayName.ifBlank { "Google User" },
                fullName = displayName.ifBlank { "Google User" },
                email = email,
                phoneNumber = phoneNumber,
                age = "0",
                registrationDate = dateFormatted,
                emailVerified = true,
                createdAt = now,
                updatedAt = now
            )
            saveOfflineUserProfile(fallback)
            fallback
        }
    }

    suspend fun saveUserProfile(profile: UserProfile): Boolean {
        saveOfflineUserProfile(profile)
        if (profile.uid.isBlank()) return true

        return try {
            val dataMap = hashMapOf<String, Any>(
                "uid" to profile.uid,
                "name" to profile.name,
                "fullName" to profile.fullName.ifBlank { profile.name },
                "email" to profile.email,
                "phoneNumber" to profile.phoneNumber,
                "age" to (profile.age.toIntOrNull() ?: 0),
                "registrationDate" to profile.registrationDate,
                "emailVerified" to profile.emailVerified,
                "createdAt" to profile.createdAt,
                "updatedAt" to profile.updatedAt
            )
            firestore.collection("users").document(profile.uid)
                .set(dataMap, SetOptions.merge())
                .await()
            Log.d(TAG, "User profile saved successfully to Firestore: ${profile.uid}")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to save user profile to Firestore, saved offline", e)
            false
        }
    }

    suspend fun updateEmailVerificationStatus(uid: String, isVerified: Boolean): Boolean {
        val currentOffline = getOfflineUserProfile()
        val now = System.currentTimeMillis()
        if (currentOffline != null && currentOffline.uid == uid) {
            saveOfflineUserProfile(currentOffline.copy(emailVerified = isVerified, updatedAt = now))
        }

        if (uid.isBlank()) return true

        return try {
            firestore.collection("users").document(uid)
                .update(
                    mapOf(
                        "emailVerified" to isVerified,
                        "updatedAt" to now
                    )
                )
                .await()
            Log.d(TAG, "User email verification updated in Firestore: $isVerified")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to update email verification status in Firestore", e)
            false
        }
    }

    suspend fun updateProfileDetails(uid: String, fullName: String, phoneNumber: String, age: String): Boolean {
        val currentOffline = getOfflineUserProfile()
        val now = System.currentTimeMillis()
        val updated = currentOffline?.copy(
            name = fullName,
            fullName = fullName,
            phoneNumber = phoneNumber,
            age = age,
            updatedAt = now
        ) ?: UserProfile(
            uid = uid,
            name = fullName,
            fullName = fullName,
            phoneNumber = phoneNumber,
            age = age,
            updatedAt = now
        )

        saveOfflineUserProfile(updated)

        if (uid.isBlank()) return true

        return try {
            firestore.collection("users").document(uid)
                .update(
                    mapOf(
                        "name" to fullName,
                        "fullName" to fullName,
                        "phoneNumber" to phoneNumber,
                        "age" to (age.toIntOrNull() ?: age),
                        "updatedAt" to now
                    )
                )
                .await()
            Log.d(TAG, "User profile updated successfully in Firestore")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to update profile in Firestore, changes saved locally", e)
            false
        }
    }

    fun saveOfflineUserProfile(profile: UserProfile) {
        prefs.edit()
            .putString("uid", profile.uid)
            .putString("name", profile.name.ifBlank { profile.fullName })
            .putString("fullName", profile.fullName.ifBlank { profile.name })
            .putString("email", profile.email)
            .putString("phoneNumber", profile.phoneNumber)
            .putString("age", profile.age)
            .putString("registrationDate", profile.registrationDate)
            .putBoolean("emailVerified", profile.emailVerified)
            .putLong("createdAt", profile.createdAt)
            .putLong("updatedAt", profile.updatedAt)
            .apply()
    }

    fun getOfflineUserProfile(): UserProfile? {
        val uid = prefs.getString("uid", "") ?: ""
        val email = prefs.getString("email", "") ?: ""
        if (uid.isBlank() && email.isBlank()) return null

        val name = prefs.getString("name", "") ?: ""
        val fullName = prefs.getString("fullName", name) ?: name

        return UserProfile(
            uid = uid,
            name = name,
            fullName = fullName,
            email = email,
            phoneNumber = prefs.getString("phoneNumber", "") ?: "",
            age = prefs.getString("age", "0") ?: "0",
            registrationDate = prefs.getString("registrationDate", "") ?: "",
            emailVerified = prefs.getBoolean("emailVerified", false),
            createdAt = prefs.getLong("createdAt", System.currentTimeMillis()),
            updatedAt = prefs.getLong("updatedAt", System.currentTimeMillis())
        )
    }

    fun clearOfflineUserProfile() {
        prefs.edit().clear().apply()
    }
}
