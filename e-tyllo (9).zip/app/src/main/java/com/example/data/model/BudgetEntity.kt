package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "budget")
data class BudgetEntity(
    @PrimaryKey val id: Int = 1,
    val monthlyAmount: Double = 50000.0,
    val updatedAt: Long = System.currentTimeMillis()
)
