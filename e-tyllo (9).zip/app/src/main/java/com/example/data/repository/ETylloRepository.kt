package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.example.data.local.AppDatabase
import com.example.data.model.*
import com.example.util.AlarmScheduler
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class ETylloRepository(private val context: Context) {
    private val db = AppDatabase.getDatabase(context)
    private val transactionDao = db.transactionDao()
    private val loanDao = db.loanDao()
    private val budgetDao = db.budgetDao()
    private val categoryDao = db.categoryDao()

    private val prefs: SharedPreferences = context.getSharedPreferences("e_tyllo_prefs", Context.MODE_PRIVATE)

    private val firestore: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }
    private val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }

    companion object {
        private const val TAG = "ETylloRepository"
    }

    // Reactive Flow for Data
    val allTransactions: Flow<List<TransactionEntity>> = transactionDao.getAllTransactions()
    val allLoans: Flow<List<LoanEntity>> = loanDao.getAllLoans()
    val budget: Flow<BudgetEntity?> = budgetDao.getBudget()
    val allCategories: Flow<List<CategoryEntity>> = categoryDao.getAllCategories()

    // State Flows for User Preferences
    private val _themeMode = MutableStateFlow(getSavedThemeMode())
    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

    private val _language = MutableStateFlow(getSavedLanguage())
    val language: StateFlow<AppLanguage> = _language.asStateFlow()

    private val _isPinEnabled = MutableStateFlow(prefs.getBoolean("pin_enabled", false))
    val isPinEnabled: StateFlow<Boolean> = _isPinEnabled.asStateFlow()

    private val _pinCode = MutableStateFlow(prefs.getString("pin_code", "1234") ?: "1234")
    val pinCode: StateFlow<String> = _pinCode.asStateFlow()

    private val _isBiometricsEnabled = MutableStateFlow(prefs.getBoolean("biometrics_enabled", true))
    val isBiometricsEnabled: StateFlow<Boolean> = _isBiometricsEnabled.asStateFlow()

    private val _isSignedIn = MutableStateFlow(auth.currentUser != null || prefs.getBoolean("is_signed_in", false))
    val isSignedIn: StateFlow<Boolean> = _isSignedIn.asStateFlow()

    private val _userEmail = MutableStateFlow(auth.currentUser?.email ?: prefs.getString("user_email", "") ?: "")
    val userEmail: StateFlow<String> = _userEmail.asStateFlow()

    private val _userName = MutableStateFlow(auth.currentUser?.displayName ?: prefs.getString("user_name", "") ?: "")
    val userName: StateFlow<String> = _userName.asStateFlow()

    private val scope = CoroutineScope(Dispatchers.IO)

    init {
        // Seed default categories if needed
        scope.launch {
            seedDefaultCategories()
        }

        // Observe auth state changes
        auth.addAuthStateListener { firebaseAuth ->
            val user = firebaseAuth.currentUser
            if (user != null) {
                _isSignedIn.value = true
                _userEmail.value = user.email ?: ""
                _userName.value = user.displayName ?: prefs.getString("user_name", "") ?: ""
                prefs.edit()
                    .putBoolean("is_signed_in", true)
                    .putString("user_email", user.email)
                    .putString("user_name", _userName.value)
                    .apply()
                scope.launch { syncFirestoreDataToRoom(user.uid) }
            } else {
                _isSignedIn.value = prefs.getBoolean("is_signed_in", false)
            }
        }
    }

    private suspend fun seedDefaultCategories() {
        try {
            val existing = categoryDao.getAllCategories().firstOrNull()
            if (existing.isNullOrEmpty()) {
                val defaultExpenses = listOf("Food & Dining", "Bills & Utilities", "Transport", "Shopping", "Entertainment", "Health", "General")
                defaultExpenses.forEach { cat ->
                    categoryDao.insertCategory(CategoryEntity(name = cat, type = "EXPENSE"))
                }
                val defaultIncomes = listOf("Salary", "Freelance", "Allowance", "Company Allowance", "Business", "Investment", "Others")
                defaultIncomes.forEach { cat ->
                    categoryDao.insertCategory(CategoryEntity(name = cat, type = "INCOME"))
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error seeding categories", e)
        }
    }

    // Category CRUD
    suspend fun addCategory(name: String, type: String) {
        if (name.isBlank()) return
        categoryDao.insertCategory(CategoryEntity(name = name.trim(), type = type))
    }

    suspend fun deleteCategory(id: Long) {
        categoryDao.deleteCategory(id)
    }

    // Transactions logic with custom Date
    suspend fun addTransaction(type: String, amount: Double, category: String, dateMillis: Long, note: String) {
        val entity = TransactionEntity(
            type = type,
            amount = amount,
            category = category,
            dateMillis = dateMillis,
            note = note
        )
        val id = transactionDao.insertTransaction(entity)

        val uid = auth.currentUser?.uid ?: ""
        if (uid.isNotBlank()) {
            try {
                val txMap = mapOf(
                    "id" to id,
                    "type" to type,
                    "amount" to amount,
                    "category" to category,
                    "dateMillis" to dateMillis,
                    "note" to note
                )
                val collectionName = if (type.equals("INCOME", ignoreCase = true)) "income" else "expenses"
                firestore.collection("users").document(uid)
                    .collection(collectionName).document(id.toString())
                    .set(txMap)
                    .await()
            } catch (e: Exception) {
                Log.e(TAG, "Error syncing transaction to Firestore", e)
            }
        }
    }

    suspend fun deleteTransaction(id: Long) {
        transactionDao.deleteTransaction(id)
        val uid = auth.currentUser?.uid ?: ""
        if (uid.isNotBlank()) {
            try {
                firestore.collection("users").document(uid)
                    .collection("expenses").document(id.toString())
                    .delete()
                    .await()
                firestore.collection("users").document(uid)
                    .collection("income").document(id.toString())
                    .delete()
                    .await()
            } catch (e: Exception) {
                Log.e(TAG, "Error deleting transaction from Firestore", e)
            }
        }
    }

    // Advanced Loans logic with Partial Payments & Alarm
    suspend fun addLoan(type: String, personName: String, amount: Double, dateMillis: Long, dueDateMillis: Long, note: String) {
        val entity = LoanEntity(
            type = type, // "Gave Loan" ("LEND") or "Took Loan" ("BORROW")
            personName = personName,
            amount = amount,
            paidAmount = 0.0,
            dateMillis = dateMillis,
            dueDateMillis = dueDateMillis,
            note = note,
            isSettled = false
        )
        val id = loanDao.insertLoan(entity)

        // Schedule Alarm Reminder
        AlarmScheduler.scheduleLoanReminder(
            context = context,
            loanId = id,
            personName = personName,
            amount = amount,
            loanType = if (type.contains("Gave", true) || type == "LEND") "Gave Loan" else "Took Loan",
            dueDateMillis = dueDateMillis
        )

        val uid = auth.currentUser?.uid ?: ""
        if (uid.isNotBlank()) {
            try {
                val loanMap = mapOf(
                    "id" to id,
                    "type" to type,
                    "personName" to personName,
                    "amount" to amount,
                    "paidAmount" to 0.0,
                    "dateMillis" to dateMillis,
                    "dueDateMillis" to dueDateMillis,
                    "note" to note,
                    "isSettled" to false
                )
                firestore.collection("users").document(uid)
                    .collection("loans").document(id.toString())
                    .set(loanMap)
                    .await()
            } catch (e: Exception) {
                Log.e(TAG, "Error syncing loan to Firestore", e)
            }
        }
    }

    suspend fun addLoanPayment(loanId: Long, paymentAmount: Double) {
        val loans = loanDao.getAllLoans().firstOrNull() ?: return
        val existing = loans.find { it.id == loanId } ?: return

        val newPaid = existing.paidAmount + paymentAmount
        val isCleared = newPaid >= existing.amount
        val updated = existing.copy(
            paidAmount = newPaid,
            isSettled = isCleared
        )

        loanDao.updateLoan(updated)

        val uid = auth.currentUser?.uid ?: ""
        if (uid.isNotBlank()) {
            try {
                firestore.collection("users").document(uid)
                    .collection("loans").document(loanId.toString())
                    .update(
                        mapOf(
                            "paidAmount" to newPaid,
                            "isSettled" to isCleared
                        )
                    )
                    .await()
            } catch (e: Exception) {
                Log.e(TAG, "Error updating loan payment in Firestore", e)
            }
        }
    }

    suspend fun deleteLoan(id: Long) {
        loanDao.deleteLoan(id)
        val uid = auth.currentUser?.uid ?: ""
        if (uid.isNotBlank()) {
            try {
                firestore.collection("users").document(uid)
                    .collection("loans").document(id.toString())
                    .delete()
                    .await()
            } catch (e: Exception) {
                Log.e(TAG, "Error deleting loan from Firestore", e)
            }
        }
    }

    // Budget logic
    suspend fun setBudgetAmount(amount: Double) {
        budgetDao.setBudget(BudgetEntity(id = 1, monthlyAmount = amount))
        val uid = auth.currentUser?.uid ?: ""
        if (uid.isNotBlank()) {
            try {
                firestore.collection("users").document(uid)
                    .collection("budgets").document("current")
                    .set(mapOf("monthlyAmount" to amount))
                    .await()
            } catch (e: Exception) {
                Log.e(TAG, "Error syncing budget to Firestore", e)
            }
        }
    }

    private suspend fun syncFirestoreDataToRoom(uid: String) {
        try {
            // Fetch Expenses
            val expensesSnapshot = firestore.collection("users").document(uid)
                .collection("expenses").get().await()
            for (doc in expensesSnapshot.documents) {
                val type = doc.getString("type") ?: "EXPENSE"
                val amount = doc.getDouble("amount") ?: 0.0
                val category = doc.getString("category") ?: "General"
                val dateMillis = doc.getLong("dateMillis") ?: System.currentTimeMillis()
                val note = doc.getString("note") ?: ""
                val id = doc.id.toLongOrNull() ?: 0L

                val tx = TransactionEntity(id = id, type = type, amount = amount, category = category, dateMillis = dateMillis, note = note)
                transactionDao.insertTransaction(tx)
            }

            // Fetch Income
            val incomeSnapshot = firestore.collection("users").document(uid)
                .collection("income").get().await()
            for (doc in incomeSnapshot.documents) {
                val type = doc.getString("type") ?: "INCOME"
                val amount = doc.getDouble("amount") ?: 0.0
                val category = doc.getString("category") ?: "Salary"
                val dateMillis = doc.getLong("dateMillis") ?: System.currentTimeMillis()
                val note = doc.getString("note") ?: ""
                val id = doc.id.toLongOrNull() ?: 0L

                val tx = TransactionEntity(id = id, type = type, amount = amount, category = category, dateMillis = dateMillis, note = note)
                transactionDao.insertTransaction(tx)
            }

            // Fetch Loans
            val loansSnapshot = firestore.collection("users").document(uid)
                .collection("loans").get().await()
            for (doc in loansSnapshot.documents) {
                val type = doc.getString("type") ?: "BORROW"
                val personName = doc.getString("personName") ?: "Unknown"
                val amount = doc.getDouble("amount") ?: 0.0
                val paidAmount = doc.getDouble("paidAmount") ?: 0.0
                val dateMillis = doc.getLong("dateMillis") ?: System.currentTimeMillis()
                val dueDateMillis = doc.getLong("dueDateMillis") ?: System.currentTimeMillis()
                val note = doc.getString("note") ?: ""
                val isSettled = doc.getBoolean("isSettled") ?: false
                val id = doc.id.toLongOrNull() ?: 0L

                val loan = LoanEntity(
                    id = id,
                    type = type,
                    personName = personName,
                    amount = amount,
                    paidAmount = paidAmount,
                    dateMillis = dateMillis,
                    dueDateMillis = dueDateMillis,
                    note = note,
                    isSettled = isSettled
                )
                loanDao.insertLoan(loan)
            }

            // Fetch Budget (check both budgets and budget for backward compatibility)
            var budgetDoc = firestore.collection("users").document(uid)
                .collection("budgets").document("current").get().await()
            if (!budgetDoc.exists()) {
                budgetDoc = firestore.collection("users").document(uid)
                    .collection("budget").document("current").get().await()
            }
            if (budgetDoc.exists()) {
                val monthlyAmount = budgetDoc.getDouble("monthlyAmount") ?: 50000.0
                budgetDao.setBudget(BudgetEntity(id = 1, monthlyAmount = monthlyAmount))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error pulling data from Firestore", e)
        }
    }

    // Settings mutators
    fun setThemeMode(mode: ThemeMode) {
        prefs.edit().putString("theme_mode", mode.name).apply()
        _themeMode.value = mode
    }

    fun setLanguage(lang: AppLanguage) {
        prefs.edit().putString("app_language", lang.name).apply()
        _language.value = lang
    }

    fun setPinEnabled(enabled: Boolean, code: String = "1234") {
        prefs.edit().putBoolean("pin_enabled", enabled).putString("pin_code", code).apply()
        _isPinEnabled.value = enabled
        _pinCode.value = code
    }

    fun setBiometricsEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("biometrics_enabled", enabled).apply()
        _isBiometricsEnabled.value = enabled
    }

    fun setSignedIn(signedIn: Boolean, email: String = "", name: String = "") {
        prefs.edit()
            .putBoolean("is_signed_in", signedIn)
            .putString("user_email", email)
            .putString("user_name", name)
            .apply()
        _isSignedIn.value = signedIn
        _userEmail.value = email
        _userName.value = name
    }

    private fun getSavedThemeMode(): ThemeMode {
        val saved = prefs.getString("theme_mode", ThemeMode.DARK.name) ?: ThemeMode.DARK.name
        return try {
            ThemeMode.valueOf(saved)
        } catch (e: Exception) {
            ThemeMode.DARK
        }
    }

    private fun getSavedLanguage(): AppLanguage {
        val saved = prefs.getString("app_language", AppLanguage.ENGLISH.name) ?: AppLanguage.ENGLISH.name
        return try {
            AppLanguage.valueOf(saved)
        } catch (e: Exception) {
            AppLanguage.ENGLISH
        }
    }
}
