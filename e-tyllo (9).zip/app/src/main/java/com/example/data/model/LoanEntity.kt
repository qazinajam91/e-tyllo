package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "loans")
data class LoanEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val type: String, // "BORROW" ("Took Loan") or "LEND" ("Gave Loan")
    val personName: String,
    val amount: Double,
    val paidAmount: Double = 0.0,
    val dateMillis: Long,
    val dueDateMillis: Long,
    val note: String = "",
    val isSettled: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
) {
    val remainingAmount: Double
        get() = (amount - paidAmount).coerceAtLeast(0.0)

    val isCleared: Boolean
        get() = isSettled || (remainingAmount <= 0.0)
}
