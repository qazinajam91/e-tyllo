package com.example.util

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log

object AlarmScheduler {
    fun scheduleLoanReminder(
        context: Context,
        loanId: Long,
        personName: String,
        amount: Double,
        loanType: String,
        dueDateMillis: Long
    ) {
        if (dueDateMillis <= System.currentTimeMillis()) return

        try {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val intent = Intent(context, LoanReminderReceiver::class.java).apply {
                putExtra("loanId", loanId)
                putExtra("personName", personName)
                putExtra("amount", amount)
                putExtra("loanType", loanType)
            }

            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            } else {
                PendingIntent.FLAG_UPDATE_CURRENT
            }

            val pendingIntent = PendingIntent.getBroadcast(
                context,
                loanId.toInt(),
                intent,
                flags
            )

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    dueDateMillis,
                    pendingIntent
                )
            } else {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    dueDateMillis,
                    pendingIntent
                )
            }
            Log.d("AlarmScheduler", "Scheduled loan reminder alarm for $personName at $dueDateMillis")
        } catch (e: Exception) {
            Log.e("AlarmScheduler", "Failed to schedule alarm", e)
        }
    }
}
