package com.example.util

import android.app.KeyguardManager
import android.content.Context
import android.hardware.biometrics.BiometricManager
import android.os.Build
import androidx.core.hardware.fingerprint.FingerprintManagerCompat

object BiometricHelper {

    fun isBiometricAvailable(context: Context): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val biometricManager = context.getSystemService(Context.BIOMETRIC_SERVICE) as? BiometricManager
            if (biometricManager != null) {
                val canAuth = biometricManager.canAuthenticate()
                if (canAuth == BiometricManager.BIOMETRIC_SUCCESS) {
                    return true
                }
            }
        }
        val fingerprintManager = FingerprintManagerCompat.from(context)
        if (fingerprintManager.isHardwareDetected && fingerprintManager.hasEnrolledFingerprints()) {
            return true
        }

        val keyguardManager = context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        return keyguardManager?.isKeyguardSecure == true
    }
}
