package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.util.Log
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.model.LoanEntity
import com.example.data.model.TransactionEntity
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

object PdfGenerator {
    private const val TAG = "PdfGenerator"

    fun generateAndOpenReportPdf(
        context: Context,
        monthName: String,
        year: Int,
        day: Int? = null,
        totalIncome: Double,
        totalExpense: Double,
        totalLent: Double = 0.0,
        totalBorrowed: Double = 0.0,
        transactions: List<TransactionEntity>,
        loans: List<LoanEntity> = emptyList()
    ) {
        try {
            val pdfDocument = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // Standard A4 size
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            val titlePaint = Paint().apply {
                color = Color.parseColor("#10B981") // Emerald Green
                textSize = 20f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }

            val subtitlePaint = Paint().apply {
                color = Color.DKGRAY
                textSize = 11f
            }

            val headerBgPaint = Paint().apply {
                color = Color.parseColor("#F3F4F6")
            }

            val sectionBgPaint = Paint().apply {
                color = Color.parseColor("#E5E7EB")
            }

            val textBoldPaint = Paint().apply {
                color = Color.BLACK
                textSize = 10f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }

            val textPaint = Paint().apply {
                color = Color.BLACK
                textSize = 9.5f
            }

            val incomePaint = Paint().apply {
                color = Color.parseColor("#10B981")
                textSize = 9.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }

            val expensePaint = Paint().apply {
                color = Color.parseColor("#EF4444")
                textSize = 9.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }

            val amberPaint = Paint().apply {
                color = Color.parseColor("#D97706")
                textSize = 9.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }

            val linePaint = Paint().apply {
                color = Color.LTGRAY
                strokeWidth = 1f
            }

            val footerPaint = Paint().apply {
                color = Color.GRAY
                textSize = 8.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                textAlign = Paint.Align.CENTER
            }

            var y = 35f

            // App Header & Title
            canvas.drawText("E TYLLO EXPENSE MANAGER", 40f, y, titlePaint)
            y += 16f
            val periodText = if (day != null) "Financial Report: $day $monthName $year" else "Financial Report: $monthName $year"
            canvas.drawText(periodText, 40f, y, subtitlePaint)
            y += 14f
            val dateStr = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date())
            canvas.drawText("Generated on: $dateStr", 40f, y, subtitlePaint)
            y += 18f

            // Summary Card (Transactions & Loans overview)
            canvas.drawRect(40f, y, 555f, y + 54f, headerBgPaint)
            val net = totalIncome - totalExpense
            val summaryTitle = if (day != null) "Daily Summary" else "Monthly Summary"
            canvas.drawText(summaryTitle, 50f, y + 16f, textBoldPaint)
            canvas.drawText("Income: Rs ${totalIncome.toInt()}", 50f, y + 34f, incomePaint)
            canvas.drawText("Expense: Rs ${totalExpense.toInt()}", 160f, y + 34f, expensePaint)
            val netColor = if (net >= 0) incomePaint else expensePaint
            canvas.drawText("Net: Rs ${net.toInt()}", 270f, y + 34f, netColor)
            canvas.drawText("Lent: Rs ${totalLent.toInt()}", 370f, y + 34f, amberPaint)
            canvas.drawText("Borrowed: Rs ${totalBorrowed.toInt()}", 465f, y + 34f, amberPaint)
            y += 66f

            // Transactions Table Section
            canvas.drawRect(40f, y, 555f, y + 20f, sectionBgPaint)
            canvas.drawText("TRANSACTIONS BREAKDOWN (${transactions.size})", 50f, y + 14f, textBoldPaint)
            y += 24f

            // Table Header
            canvas.drawRect(40f, y, 555f, y + 20f, headerBgPaint)
            canvas.drawText("Date", 50f, y + 14f, textBoldPaint)
            canvas.drawText("Type", 130f, y + 14f, textBoldPaint)
            canvas.drawText("Category", 210f, y + 14f, textBoldPaint)
            canvas.drawText("Amount", 350f, y + 14f, textBoldPaint)
            canvas.drawText("Note", 440f, y + 14f, textBoldPaint)
            y += 24f

            val dateFormat = SimpleDateFormat("dd MMM", Locale.getDefault())

            val maxTransactionsToShow = if (loans.isEmpty()) 20 else 12
            val txSubset = transactions.take(maxTransactionsToShow)

            for (tx in txSubset) {
                val dateFormatted = dateFormat.format(Date(tx.dateMillis))
                val isIncome = tx.type.uppercase() == "INCOME"

                canvas.drawText(dateFormatted, 50f, y, textPaint)
                canvas.drawText(if (isIncome) "Income" else "Expense", 130f, y, if (isIncome) incomePaint else expensePaint)
                canvas.drawText(tx.category.take(18), 210f, y, textPaint)
                canvas.drawText("Rs ${tx.amount.toInt()}", 350f, y, if (isIncome) incomePaint else expensePaint)
                canvas.drawText(tx.note.take(16), 440f, y, textPaint)

                y += 6f
                canvas.drawLine(40f, y, 555f, y, linePaint)
                y += 14f
            }

            if (transactions.size > maxTransactionsToShow) {
                canvas.drawText("...and ${transactions.size - maxTransactionsToShow} more transactions", 50f, y, subtitlePaint)
                y += 16f
            }

            if (transactions.isEmpty()) {
                canvas.drawText("No transactions in this period", 50f, y, subtitlePaint)
                y += 16f
            }

            y += 10f

            // Loans Section (if loans present)
            if (loans.isNotEmpty() && y < 700f) {
                canvas.drawRect(40f, y, 555f, y + 20f, sectionBgPaint)
                canvas.drawText("LOANS & BORROWINGS (${loans.size})", 50f, y + 14f, textBoldPaint)
                y += 24f

                canvas.drawRect(40f, y, 555f, y + 20f, headerBgPaint)
                canvas.drawText("Person", 50f, y + 14f, textBoldPaint)
                canvas.drawText("Type", 170f, y + 14f, textBoldPaint)
                canvas.drawText("Total", 270f, y + 14f, textBoldPaint)
                canvas.drawText("Remaining", 370f, y + 14f, textBoldPaint)
                canvas.drawText("Status", 470f, y + 14f, textBoldPaint)
                y += 24f

                for (loan in loans.take(8)) {
                    val isLent = loan.type.contains("LEND", true) || loan.type.contains("Gave", true)
                    val typeLabel = if (isLent) "Lent" else "Borrowed"
                    val statusLabel = if (loan.isCleared) "Cleared" else "Pending"

                    canvas.drawText(loan.personName.take(16), 50f, y, textPaint)
                    canvas.drawText(typeLabel, 170f, y, if (isLent) incomePaint else amberPaint)
                    canvas.drawText("Rs ${loan.amount.toInt()}", 270f, y, textPaint)
                    canvas.drawText("Rs ${loan.remainingAmount.toInt()}", 370f, y, if (loan.isCleared) incomePaint else expensePaint)
                    canvas.drawText(statusLabel, 470f, y, if (loan.isCleared) incomePaint else amberPaint)

                    y += 6f
                    canvas.drawLine(40f, y, 555f, y, linePaint)
                    y += 14f
                }
            }

            // Developer Credit Footer (discreet, centered, bottom of page)
            val footerY = pageInfo.pageHeight - 24f
            canvas.drawText(
                "Developed By Qazi Najam Lead Developer and Architect",
                pageInfo.pageWidth / 2f,
                footerY,
                footerPaint
            )

            pdfDocument.finishPage(page)

            val fileNameSuffix = if (day != null) "${day}_${monthName}_$year" else "${monthName}_$year"
            val pdfFile = File(context.cacheDir, "E_Tyllo_Report_$fileNameSuffix.pdf")
            val outputStream = FileOutputStream(pdfFile)
            pdfDocument.writeTo(outputStream)
            pdfDocument.close()
            outputStream.close()

            // Open or share PDF via Intent
            val contentUri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.provider",
                pdfFile
            )

            val shareIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(contentUri, "application/pdf")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            val chooser = Intent.createChooser(shareIntent, "Open PDF Report")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)

        } catch (e: Exception) {
            Log.e(TAG, "Error generating PDF report", e)
            Toast.makeText(context, "Failed to generate PDF: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }
}
