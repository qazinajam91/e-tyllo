package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TransactionEntity
import com.example.ui.components.AdBannerCard
import com.example.ui.components.DonutChart
import com.example.ui.components.PieSegment
import com.example.ui.components.WeeklyTrendChart
import com.example.ui.theme.*

@Composable
fun DashboardScreen(
    todayIncome: Double,
    todayExpense: Double,
    todaySavings: Double,
    todayNet: Double,
    monthlyIncome: Double,
    monthlyExpense: Double,
    monthlyNet: Double,
    budgetAmount: Double,
    recentTransactions: List<TransactionEntity>,
    onAddExpenseClick: () -> Unit,
    onAddIncomeClick: () -> Unit,
    onAddLoanClick: () -> Unit,
    onSetBudgetClick: () -> Unit,
    onViewAllTransactions: () -> Unit,
    tr: (String) -> String
) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        visible = true
    }

    val isDark = isSystemInDarkTheme()

    AnimatedVisibility(
        visible = visible,
        enter = fadeIn() + slideInVertically(initialOffsetY = { it / 6 })
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // TODAY Section Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = tr("today").uppercase(),
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    letterSpacing = 1.2.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = TealPrimary.copy(alpha = 0.12f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(TealPrimary)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = tr("today_pulse"),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = TealPrimary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 2x2 Grid for TODAY - High Contrast Clean Cards
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Today's Income Card
                    EvolvedDashboardStatCard(
                        title = tr("todays_income"),
                        amount = "Rs ${todayIncome.toInt()}",
                        icon = Icons.Default.ArrowUpward,
                        accentColor = IncomeGreen,
                        modifier = Modifier.weight(1f).testTag("todays_income_card")
                    )

                    // Today's Expense Card
                    EvolvedDashboardStatCard(
                        title = tr("todays_expense"),
                        amount = "Rs ${todayExpense.toInt()}",
                        icon = Icons.Default.ArrowDownward,
                        accentColor = ExpenseRed,
                        modifier = Modifier.weight(1f).testTag("todays_expense_card")
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Today's Savings Card
                    EvolvedDashboardStatCard(
                        title = tr("todays_savings"),
                        amount = "Rs ${todaySavings.toInt()}",
                        icon = Icons.Default.Savings,
                        accentColor = SavingsBlue,
                        modifier = Modifier.weight(1f).testTag("todays_savings_card")
                    )

                    // Profit / Loss Card
                    EvolvedDashboardStatCard(
                        title = tr("profit_loss"),
                        amount = "Rs ${todayNet.toInt()}",
                        icon = Icons.Default.AccountBalanceWallet,
                        accentColor = TealPrimary,
                        modifier = Modifier.weight(1f).testTag("profit_loss_card")
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // THIS MONTH Section
            Text(
                text = tr("this_month").uppercase(),
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                letterSpacing = 1.2.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))

            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 2.dp,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(18.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = tr("monthly_income"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "Rs ${monthlyIncome.toInt()}", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = IncomeGreen)
                    }
                    HorizontalDivider(modifier = Modifier.height(36.dp).width(1.dp), color = MaterialTheme.colorScheme.outlineVariant)
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = tr("monthly_expense"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "Rs ${monthlyExpense.toInt()}", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = ExpenseRed)
                    }
                    HorizontalDivider(modifier = Modifier.height(36.dp).width(1.dp), color = MaterialTheme.colorScheme.outlineVariant)
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = tr("monthly_net"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Rs ${monthlyNet.toInt()}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // QUICK ACTIONS Section
            Text(
                text = tr("quick_actions").uppercase(),
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                letterSpacing = 1.2.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Add Expense Button
                Surface(
                    onClick = onAddExpenseClick,
                    shape = RoundedCornerShape(16.dp),
                    color = ExpenseRed.copy(alpha = if (isDark) 0.18f else 0.08f),
                    border = BorderStroke(1.dp, ExpenseRed.copy(alpha = 0.3f)),
                    modifier = Modifier.weight(1f).height(48.dp).testTag("quick_add_expense")
                ) {
                    Row(
                        modifier = Modifier.fillMaxSize().padding(horizontal = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.RemoveCircleOutline,
                            contentDescription = null,
                            tint = ExpenseRed,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = tr("add_expense"),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = ExpenseRed
                        )
                    }
                }

                // Add Income Button
                Surface(
                    onClick = onAddIncomeClick,
                    shape = RoundedCornerShape(16.dp),
                    color = IncomeGreen.copy(alpha = if (isDark) 0.18f else 0.08f),
                    border = BorderStroke(1.dp, IncomeGreen.copy(alpha = 0.3f)),
                    modifier = Modifier.weight(1f).height(48.dp).testTag("quick_add_income")
                ) {
                    Row(
                        modifier = Modifier.fillMaxSize().padding(horizontal = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddCircleOutline,
                            contentDescription = null,
                            tint = IncomeGreen,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = tr("add_income"),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = IncomeGreen
                        )
                    }
                }

                // Add Loan Button
                Surface(
                    onClick = onAddLoanClick,
                    shape = RoundedCornerShape(16.dp),
                    color = LoanOrange.copy(alpha = if (isDark) 0.18f else 0.08f),
                    border = BorderStroke(1.dp, LoanOrange.copy(alpha = 0.3f)),
                    modifier = Modifier.weight(1f).height(48.dp).testTag("quick_add_loan")
                ) {
                    Row(
                        modifier = Modifier.fillMaxSize().padding(horizontal = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PeopleOutline,
                            contentDescription = null,
                            tint = LoanOrange,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = tr("add_loan"),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = LoanOrange
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Budget Status Card
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 2.dp,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = tr("budget_status"), fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
                            Text(text = tr("budget_monthly"), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        TextButton(onClick = onSetBudgetClick) {
                            Text(text = tr("set_budget"), color = TealPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    val usedPct = if (budgetAmount > 0) (monthlyExpense / budgetAmount).coerceIn(0.0, 1.0).toFloat() else 0f
                    val remaining = (budgetAmount - monthlyExpense).coerceAtLeast(0.0)

                    LinearProgressIndicator(
                        progress = { usedPct },
                        modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)),
                        color = if (usedPct > 0.85f) ExpenseRed else TealPrimary,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "${tr("used")}: Rs ${monthlyExpense.toInt()}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(text = "${tr("remaining")}: Rs ${remaining.toInt()}", fontSize = 12.sp, color = TealPrimary, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Weekly Trend Chart Card
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 2.dp,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(text = tr("weekly_trend"), fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
                    Spacer(modifier = Modifier.height(12.dp))
                    WeeklyTrendChart()
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Expense Breakdown Donut Chart Card
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 2.dp,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(text = tr("expense_breakdown"), fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
                    Spacer(modifier = Modifier.height(12.dp))
                    DonutChart(
                        segments = listOf(
                            PieSegment("Travel", 230.0, TealPrimary),
                            PieSegment("Food", 170.0, RoseCoral)
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // AdMob Native / Banner Ad Card
            AdBannerCard()

            Spacer(modifier = Modifier.height(24.dp))

            // Recent Activity / Transactions Feed
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = tr("recent_activity"),
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = tr("view_all"),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = TealPrimary,
                    modifier = Modifier.clickable { onViewAllTransactions() }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (recentTransactions.isEmpty()) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
                        Text(text = "No recent transactions", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else {
                recentTransactions.take(5).forEach { tx ->
                    EvolvedTransactionListItem(transaction = tx)
                    Spacer(modifier = Modifier.height(10.dp))
                }
            }

            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}

@Composable
fun EvolvedDashboardStatCard(
    title: String,
    amount: String,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    val isDark = isSystemInDarkTheme()
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 2.dp,
        border = BorderStroke(
            1.dp,
            MaterialTheme.colorScheme.outlineVariant.copy(alpha = if (isDark) 0.3f else 0.6f)
        ),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = title,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(accentColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = accentColor,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = amount,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
fun EvolvedTransactionListItem(transaction: TransactionEntity) {
    val isExpense = transaction.type == "EXPENSE"
    val icon = when (transaction.category) {
        "Travel" -> Icons.Default.DirectionsCar
        "Food" -> Icons.Default.Fastfood
        "Fuel" -> Icons.Default.LocalGasStation
        "Hotel" -> Icons.Default.Hotel
        "Medicine" -> Icons.Default.MedicalServices
        "Shopping" -> Icons.Default.ShoppingBag
        "Company Allowance", "Salary" -> Icons.Default.AccountBalanceWallet
        else -> Icons.Default.Category
    }

    Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 1.dp,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(if (isExpense) ExpenseRed.copy(alpha = 0.12f) else IncomeGreen.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = transaction.category,
                    tint = if (isExpense) ExpenseRed else IncomeGreen,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = transaction.category,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                if (transaction.note.isNotBlank()) {
                    Text(
                        text = transaction.note,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Text(
                text = if (isExpense) "-Rs ${transaction.amount.toInt()}" else "+Rs ${transaction.amount.toInt()}",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = if (isExpense) ExpenseRed else IncomeGreen
            )
        }
    }
}
