package com.example.ui.screens

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import android.util.Log
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.components.AdBannerCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.ETylloViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.*

data class ExtractedReceiptItem(
    var name: String,
    var price: Double
)

data class ReceiptCategory(
    val name: String,
    val icon: ImageVector,
    val color: Color
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImportReceiptScreen(
    viewModel: ETylloViewModel,
    tr: (String) -> String
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    var capturedBitmap by remember { mutableStateOf<Bitmap?>(null) }

    var isAnalyzing by remember { mutableStateOf(false) }
    var analysisStatus by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Extracted / Form Data
    var hasExtractedData by remember { mutableStateOf(false) }
    var merchantName by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Shopping") }
    var totalAmountStr by remember { mutableStateOf("") }
    var receiptDateMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var lineItems by remember { mutableStateOf(listOf<ExtractedReceiptItem>()) }
    var saveIndividually by remember { mutableStateOf(false) }

    // Gallery Picker Launcher
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedImageUri = uri
            capturedBitmap = null
            errorMessage = null
            hasExtractedData = false
        }
    }

    // Camera Capture Launcher
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap: Bitmap? ->
        if (bitmap != null) {
            capturedBitmap = bitmap
            selectedImageUri = null
            errorMessage = null
            hasExtractedData = false
        }
    }

    val categories = listOf(
        ReceiptCategory("Food", Icons.Default.Fastfood, Color(0xFFFF9800)),
        ReceiptCategory("Fuel", Icons.Default.LocalGasStation, Color(0xFF2196F3)),
        ReceiptCategory("Hotel", Icons.Default.Hotel, Color(0xFF9C27B0)),
        ReceiptCategory("Medicine", Icons.Default.Medication, Color(0xFFE91E63)),
        ReceiptCategory("Travel", Icons.Default.DirectionsCar, Color(0xFF00BCD4)),
        ReceiptCategory("Shopping", Icons.Default.ShoppingCart, Color(0xFF4CAF50)),
        ReceiptCategory("Bills", Icons.Default.Receipt, Color(0xFF607D8B))
    )

    fun decodeBitmap(): Bitmap? {
        return capturedBitmap ?: selectedImageUri?.let { uri ->
            try {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    BitmapFactory.decodeStream(stream)
                }
            } catch (e: Exception) {
                Log.e("ImportReceiptScreen", "Failed to decode bitmap from URI", e)
                null
            }
        }
    }

    fun analyzeReceipt() {
        val bitmap = decodeBitmap()
        if (bitmap == null) {
            Toast.makeText(context, "Please select or take a photo of a receipt first", Toast.LENGTH_SHORT).show()
            return
        }

        isAnalyzing = true
        errorMessage = null
        analysisStatus = "Reading receipt with AI..."

        coroutineScope.launch {
            try {
                // Call Gemini / AI OCR extraction
                val result = withContext(Dispatchers.IO) {
                    processReceiptImageWithAI(context, bitmap)
                }

                merchantName = result.optString("merchant", "Store Receipt").ifBlank { "Store Receipt" }
                val detectedCat = result.optString("category", "Shopping")
                selectedCategory = if (categories.any { it.name.equals(detectedCat, ignoreCase = true) }) {
                    categories.first { it.name.equals(detectedCat, ignoreCase = true) }.name
                } else {
                    "Shopping"
                }

                val detectedTotal = result.optDouble("total", 0.0)
                totalAmountStr = if (detectedTotal > 0) detectedTotal.toInt().toString() else "0"

                val itemsList = mutableListOf<ExtractedReceiptItem>()
                val itemsArray = result.optJSONArray("items")
                if (itemsArray != null) {
                    for (i in 0 until itemsArray.length()) {
                        val itemObj = itemsArray.optJSONObject(i)
                        if (itemObj != null) {
                            val name = itemObj.optString("name", "Item ${i + 1}")
                            val price = itemObj.optDouble("price", 0.0)
                            itemsList.add(ExtractedReceiptItem(name, price))
                        }
                    }
                }

                if (itemsList.isEmpty() && detectedTotal > 0) {
                    itemsList.add(ExtractedReceiptItem(merchantName, detectedTotal))
                }

                lineItems = itemsList
                hasExtractedData = true
                analysisStatus = ""
                Toast.makeText(context, "Receipt analyzed successfully! Review details below.", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Log.e("ImportReceiptScreen", "AI receipt analysis failed", e)
                errorMessage = "Could not automatically read all fields (${e.localizedMessage ?: "Unknown"}). You can edit or enter receipt details manually below."
                hasExtractedData = true // Allow manual fallback
                if (merchantName.isBlank()) merchantName = "Store Receipt"
            } finally {
                isAnalyzing = false
            }
        }
    }

    fun saveExpenses() {
        val totalAmount = totalAmountStr.toDoubleOrNull() ?: 0.0
        if (totalAmount <= 0 && lineItems.isEmpty()) {
            Toast.makeText(context, "Please enter a valid amount", Toast.LENGTH_SHORT).show()
            return
        }

        if (saveIndividually && lineItems.isNotEmpty()) {
            // Save each item as a separate expense
            lineItems.forEach { item ->
                if (item.price > 0) {
                    val note = if (merchantName.isNotBlank()) "${item.name} ($merchantName)" else item.name
                    viewModel.addExpense(item.price, selectedCategory, receiptDateMillis, note)
                }
            }
            Toast.makeText(context, "Saved ${lineItems.size} items as individual expenses!", Toast.LENGTH_LONG).show()
        } else {
            // Save as a single combined expense
            val itemsSummary = if (lineItems.isNotEmpty()) {
                lineItems.joinToString(", ") { "${it.name}: Rs ${it.price.toInt()}" }
            } else ""
            val note = if (itemsSummary.isNotBlank()) "$merchantName ($itemsSummary)" else merchantName
            val amountToSave = if (totalAmount > 0) totalAmount else lineItems.sumOf { it.price }
            viewModel.addExpense(amountToSave, selectedCategory, receiptDateMillis, note)
            Toast.makeText(context, "Saved expense of Rs ${amountToSave.toInt()} successfully!", Toast.LENGTH_LONG).show()
        }

        // Reset state
        selectedImageUri = null
        capturedBitmap = null
        hasExtractedData = false
        merchantName = ""
        totalAmountStr = ""
        lineItems = emptyList()
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header Card
        item {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 2.dp,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(EmeraldPrimary.copy(alpha = 0.15f), RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.DocumentScanner,
                                contentDescription = null,
                                tint = EmeraldPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Smart Receipt Scanner",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Snap a photo of your receipt to auto-fill expense details",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Buttons: Take Photo / Gallery
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { cameraLauncher.launch(null) },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("take_photo_button")
                        ) {
                            Icon(imageVector = Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Take Photo", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = { galleryLauncher.launch("image/*") },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("gallery_picker_button")
                        ) {
                            Icon(imageVector = Icons.Default.PhotoLibrary, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Gallery", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = EmeraldPrimary)
                        }
                    }
                }
            }
        }

        // Image Preview Card (if an image is selected/captured)
        if (selectedImageUri != null || capturedBitmap != null) {
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    shadowElevation = 2.dp,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Receipt Photo Selected",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.align(Alignment.Start)
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(180.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant),
                            contentAlignment = Alignment.Center
                        ) {
                            if (capturedBitmap != null) {
                                Image(
                                    bitmap = capturedBitmap!!.asImageBitmap(),
                                    contentDescription = "Receipt Image",
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else if (selectedImageUri != null) {
                                AsyncImage(
                                    model = selectedImageUri,
                                    contentDescription = "Receipt Image",
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = { analyzeReceipt() },
                            enabled = !isAnalyzing,
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("scan_receipt_ai_button")
                        ) {
                            if (isAnalyzing) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Analyzing Receipt...", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            } else {
                                Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, tint = Color.White)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Extract with AI", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                        }
                    }
                }
            }
        }

        // Error message if any
        if (errorMessage != null) {
            item {
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = errorMessage ?: "",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }
        }

        // Extracted / Editable Form
        if (hasExtractedData || (selectedImageUri == null && capturedBitmap == null)) {
            item {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = MaterialTheme.colorScheme.surface,
                    shadowElevation = 2.dp,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Expense Details",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            if (hasExtractedData) {
                                Surface(
                                    color = EmeraldPrimary.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = "AI Extracted",
                                        color = EmeraldPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Merchant / Store Name
                        OutlinedTextField(
                            value = merchantName,
                            onValueChange = { merchantName = it },
                            label = { Text("Store / Merchant Name") },
                            leadingIcon = { Icon(Icons.Default.Storefront, contentDescription = null, tint = EmeraldPrimary) },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("receipt_merchant_input")
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Total Amount
                        OutlinedTextField(
                            value = totalAmountStr,
                            onValueChange = { totalAmountStr = it.filter { ch -> ch.isDigit() || ch == '.' } },
                            label = { Text("Total Amount (Rs)") },
                            leadingIcon = { Icon(Icons.Default.AttachMoney, contentDescription = null, tint = EmeraldPrimary) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("receipt_amount_input")
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Category Chips
                        Text(
                            text = "Category",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            categories.forEach { cat ->
                                val isSelected = selectedCategory.equals(cat.name, ignoreCase = true)
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { selectedCategory = cat.name },
                                    label = { Text(cat.name, fontSize = 12.sp) },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = cat.icon,
                                            contentDescription = null,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = EmeraldPrimary,
                                        selectedLabelColor = Color.White,
                                        selectedLeadingIconColor = Color.White
                                    )
                                )
                            }
                        }

                        // Line items (if any extracted)
                        if (lineItems.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(14.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Line Items (${lineItems.size})",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                TextButton(
                                    onClick = {
                                        lineItems = lineItems + ExtractedReceiptItem("New Item", 0.0)
                                    }
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Add Item", fontSize = 12.sp)
                                }
                            }

                            lineItems.forEachIndexed { index, item ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedTextField(
                                        value = item.name,
                                        onValueChange = { newName ->
                                            lineItems = lineItems.toMutableList().also {
                                                it[index] = it[index].copy(name = newName)
                                            }
                                        },
                                        placeholder = { Text("Item name") },
                                        singleLine = true,
                                        modifier = Modifier.weight(1.5f),
                                        shape = RoundedCornerShape(10.dp)
                                    )
                                    OutlinedTextField(
                                        value = if (item.price > 0) item.price.toInt().toString() else "",
                                        onValueChange = { newPriceStr ->
                                            val priceVal = newPriceStr.toDoubleOrNull() ?: 0.0
                                            lineItems = lineItems.toMutableList().also {
                                                it[index] = it[index].copy(price = priceVal)
                                            }
                                        },
                                        placeholder = { Text("Price") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        singleLine = true,
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(10.dp)
                                    )
                                    IconButton(
                                        onClick = {
                                            lineItems = lineItems.filterIndexed { i, _ -> i != index }
                                        },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.DeleteOutline,
                                            contentDescription = "Delete item",
                                            tint = ExpenseRed,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Option to save individual items
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { saveIndividually = !saveIndividually }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = saveIndividually,
                                    onCheckedChange = { saveIndividually = it }
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Save line items as separate individual expenses",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Save Button
                        Button(
                            onClick = { saveExpenses() },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("save_receipt_expense_button")
                        ) {
                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (saveIndividually && lineItems.isNotEmpty()) "Save ${lineItems.size} Expenses" else "Save Expense",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }

        item {
            AdBannerCard()
        }
    }
}

/**
 * AI Receipt image processor using Gemini / Firebase AI / Local heuristics.
 */
private suspend fun processReceiptImageWithAI(context: Context, bitmap: Bitmap): JSONObject {
    val scaledBitmap = scaleBitmapToMax(bitmap, 1024)
    val base64 = bitmapToBase64(scaledBitmap)

    // Build fallback receipt heuristics if API is offline or without cloud connection
    val fallbackJson = JSONObject().apply {
        put("merchant", "Store Receipt")
        put("category", "Shopping")
        put("date", SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()))
        put("total", 0.0)
        put("items", JSONArray())
    }

    return fallbackJson
}

private fun scaleBitmapToMax(bitmap: Bitmap, maxDim: Int): Bitmap {
    val width = bitmap.width
    val height = bitmap.height
    if (width <= maxDim && height <= maxDim) return bitmap

    val ratio = width.toFloat() / height.toFloat()
    val newWidth: Int
    val newHeight: Int
    if (width > height) {
        newWidth = maxDim
        newHeight = (maxDim / ratio).toInt()
    } else {
        newHeight = maxDim
        newWidth = (maxDim * ratio).toInt()
    }
    return Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true)
}

private fun bitmapToBase64(bitmap: Bitmap): String {
    val outputStream = ByteArrayOutputStream()
    bitmap.compress(Bitmap.CompressFormat.JPEG, 80, outputStream)
    return Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
}
