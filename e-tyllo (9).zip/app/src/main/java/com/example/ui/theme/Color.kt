package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ===================================================================
// E Tyllo Refined Fintech Color System
// Modern Deep Indigo / Vibrant Success Green / Coral & Amber Accents
// ===================================================================

// Primary Branding & Accents (Deep Indigo / Electric Blue)
val IndigoPrimary = Color(0xFF4338CA)        // Deep Indigo 700 (#4338CA)
val IndigoDark = Color(0xFF1E1B4B)           // Indigo 950 (#1E1B4B)
val IndigoLight = Color(0xFF6366F1)          // Indigo 500 (#6366F1)
val IndigoContainerLight = Color(0xFFEEF2FF) // Indigo 50 (#EEF2FF)
val IndigoContainerDark = Color(0xFF312E81)  // Indigo 900 (#312E81)
val DeepIndigoBrand = Color(0xFF3730A3)      // Indigo 800 (#3730A3)

// Success & Income Accents (Crisp Modern Emerald Green #22C55E)
val AccentSuccessGreen = Color(0xFF22C55E)   // Green 500 (#22C55E)
val AccentSuccessLight = Color(0xFF4ADE80)   // Green 400 (#4ADE80)
val AccentSuccessDark = Color(0xFF16A34A)    // Green 600 (#16A34A)
val SoftSuccessBgLight = Color(0xFFF0FDF4)   // Green 50
val SoftSuccessBgDark = Color(0xFF052E16)    // Green 950

// Expense Accents (Crisp Coral / Red #F87171 & #EF4444)
val AccentExpenseCoral = Color(0xFFF87171)   // Red 400 (#F87171)
val AccentExpenseRed = Color(0xFFEF4444)     // Red 500 (#EF4444)
val SoftExpenseBgLight = Color(0xFFFEF2F2)   // Red 50
val SoftExpenseBgDark = Color(0xFF450A0A)    // Red 950

// Loan & Warning Accents (Warm Amber #F59E0B)
val AccentLoanAmber = Color(0xFFF59E0B)      // Amber 500 (#F59E0B)
val SoftLoanBgLight = Color(0xFFFFFBEB)      // Amber 50
val SoftLoanBgDark = Color(0xFF451A03)       // Amber 950

// Compatibility aliases for legacy references across existing composables
val DeepTeal = IndigoPrimary
val DeepTealLight = IndigoLight
val DeepTealDark = IndigoDark
val TealContainerLight = IndigoContainerLight
val TealContainerDark = IndigoContainerDark

val EmeraldGreen = AccentSuccessGreen
val EmeraldLight = AccentSuccessLight
val EmeraldDark = AccentSuccessDark

val TealPrimary = IndigoPrimary
val TealDark = IndigoDark
val TealLight = IndigoLight
val EmeraldPrimary = AccentSuccessGreen
val EmeraldBg = IndigoContainerDark

val RoseCoral = AccentExpenseCoral
val RoseCoralBg = SoftExpenseBgLight

// Dark Theme Surfaces & Text (Dark Slate / Navy #0A192F)
val DarkSlateNavy = Color(0xFF0A192F)        // Deep Dark Slate Navy (#0A192F)
val DarkBackground = DarkSlateNavy
val DarkSurface = Color(0xFF112240)           // Navy Slate Card Surface
val DarkSurfaceVariant = Color(0xFF1E293B)    // Slate 800
val DarkBorder = Color(0xFF233554)            // Border in Navy Dark
val DarkTextPrimary = Color(0xFFF8FAFC)       // Slate 50 Clean Text
val DarkTextSecondary = Color(0xFF94A3B8)     // Soft Slate Gray (#94A3B8)
val SoftSlateGray = Color(0xFF94A3B8)

// Light Theme Surfaces & Text (Clean White #F8FAFC / Light Soft Gray #F1F5F9)
val CleanWhite = Color(0xFFF8FAFC)           // Clean White Light Surface (#F8FAFC)
val SoftLightGray = Color(0xFFF1F5F9)        // Light Soft Gray (#F1F5F9)
val LightBackground = CleanWhite
val LightSurface = Color(0xFFFFFFFF)         // Pure White card
val LightSurfaceVariant = SoftLightGray
val LightBorder = Color(0xFFE2E8F0)          // Slate 200 Border
val LightTextPrimary = Color(0xFF0F172A)     // High-contrast Slate 900
val LightTextSecondary = Color(0xFF64748B)   // High-contrast Slate 500

val TextFieldBgLight = SoftLightGray
val TextFieldBgDark = DarkSurfaceVariant

// Semantic Transaction Colors
val IncomeGreen = AccentSuccessGreen
val SoftMintGreenBg = SoftSuccessBgLight
val SoftMintGreenBgDark = SoftSuccessBgDark

val ExpenseRed = AccentExpenseRed
val SoftSalmonRedBg = SoftExpenseBgLight
val SoftSalmonRedBgDark = SoftExpenseBgDark

val LoanOrange = AccentLoanAmber
val SoftOrangeBg = SoftLoanBgLight
val SoftOrangeBgDark = SoftLoanBgDark

val SavingsBlue = IndigoLight
val SoftBlueBg = IndigoContainerLight
val SoftBlueBgDark = IndigoContainerDark

// Charts
val ChartBlue = IndigoLight
val ChartGreen = AccentSuccessGreen
val ChartRed = AccentExpenseRed
val ChartYellow = AccentLoanAmber
