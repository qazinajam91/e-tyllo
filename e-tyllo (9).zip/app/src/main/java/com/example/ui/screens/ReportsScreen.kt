package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LoanEntity
import com.example.data.model.TransactionEntity
import com.example.ui.theme.*
import com.example.util.PdfGenerator
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ReportsScreen(
    transactions: List<TransactionEntity>,
    loans: List<LoanEntity> = emptyList(),
    tr: (String) -> String
) {
    val context = LocalContext.current
    val currentCal = remember { Calendar.getInstance() }
    val isDark = isSystemInDarkTheme()

    var selectedMonthIndex by remember { mutableIntStateOf(currentCal.get(Calendar.MONTH)) }
    var selectedYear by remember { mutableIntStateOf(currentCal.get(Calendar.YEAR)) }
    var selectedDay by remember { mutableStateOf<Int?>(null) } // null means "All Days"

    var showMonthDropdown by remember { mutableStateOf(false) }
    var showYearDropdown by remember { mutableStateOf(false) }
    var showDayDropdown by remember { mutableStateOf(false) }

    val monthsList = listOf(
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    )
    val yearsList = (2024..2030).toList()

    // Calculate maximum days in selected month and year
    val maxDaysInMonth = remember(selectedMonthIndex, selectedYear) {
        val cal = Calendar.getInstance().apply {
            set(Calendar.YEAR, selectedYear)
            set(Calendar.MONTH, selectedMonthIndex)
            set(Calendar.DAY_OF_MONTH, 1)
        }
        cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    }

    // Reset selected day if it exceeds the new month's days
    LaunchedEffect(maxDaysInMonth) {
        if (selectedDay != null && selectedDay!! > maxDaysInMonth) {
            selectedDay = null
        }
    }

    // Filter transactions by selected month, year & optional day
    val filteredTransactions = remember(transactions, selectedMonthIndex, selectedYear, selectedDay) {
        transactions.filter { tx ->
            val cal = Calendar.getInstance().apply { timeInMillis = tx.dateMillis }
            val matchMonth = cal.get(Calendar.MONTH) == selectedMonthIndex
            val matchYear = cal.get(Calendar.YEAR) == selectedYear
            val matchDay = selectedDay == null || cal.get(Calendar.DAY_OF_MONTH) == selectedDay
            matchMonth && matchYear && matchDay
        }.sortedByDescending { it.dateMillis }
    }

    // Filter loans by selected month, year & optional day
    val filteredLoans = remember(loans, selectedMonthIndex, selectedYear, selectedDay) {
        loans.filter { loan ->
            val cal = Calendar.getInstance().apply { timeInMillis = loan.dateMillis }
            val matchMonth = cal.get(Calendar.MONTH) == selectedMonthIndex
            val matchYear = cal.get(Calendar.YEAR) == selectedYear
            val matchDay = selectedDay == null || cal.get(Calendar.DAY_OF_MONTH) == selectedDay
            matchMonth && matchYear && matchDay
        }.sortedByDescending { it.dateMillis }
    }

    val totalIncome = filteredTransactions.filter { it.type.uppercase() == "INCOME" }.sumOf { it.amount }
    val totalExpense = filteredTransactions.filter { it.type.uppercase() == "EXPENSE" }.sumOf { it.amount }
    val netBalance = totalIncome - totalExpense

    val totalLent = filteredLoans.filter { it.type.contains("LEND", true) || it.type.contains("Gave", true) }.sumOf { it.amount }
    val totalBorrowed = filteredLoans.filter { it.type.contains("BORROW", true) || it.type.contains("Took", true) }.sumOf { it.amount }

    // Group transactions by date string
    val dayGrouped = remember(filteredTransactions) {
        val dateFormat = SimpleDateFormat("dd MMMM yyyy", Locale.getDefault())
        filteredTransactions.groupBy { dateFormat.format(Date(it.dateMillis)) }
    }

    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        visible = true
    }

    AnimatedVisibility(
        visible = visible,
        enter = fadeIn() + slideInVertically(initialOffsetY = { it / 6 })
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Day, Month and Year Selectors
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Day Selector
                Box(modifier = Modifier.weight(1f)) {
                    OutlinedButton(
                        onClick = { showDayDropdown = true },
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("day_filter_button")
                    ) {
                        Text(
                            text = if (selectedDay == null) "All Days" else "Day $selectedDay",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = TealPrimary,
                            maxLines = 1
                        )
                    }
                    DropdownMenu(
                        expanded = showDayDropdown,
                        onDismissRequest = { showDayDropdown = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("All Days (Full Month)") },
                            onClick = {
                                selectedDay = null
                                showDayDropdown = false
                            }
                        )
                        (1..maxDaysInMonth).forEach { day ->
                            DropdownMenuItem(
                                text = { Text("Day $day") },
                                onClick = {
                                    selectedDay = day
                                    showDayDropdown = false
                                }
                            )
                        }
                    }
                }

                // Month Dropdown Box
                Box(modifier = Modifier.weight(1.2f)) {
                    OutlinedButton(
                        onClick = { showMonthDropdown = true },
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("month_filter_button")
                    ) {
                        Text(
                            text = monthsList[selectedMonthIndex],
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = TealPrimary,
                            maxLines = 1
                        )
                    }
                    DropdownMenu(
                        expanded = showMonthDropdown,
                        onDismissRequest = { showMonthDropdown = false }
                    ) {
                        monthsList.forEachIndexed { index, name ->
                            DropdownMenuItem(
                                text = { Text(name) },
                                onClick = {
                                    selectedMonthIndex = index
                                    showMonthDropdown = false
                                }
                            )
                        }
                    }
                }

                // Year Dropdown Box
                Box(modifier = Modifier.weight(0.9f)) {
                    OutlinedButton(
                        onClick = { showYearDropdown = true },
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("year_filter_button")
                    ) {
                        Text(
                            text = "$selectedYear",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = TealPrimary,
                            maxLines = 1
                        )
                    }
                    DropdownMenu(
                        expanded = showYearDropdown,
                        onDismissRequest = { showYearDropdown = false }
                    ) {
                        yearsList.forEach { y ->
                            DropdownMenuItem(
                                text = { Text("$y") },
                                onClick = {
                                    selectedYear = y
                                    showYearDropdown = false
                                }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Summary Overview Card
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 2.dp,
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    val periodLabel = if (selectedDay != null) {
                        "$selectedDay ${monthsList[selectedMonthIndex]} $selectedYear"
                    } else {
                        "${monthsList[selectedMonthIndex]} $selectedYear"
                    }

                    Text(
                        text = "$periodLabel Overview",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Income", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("Rs ${totalIncome.toInt()}", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = IncomeGreen)
                        }
                        Column {
                            Text("Expense", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("Rs ${totalExpense.toInt()}", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = ExpenseRed)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Net Balance", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = "Rs ${netBalance.toInt()}",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (netBalance >= 0) IncomeGreen else ExpenseRed
                            )
                        }
                    }

                    if (filteredLoans.isNotEmpty() || totalLent > 0 || totalBorrowed > 0) {
                        HorizontalDivider(
                            modifier = Modifier.padding(vertical = 8.dp),
                            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Total Lent", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("Rs ${totalLent.toInt()}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = AccentLoanAmber)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Total Borrowed", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("Rs ${totalBorrowed.toInt()}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = ExpenseRed)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Export to PDF Button
            Button(
                onClick = {
                    PdfGenerator.generateAndOpenReportPdf(
                        context = context,
                        monthName = monthsList[selectedMonthIndex],
                        year = selectedYear,
                        day = selectedDay,
                        totalIncome = totalIncome,
                        totalExpense = totalExpense,
                        totalLent = totalLent,
                        totalBorrowed = totalBorrowed,
                        transactions = filteredTransactions,
                        loans = filteredLoans
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = TealPrimary),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .testTag("export_pdf_report_button")
            ) {
                Icon(imageVector = Icons.Default.PictureAsPdf, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Export to PDF Report", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Content Breakdown List
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                // Section 1: Transactions
                item {
                    Text(
                        text = "Transactions Breakdown (${filteredTransactions.size})",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                if (dayGrouped.isEmpty()) {
                    item {
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "No transactions recorded for this period",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                } else {
                    dayGrouped.forEach { (dateStr, txList) ->
                        val dayIncome = txList.filter { it.type.uppercase() == "INCOME" }.sumOf { it.amount }
                        val dayExpense = txList.filter { it.type.uppercase() == "EXPENSE" }.sumOf { it.amount }

                        item {
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surface,
                                shadowElevation = 1.5.dp,
                                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = dateStr,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = TealPrimary
                                        )
                                        Text(
                                            text = "Net: Rs ${(dayIncome - dayExpense).toInt()}",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (dayIncome - dayExpense >= 0) IncomeGreen else ExpenseRed
                                        )
                                    }

                                    HorizontalDivider(
                                        modifier = Modifier.padding(vertical = 6.dp),
                                        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                                    )

                                    txList.forEach { tx ->
                                        val isIncome = tx.type.uppercase() == "INCOME"
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 3.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = if (isIncome) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                                                contentDescription = null,
                                                tint = if (isIncome) IncomeGreen else ExpenseRed,
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = tx.category,
                                                    fontWeight = FontWeight.Medium,
                                                    fontSize = 12.5.sp,
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                                if (tx.note.isNotBlank()) {
                                                    Text(
                                                        text = tx.note,
                                                        fontSize = 10.5.sp,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                            }
                                            Text(
                                                text = "${if (isIncome) "+" else "-"}Rs ${tx.amount.toInt()}",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.5.sp,
                                                color = if (isIncome) IncomeGreen else ExpenseRed
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Section 2: Loans & Borrowings
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Loans & Borrowings (${filteredLoans.size})",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                if (filteredLoans.isEmpty()) {
                    item {
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "No loan records found for this period",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                } else {
                    items(filteredLoans, key = { it.id }) { loan ->
                        val isLent = loan.type.contains("LEND", true) || loan.type.contains("Gave", true)
                        val loanDateStr = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(loan.dateMillis))

                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surface,
                            shadowElevation = 1.5.dp,
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(
                                            if (isLent) AccentSuccessGreen.copy(alpha = 0.15f) else AccentLoanAmber.copy(alpha = 0.15f),
                                            RoundedCornerShape(10.dp)
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (isLent) Icons.Default.CallMade else Icons.Default.CallReceived,
                                        contentDescription = null,
                                        tint = if (isLent) AccentSuccessGreen else AccentLoanAmber,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(10.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = loan.personName,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "${if (isLent) "Lent on " else "Borrowed on "} $loanDateStr",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "Rs ${loan.amount.toInt()}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = if (isLent) AccentSuccessGreen else AccentLoanAmber
                                    )
                                    Text(
                                        text = if (loan.isCleared) "Cleared" else "Rem: Rs ${loan.remainingAmount.toInt()}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = if (loan.isCleared) IncomeGreen else ExpenseRed
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
