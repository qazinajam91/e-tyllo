package com.example.ui.screens

import androidx.compose.runtime.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.viewmodel.AuthViewModel

enum class AuthScreenMode {
    SIGN_IN,
    SIGN_UP,
    EMAIL_VERIFICATION
}

@Composable
fun LoginScreen(
    authViewModel: AuthViewModel,
    onSignInSuccess: () -> Unit,
    tr: (String) -> String
) {
    val uiState by authViewModel.uiState.collectAsStateWithLifecycle()
    var currentMode by remember { mutableStateOf(AuthScreenMode.SIGN_IN) }

    LaunchedEffect(uiState.isAuthenticated, uiState.isGuest, uiState.isNeedsVerification) {
        if (uiState.isAuthenticated || uiState.isGuest) {
            onSignInSuccess()
        } else if (uiState.isNeedsVerification) {
            currentMode = AuthScreenMode.EMAIL_VERIFICATION
        }
    }

    when (currentMode) {
        AuthScreenMode.SIGN_IN -> {
            SignInScreen(
                authViewModel = authViewModel,
                onNavigateToSignUp = {
                    authViewModel.clearMessages()
                    currentMode = AuthScreenMode.SIGN_UP
                },
                onSignInSuccess = onSignInSuccess,
                onNeedsEmailVerification = {
                    currentMode = AuthScreenMode.EMAIL_VERIFICATION
                },
                tr = tr
            )
        }
        AuthScreenMode.SIGN_UP -> {
            SignUpScreen(
                authViewModel = authViewModel,
                onNavigateToSignIn = {
                    authViewModel.clearMessages()
                    currentMode = AuthScreenMode.SIGN_IN
                },
                onNeedsEmailVerification = {
                    currentMode = AuthScreenMode.EMAIL_VERIFICATION
                },
                tr = tr
            )
        }
        AuthScreenMode.EMAIL_VERIFICATION -> {
            EmailVerificationScreen(
                authViewModel = authViewModel,
                onVerificationSuccess = onSignInSuccess,
                onSignOut = {
                    currentMode = AuthScreenMode.SIGN_IN
                },
                tr = tr
            )
        }
    }
}
