package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ChartBlue
import com.example.ui.theme.ChartGreen
import com.example.ui.theme.ChartRed
import com.example.ui.theme.ChartYellow
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.ExpenseRed

data class PieSegment(
    val category: String,
    val amount: Double,
    val color: Color
)

@Composable
fun DonutChart(
    segments: List<PieSegment>,
    modifier: Modifier = Modifier
) {
    var selectedCategory by remember { mutableStateOf<PieSegment?>(null) }
    val total = segments.sumOf { it.amount }.coerceAtLeast(1.0)

    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(200.dp)
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(segments) {
                        detectTapGestures { offset ->
                            val center = Offset(size.width / 2f, size.height / 2f)
                            val dx = offset.x - center.x
                            val dy = offset.y - center.y
                            var angle = Math.toDegrees(Math.atan2(dy.toDouble(), dx.toDouble())).toFloat()
                            if (angle < 0) angle += 360f

                            var currentAngle = 0f
                            for (segment in segments) {
                                val sweep = (segment.amount / total * 360f).toFloat()
                                if (angle >= currentAngle && angle <= currentAngle + sweep) {
                                    selectedCategory = segment
                                    break
                                }
                                currentAngle += sweep
                            }
                        }
                    }
            ) {
                val strokeWidth = 36.dp.toPx()
                val diameter = size.minDimension - strokeWidth
                val topLeft = Offset((size.width - diameter) / 2, (size.height - diameter) / 2)
                val arcSize = Size(diameter, diameter)

                var startAngle = -90f
                val defaultSegments = if (segments.isEmpty()) {
                    listOf(
                        PieSegment("Travel", 230.0, ChartBlue),
                        PieSegment("Food", 170.0, ChartRed)
                    )
                } else segments

                val currentTotal = defaultSegments.sumOf { it.amount }.coerceAtLeast(1.0)

                defaultSegments.forEach { seg ->
                    val sweepAngle = (seg.amount / currentTotal * 360f).toFloat()
                    drawArc(
                        color = seg.color,
                        startAngle = startAngle,
                        sweepAngle = sweepAngle - 2f, // gap
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = strokeWidth)
                    )
                    startAngle += sweepAngle
                }
            }

            // Central Tooltip Popup
            selectedCategory?.let { seg ->
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shadowElevation = 4.dp
                ) {
                    Text(
                        text = "${seg.category} : Rs${seg.amount.toInt()}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = seg.color,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            } ?: run {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f)
                ) {
                    Text(
                        text = "Food : Rs170",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = ExpenseRed,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Legend Items
        val displaySegments = if (segments.isEmpty()) {
            listOf(
                PieSegment("Travel", 230.0, ChartBlue),
                PieSegment("Food", 170.0, ChartRed)
            )
        } else segments

        Column(modifier = Modifier.fillMaxWidth()) {
            displaySegments.forEach { seg ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp, horizontal = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .background(seg.color, RoundedCornerShape(2.dp))
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = seg.category,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Text(
                        text = "Rs${seg.amount.toInt()}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

@Composable
fun WeeklyTrendChart(
    modifier: Modifier = Modifier
) {
    val days = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
    var selectedDay by remember { mutableStateOf("Fri") }

    Column(modifier = modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .padding(vertical = 8.dp)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val width = size.width
                val height = size.height - 30.dp.toPx()
                val stepX = width / days.size

                // Draw Y axis guidelines
                val gridColor = Color.Gray.copy(alpha = 0.15f)
                drawLine(gridColor, Offset(0f, 0f), Offset(width, 0f), strokeWidth = 1f)
                drawLine(gridColor, Offset(0f, height / 2), Offset(width, height / 2), strokeWidth = 1f)
                drawLine(gridColor, Offset(0f, height), Offset(width, height), strokeWidth = 1f)

                // Draw Bars for Sun (Active bar from screenshot)
                days.forEachIndexed { index, day ->
                    val x = index * stepX + stepX / 2
                    if (day == "Sun") {
                        val barWidth = 12.dp.toPx()
                        // Green Income Bar
                        drawRect(
                            color = EmeraldPrimary,
                            topLeft = Offset(x - barWidth - 2, height * 0.2f),
                            size = Size(barWidth, height * 0.8f)
                        )
                        // Red Expense Bar
                        drawRect(
                            color = ExpenseRed,
                            topLeft = Offset(x + 2, height * 0.4f),
                            size = Size(barWidth, height * 0.6f)
                        )
                    }
                }
            }

            // Interactive Tooltip Box in Middle (Matching Screenshot)
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                shadowElevation = 6.dp,
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(8.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(text = selectedDay, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(text = "Expense : Rs0", color = ExpenseRed, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    Text(text = "Income : Rs0", color = EmeraldPrimary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                }
            }
        }

        // X Axis Labels
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            days.forEach { day ->
                Text(
                    text = day,
                    fontSize = 12.sp,
                    color = if (day == selectedDay) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Legend
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(modifier = Modifier.size(10.dp).background(ExpenseRed, RoundedCornerShape(2.dp)))
            Spacer(modifier = Modifier.width(4.dp))
            Text(text = "Expense", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.width(16.dp))
            Box(modifier = Modifier.size(10.dp).background(EmeraldPrimary, RoundedCornerShape(2.dp)))
            Spacer(modifier = Modifier.width(4.dp))
            Text(text = "Income", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun MonthlyTrendChart(
    modifier: Modifier = Modifier
) {
    val months = listOf("Mar 26", "Apr 26", "May 26", "Jun 26", "Aug 26")

    Column(modifier = modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .padding(vertical = 8.dp)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val width = size.width
                val height = size.height - 20.dp.toPx()
                val stepX = width / (months.size - 1)

                val gridColor = Color.Gray.copy(alpha = 0.15f)
                drawLine(gridColor, Offset(0f, 0f), Offset(width, 0f), strokeWidth = 1f)
                drawLine(gridColor, Offset(0f, height / 2), Offset(width, height / 2), strokeWidth = 1f)
                drawLine(gridColor, Offset(0f, height), Offset(width, height), strokeWidth = 1f)

                // Green Line (Income)
                val greenPath = Path().apply {
                    moveTo(0f, height)
                    lineTo(stepX * 1, height)
                    lineTo(stepX * 2, height)
                    lineTo(stepX * 3, height)
                    cubicTo(stepX * 3.5f, height * 0.8f, stepX * 3.8f, height * 0.2f, stepX * 4, height * 0.15f)
                }
                drawPath(greenPath, EmeraldPrimary, style = Stroke(width = 3.dp.toPx()))

                // Red Line (Expense)
                val redPath = Path().apply {
                    moveTo(0f, height)
                    lineTo(stepX * 1, height)
                    lineTo(stepX * 2, height)
                    lineTo(stepX * 3, height)
                    cubicTo(stepX * 3.5f, height * 0.9f, stepX * 3.8f, height * 0.6f, stepX * 4, height * 0.5f)
                }
                drawPath(redPath, ExpenseRed, style = Stroke(width = 3.dp.toPx()))

                // Draw Dots on Points
                drawCircle(Color.White, radius = 5.dp.toPx(), center = Offset(stepX * 4, height * 0.15f))
                drawCircle(EmeraldPrimary, radius = 3.dp.toPx(), center = Offset(stepX * 4, height * 0.15f))

                drawCircle(Color.White, radius = 5.dp.toPx(), center = Offset(stepX * 4, height * 0.5f))
                drawCircle(ExpenseRed, radius = 3.dp.toPx(), center = Offset(stepX * 4, height * 0.5f))
            }
        }

        // X Labels
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            months.forEach { m ->
                Text(text = m, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
